                      ;
this.gbar_ = {
    CONFIG: [
        [
            [0, "www.gstatic.com", "og.qtm.en_US.JWorkDrelEU.O", "com", "en", "117", 0, [4, 2, ".40.40.76.40.40.", "", "1300102,3700250", "1477276084", "0"], null, "6pUeWIP9Lcf_vAS0k6P4BQ", null, 0, "og.qtm.-nn94wb6gu8hw.L.W.O", "AA2YrTs3MZuIWnJdyD4Oj02JBNej_PUvKQ", "AA2YrTun-8-7Kguo6ymlUZgkK8aJkThylA", "", 2, 0, 200, "IDN"], null, null, null, [1, 1, 0, null, "0", "ryandevstudio@gmail.com", "", "APnIpuvINtECF2ftTHvEr9xkWB1quZ4anuO6xleJwSBPEnRrzRl06Rdk3QuI82IAXl0PQafwlpR3qSKzoF7pUS6OU2dARAcWhA"],
            [0, 1, "", 1, 0, 0, 1],
            ["%1$s (default)", "Brand Account", 0, "%1$s (delegated)", 0, null, 96, "", null, null, null, 1, "https://accounts.google.com/ListAccounts?listPages=0\u0026mo=1\u0026mn=1\u0026hl=en", 0, "dashboard/overview", null, null, null, null, "Profile", "", 0, 1],
            ["", "https", "plus.google.com", "", "/u/0/_/notifications/frame", "sourceid=117", "pid=117", "en", 5, "https://accounts.google.com/ServiceLogin?hl=en\u0026passive=true\u0026continue=https://support.google.com/chrome/%3Fp%3Dhelp%26ctx%3Dkeyboard", 0, 30000, null, "%1$s Reload the page %2$s and try again."],
            ["1", "gci_91f30755d6a6b787dcc2a4062e6e9824.js", "googleapis.client:plusone:gapi.iframes", "0", "en"], null, [100, "Notifications", 1, "https", "plus.google.com", "", 0, "", "POST", "/u/0/_/notifications/count", 3000, "%1$s Google notifications", 1, "There was an error loading notifications.", "ogs.google.com"],
            [0, "", null, "", 0, "There was an error loading your Marketplace apps.", "You have no Marketplace apps.", 1, [117, "https://support.google.com/?hl=en\u0026src=1b", "Support", "", "", null, 0], null, null, 1, 0, [
                [1, "%1$s of %2$s", "%1$s of %2$s in the more section"]
            ]],
            [1, null, null, "[[]]", ["https", "ogs.google.com", 0, "/u/0", "rt=j\u0026sourceid=117", ["/u/0/_/og/customization/get", ""],
                ["/u/0/_/og/customization/set", ""],
                ["/u/0/_/og/customization/remove", ""]
            ], "APnIpuvINtECF2ftTHvEr9xkWB1quZ4anuO6xleJwSBPEnRrzRl06Rdk3QuI82IAXl0PQafwlpR3qSKzoF7pUS6OU2dARAcWhA"],
            ["m;/_/scs/abc-static/_/js/k=gapi.gapi.en.8KvJMpFyTwI.O/m=__features__/rt=j/d=1/rs=AHpOoo97bqw3j5jg4TkTecEOgY44B9P0Vg", "https://apis.google.com", "", "1", "1", "", null, 1, "es_plusone_gc_20161019.0_p0", "en"],
            [0.009999999776482582, "com", "117", [null, "", "w", null, 1, 5184000, 1, 0, "", 0], null, [
                ["", "", "0", 0, 0, -1]
            ], null, 0, null, null, ["5061451", "google\\.(com|ru|ca|by|kz|com\\.mx|com\\.tr)$", 1]],
            [0, 1, 1, 40400, 117, "IDN", "en", "1477276084.0", 7],
            [
                [null, null, null, "//www.gstatic.com/og/_/js/k=og.qtm.en_US.JWorkDrelEU.O/rt=j/m=qgl,q_d,q_sf,qawd,qnd,qdid,qmd,qsd/exm=qaaw,qabr,qadd,qaid,qalo,qano,qebr,qein,qhaw,qhbr,qhch,qhga,qhid,qhin,qhlo,qhmn,qhno,qhpc,qhpr,qhsf,qhtb,qhtt/d=1/ed=1/rs=AA2YrTs3MZuIWnJdyD4Oj02JBNej_PUvKQ"],
                [null, null, null, "//www.gstatic.com/og/_/ss/k=og.qtm.-nn94wb6gu8hw.L.W.O/m=q_d,q_sf,qawd,qnd,qdid,qmd/excm=qaaw,qabr,qadd,qaid,qalo,qano,qebr,qein,qhaw,qhbr,qhch,qhga,qhid,qhin,qhlo,qhmn,qhno,qhpc,qhpr,qhsf,qhtb,qhtt/d=1/ed=1/rs=AA2YrTun-8-7Kguo6ymlUZgkK8aJkThylA"]
            ]
        ]
    ],
};
this.gbar_ = this.gbar_ || {};
(function(_) {
    var window = this;
    try {
        var aa, ba, ca, da, sa, ta;
        for (_.k, aa = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, c, d) {
                if (d.get || d.set) throw new TypeError("ES3 does not support getters and setters.");
                a != Array.prototype && a != Object.prototype && (a[c] = d.value)
            }, ba = "undefined" != typeof window && window === this ? this : "undefined" != typeof window.global && null != window.global ? window.global : this, ca = ["String", "prototype", "startsWith"], da = 0; da < ca.length - 1; da++) {
            var fa = ca[da];
            fa in ba || (ba[fa] = {});
            ba = ba[fa]
        }
        var ga = ca[ca.length - 1],
            ha = ba[ga],
            ia = ha ? ha : function(a, c) {
                var d;
                if (null == this) throw new TypeError("The 'this' value for String.prototype.startsWith must not be null or undefined");
                if (a instanceof RegExp) throw new TypeError("First argument to String.prototype.startsWith must not be a regular expression");
                d = this + "";
                a += "";
                for (var e = d.length, f = a.length, g = Math.max(0, Math.min(c | 0, d.length)), h = 0; h < f && g < e;)
                    if (d[g++] != a[h++]) return !1;
                return h >= f
            };
        ia != ha && null != ia && aa(ba, ga, {
            configurable: !0,
            writable: !0,
            value: ia
        });
        _.ja = _.ja || {};
        _.m = this;
        _.ka = function(a) {
            return void 0 !== a
        };
        _.la = function() {};
        _.ma = function(a) {
            a.Aa = function() {
                return a.Me ? a.Me : a.Me = new a
            }
        };
        _.na = function(a) {
            var c = typeof a;
            if ("object" == c)
                if (a) {
                    if (a instanceof Array) return "array";
                    if (a instanceof Object) return c;
                    var d = Object.prototype.toString.call(a);
                    if ("[object Window]" == d) return "object";
                    if ("[object Array]" == d || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) return "array";
                    if ("[object Function]" == d || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) return "function"
                } else return "null";
            else if ("function" == c && "undefined" == typeof a.call) return "object";
            return c
        };
        _.oa = function(a) {
            return "array" == _.na(a)
        };
        _.n = function(a) {
            return "string" == typeof a
        };
        _.pa = function(a) {
            return "number" == typeof a
        };
        _.qa = "closure_uid_" + (1E9 * Math.random() >>> 0);
        sa = function(a, c, d) {
            return a.call.apply(a.bind, arguments)
        };
        ta = function(a, c, d) {
            if (!a) throw Error();
            if (2 < arguments.length) {
                var e = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var d = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(d, e);
                    return a.apply(c, d)
                }
            }
            return function() {
                return a.apply(c, arguments)
            }
        };
        _.q = function(a, c, d) {
            _.q = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? sa : ta;
            return _.q.apply(null, arguments)
        };
        _.ua = Date.now || function() {
            return +new Date
        };
        _.t = function(a, c) {
            var d = a.split("."),
                e = _.m;
            d[0] in e || !e.execScript || e.execScript("var " + d[0]);
            for (var f; d.length && (f = d.shift());) !d.length && _.ka(c) ? e[f] = c : e[f] ? e = e[f] : e = e[f] = {}
        };
        _.v = function(a, c) {
            function d() {}
            d.prototype = c.prototype;
            a.H = c.prototype;
            a.prototype = new d;
            a.prototype.constructor = a;
            a.Yh = function(a, d, g) {
                for (var e = Array(arguments.length - 2), f = 2; f < arguments.length; f++) e[f - 2] = arguments[f];
                return c.prototype[d].apply(a, e)
            }
        };
        _.va = function(a) {
            if (Error.captureStackTrace) Error.captureStackTrace(this, _.va);
            else {
                var c = Error().stack;
                c && (this.stack = c)
            }
            a && (this.message = String(a))
        };
        _.v(_.va, Error);
        _.va.prototype.name = "CustomError";
        var xa;
        _.wa = String.prototype.trim ? function(a) {
            return a.trim()
        } : function(a) {
            return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "")
        };
        _.ya = function(a, c) {
            for (var d = 0, e = (0, _.wa)(String(a)).split("."), f = (0, _.wa)(String(c)).split("."), g = Math.max(e.length, f.length), h = 0; 0 == d && h < g; h++) {
                var l = e[h] || "",
                    p = f[h] || "";
                do {
                    l = /(\d*)(\D*)(.*)/.exec(l) || ["", "", "", ""];
                    p = /(\d*)(\D*)(.*)/.exec(p) || ["", "", "", ""];
                    if (0 == l[0].length && 0 == p[0].length) break;
                    d = xa(0 == l[1].length ? 0 : (0, window.parseInt)(l[1], 10), 0 == p[1].length ? 0 : (0, window.parseInt)(p[1], 10)) || xa(0 == l[2].length, 0 == p[2].length) || xa(l[2], p[2]);
                    l = l[3];
                    p = p[3]
                } while (0 == d)
            }
            return d
        };
        xa = function(a, c) {
            return a < c ? -1 : a > c ? 1 : 0
        };
        _.za = Array.prototype.indexOf ? function(a, c, d) {
            return Array.prototype.indexOf.call(a, c, d)
        } : function(a, c, d) {
            d = null == d ? 0 : 0 > d ? Math.max(0, a.length + d) : d;
            if (_.n(a)) return _.n(c) && 1 == c.length ? a.indexOf(c, d) : -1;
            for (; d < a.length; d++)
                if (d in a && a[d] === c) return d;
            return -1
        };
        _.Aa = Array.prototype.forEach ? function(a, c, d) {
            Array.prototype.forEach.call(a, c, d)
        } : function(a, c, d) {
            for (var e = a.length, f = _.n(a) ? a.split("") : a, g = 0; g < e; g++) g in f && c.call(d, f[g], g, a)
        };
        _.Ba = Array.prototype.filter ? function(a, c, d) {
            return Array.prototype.filter.call(a, c, d)
        } : function(a, c, d) {
            for (var e = a.length, f = [], g = 0, h = _.n(a) ? a.split("") : a, l = 0; l < e; l++)
                if (l in h) {
                    var p = h[l];
                    c.call(d, p, l, a) && (f[g++] = p)
                }
            return f
        };
        _.Ca = Array.prototype.map ? function(a, c, d) {
            return Array.prototype.map.call(a, c, d)
        } : function(a, c, d) {
            for (var e = a.length, f = Array(e), g = _.n(a) ? a.split("") : a, h = 0; h < e; h++) h in g && (f[h] = c.call(d, g[h], h, a));
            return f
        };
        _.Da = Array.prototype.some ? function(a, c, d) {
            return Array.prototype.some.call(a, c, d)
        } : function(a, c, d) {
            for (var e = a.length, f = _.n(a) ? a.split("") : a, g = 0; g < e; g++)
                if (g in f && c.call(d, f[g], g, a)) return !0;
            return !1
        };
        a: {
            var Fa = _.m.navigator;
            if (Fa) {
                var Ga = Fa.userAgent;
                if (Ga) {
                    _.Ea = Ga;
                    break a
                }
            }
            _.Ea = ""
        }
        _.w = function(a) {
            return -1 != _.Ea.indexOf(a)
        };
        var Ha;
        Ha = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
        _.Ia = function(a, c) {
            for (var d, e, f = 1; f < arguments.length; f++) {
                e = arguments[f];
                for (d in e) a[d] = e[d];
                for (var g = 0; g < Ha.length; g++) d = Ha[g], Object.prototype.hasOwnProperty.call(e, d) && (a[d] = e[d])
            }
        };
        var Ka = function() {
            return (_.w("Chrome") || _.w("CriOS")) && !_.w("Edge")
        };
        _.La = function() {
            return _.w("iPhone") && !_.w("iPod") && !_.w("iPad")
        };
        _.Ma = function(a) {
            _.Ma[" "](a);
            return a
        };
        _.Ma[" "] = _.la;
        var Oa = function(a, c) {
            var d = Na;
            return Object.prototype.hasOwnProperty.call(d, a) ? d[a] : d[a] = c(a)
        };
        var Va, Wa, Na, fb;
        _.Pa = _.w("Opera");
        _.x = _.w("Trident") || _.w("MSIE");
        _.Qa = _.w("Edge");
        _.Ra = _.Qa || _.x;
        _.Sa = _.w("Gecko") && !(-1 != _.Ea.toLowerCase().indexOf("webkit") && !_.w("Edge")) && !(_.w("Trident") || _.w("MSIE")) && !_.w("Edge");
        _.y = -1 != _.Ea.toLowerCase().indexOf("webkit") && !_.w("Edge");
        _.Ta = _.w("Macintosh");
        _.Ua = _.w("Linux") || _.w("CrOS");
        Va = function() {
            var a = _.m.document;
            return a ? a.documentMode : void 0
        };
        a: {
            var Xa = "",
                Ya = function() {
                    var a = _.Ea;
                    if (_.Sa) return /rv\:([^\);]+)(\)|;)/.exec(a);
                    if (_.Qa) return /Edge\/([\d\.]+)/.exec(a);
                    if (_.x) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                    if (_.y) return /WebKit\/(\S+)/.exec(a);
                    if (_.Pa) return /(?:Version)[ \/]?(\S+)/.exec(a)
                }();Ya && (Xa = Ya ? Ya[1] : "");
            if (_.x) {
                var Za = Va();
                if (null != Za && Za > (0, window.parseFloat)(Xa)) {
                    Wa = String(Za);
                    break a
                }
            }
            Wa = Xa
        }
        _.bb = Wa;
        Na = {};
        _.cb = function(a) {
            return Oa(a, function() {
                return 0 <= _.ya(_.bb, a)
            })
        };
        _.eb = function(a) {
            return Number(db) >= a
        };
        var gb = _.m.document;
        fb = gb && _.x ? Va() || ("CSS1Compat" == gb.compatMode ? (0, window.parseInt)(_.bb, 10) : 5) : void 0;
        var db = fb;
        _.hb = _.w("Firefox");
        _.ib = _.La() || _.w("iPod");
        _.jb = _.w("iPad");
        _.kb = _.w("Android") && !(Ka() || _.w("Firefox") || _.w("Opera") || _.w("Silk"));
        _.lb = Ka();
        _.mb = _.w("Safari") && !(Ka() || _.w("Coast") || _.w("Opera") || _.w("Edge") || _.w("Silk") || _.w("Android")) && !(_.La() || _.w("iPad") || _.w("iPod"));
        var nb = null;
        var ob;
        _.pb = function(a, c) {
            return (new ob(c)).f(a)
        };
        ob = function(a) {
            this.b = a
        };
        ob.prototype.f = function(a) {
            var c = [];
            qb(this, a, c);
            return c.join("")
        };
        var qb = function(a, c, d) {
                if (null == c) d.push("null");
                else {
                    if ("object" == typeof c) {
                        if (_.oa(c)) {
                            var e = c;
                            c = e.length;
                            d.push("[");
                            for (var f = "", g = 0; g < c; g++) d.push(f), f = e[g], qb(a, a.b ? a.b.call(e, String(g), f) : f, d), f = ",";
                            d.push("]");
                            return
                        }
                        if (c instanceof String || c instanceof Number || c instanceof Boolean) c = c.valueOf();
                        else {
                            d.push("{");
                            g = "";
                            for (e in c) Object.prototype.hasOwnProperty.call(c, e) && (f = c[e], "function" != typeof f && (d.push(g), rb(e, d), d.push(":"), qb(a, a.b ? a.b.call(c, e, f) : f, d), g = ","));
                            d.push("}");
                            return
                        }
                    }
                    switch (typeof c) {
                        case "string":
                            rb(c,
                                d);
                            break;
                        case "number":
                            d.push((0, window.isFinite)(c) && !(0, window.isNaN)(c) ? String(c) : "null");
                            break;
                        case "boolean":
                            d.push(String(c));
                            break;
                        case "function":
                            d.push("null");
                            break;
                        default:
                            throw Error("d`" + typeof c);
                    }
                }
            },
            sb = {
                '"': '\\"',
                "\\": "\\\\",
                "/": "\\/",
                "\b": "\\b",
                "\f": "\\f",
                "\n": "\\n",
                "\r": "\\r",
                "\t": "\\t",
                "\x0B": "\\u000b"
            },
            tb = /\uffff/.test("\uffff") ? /[\\\"\x00-\x1f\x7f-\uffff]/g : /[\\\"\x00-\x1f\x7f-\xff]/g,
            rb = function(a, c) {
                c.push('"', a.replace(tb, function(a) {
                    var c = sb[a];
                    c || (c = "\\u" + (a.charCodeAt(0) | 65536).toString(16).substr(1), sb[a] = c);
                    return c
                }), '"')
            };
        var wb;
        _.z = function() {};
        _.ub = "function" == typeof window.Uint8Array;
        _.A = function(a, c, d, e, f) {
            a.b = null;
            c || (c = d ? [d] : []);
            a.N = d ? String(d) : void 0;
            a.A = 0 === d ? -1 : 0;
            a.j = c;
            a: {
                if (a.j.length && (c = a.j.length - 1, (d = a.j[c]) && "object" == typeof d && !_.oa(d) && !(_.ub && d instanceof window.Uint8Array))) {
                    a.B = c - a.A;
                    a.o = d;
                    break a
                } - 1 < e ? (a.B = e, a.o = null) : a.B = Number.MAX_VALUE
            }
            a.F = {};
            if (f)
                for (e = 0; e < f.length; e++) c = f[e], c < a.B ? (c += a.A, a.j[c] = a.j[c] || _.vb) : a.o[c] = a.o[c] || _.vb
        };
        _.vb = [];
        _.B = function(a, c) {
            if (c < a.B) {
                var d = c + a.A,
                    e = a.j[d];
                return e === _.vb ? a.j[d] = [] : e
            }
            e = a.o[c];
            return e === _.vb ? a.o[c] = [] : e
        };
        _.C = function(a, c, d) {
            a = _.B(a, c);
            return null == a ? d : a
        };
        _.D = function(a, c, d) {
            a.b || (a.b = {});
            if (!a.b[d]) {
                var e = _.B(a, d);
                e && (a.b[d] = new c(e))
            }
            return a.b[d]
        };
        wb = function(a) {
            if (a.b)
                for (var c in a.b) {
                    var d = a.b[c];
                    if (_.oa(d))
                        for (var e = 0; e < d.length; e++) d[e] && d[e].nb();
                    else d && d.nb()
                }
        };
        _.z.prototype.nb = function() {
            wb(this);
            return this.j
        };
        var xb = _.m.JSON && _.m.JSON.stringify || "object" === typeof JSON && JSON.stringify;
        _.z.prototype.f = _.ub ? function() {
            var a = window.Uint8Array.prototype.toJSON;
            window.Uint8Array.prototype.toJSON = function() {
                if (!nb) {
                    nb = {};
                    for (var a = 0; 65 > a; a++) nb[a] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=".charAt(a)
                }
                for (var a = nb, c = [], f = 0; f < this.length; f += 3) {
                    var g = this[f],
                        h = f + 1 < this.length,
                        l = h ? this[f + 1] : 0,
                        p = f + 2 < this.length,
                        r = p ? this[f + 2] : 0,
                        u = g >> 2,
                        g = (g & 3) << 4 | l >> 4,
                        l = (l & 15) << 2 | r >> 6,
                        r = r & 63;
                    p || (r = 64, h || (l = 64));
                    c.push(a[u], a[g], a[l], a[r])
                }
                return c.join("")
            };
            try {
                var c = xb.call(null, this.nb(),
                    yb)
            } finally {
                window.Uint8Array.prototype.toJSON = a
            }
            return c
        } : xb ? function() {
            return xb.call(null, this.nb(), yb)
        } : function() {
            return _.pb(this.nb(), yb)
        };
        var yb = function(a, c) {
            if (_.pa(c)) {
                if ((0, window.isNaN)(c)) return "NaN";
                if (window.Infinity === c) return "Infinity";
                if (-window.Infinity === c) return "-Infinity"
            }
            return c
        };
        _.z.prototype.toString = function() {
            wb(this);
            return this.j.toString()
        };
        _.F = function() {
            this.Da = this.Da;
            this.yb = this.yb
        };
        _.F.prototype.Da = !1;
        _.F.prototype.ka = function() {
            this.Da || (this.Da = !0, this.L())
        };
        _.F.prototype.L = function() {
            if (this.yb)
                for (; this.yb.length;) this.yb.shift()()
        };
        var zb = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(zb, _.z);
        _.Ab = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(_.Ab, _.z);
        _.Bb = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(_.Bb, _.z);
        var Cb = function(a) {
            _.F.call(this);
            this.j = a;
            this.b = [];
            this.f = {}
        };
        _.v(Cb, _.F);
        var Db = function(a) {
            _.F.call(this);
            this.w = a;
            this.j = this.b = null;
            this.B = 0;
            this.o = {};
            this.f = !1;
            a = window.navigator.userAgent;
            0 <= a.indexOf("MSIE") && 0 <= a.indexOf("Trident") && (a = /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a)) && a[1] && 9 > (0, window.parseFloat)(a[1]) && (this.f = !0)
        };
        _.v(Db, _.F);
        _.Eb = function(a, c, d) {
            if (!a.f)
                if (d instanceof Array)
                    for (var e in d) _.Eb(a, c, d[e]);
                else {
                    e = (0, _.q)(a.A, a, c);
                    var f = a.B + d;
                    a.B++;
                    c.setAttribute("data-eqid", f);
                    a.o[f] = e;
                    c && c.addEventListener ? c.addEventListener(d, e, !1) : c && c.attachEvent ? c.attachEvent("on" + d, e) : a.w.log(Error("e`" + c))
                }
        };
        Db.prototype.A = function(a, c) {
            this.b = c;
            this.j = a;
            c.preventDefault ? c.preventDefault() : c.returnValue = !1
        };
        _.Gb = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(_.Gb, _.z);
        _.Hb = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(_.Hb, _.z);
        _.G = function(a, c) {
            return null != a ? !!a : !!c
        };
        _.H = function(a, c) {
            void 0 == c && (c = "");
            return null != a ? a : c
        };
        _.Ib = function(a, c) {
            void 0 == c && (c = 0);
            return null != a ? a : c
        };
        var Jb, Mb, Lb;
        _.Kb = function(a) {
            var c = "//www.google.com/gen_204?",
                c = c + a.f(2040 - c.length);
            Jb(c)
        };
        Jb = function(a) {
            var c = new window.Image,
                d = Lb;
            c.onerror = c.onload = c.onabort = function() {
                d in Mb && delete Mb[d]
            };
            Mb[Lb++] = c;
            c.src = a
        };
        Mb = [];
        Lb = 0;
        var Nb = function(a) {
            this.b = a
        };
        Nb.prototype.log = function(a, c) {
            try {
                if (this.A(a)) {
                    var d = this.j(a, c);
                    this.f(d)
                }
            } catch (e) {}
        };
        Nb.prototype.f = function(a) {
            this.b ? a.b() : _.Kb(a)
        };
        _.Ob = function() {
            this.data = {}
        };
        _.Ob.prototype.b = function() {
            window.console && window.console.log && window.console.log("Log data: ", this.data)
        };
        _.Ob.prototype.f = function(a) {
            var c = [],
                d;
            for (d in this.data) c.push((0, window.encodeURIComponent)(d) + "=" + (0, window.encodeURIComponent)(String(this.data[d])));
            return ("atyp=i&zx=" + (new Date).getTime() + "&" + c.join("&")).substr(0, a)
        };
        var Pb = function(a, c) {
            this.data = {};
            var d = _.D(a, zb, 8) || new zb;
            this.data.ei = _.H(_.B(a, 10));
            this.data.ogf = _.H(_.B(d, 3));
            var e;
            e = window.google && window.google.sn ? /.*hp$/.test(window.google.sn) ? !1 : !0 : _.G(_.B(a, 7));
            this.data.ogrp = e ? "1" : "";
            this.data.ogv = _.H(_.B(d, 6)) + "." + _.H(_.B(d, 7));
            this.data.ogd = _.H(_.B(a, 21));
            this.data.ogc = _.H(_.B(a, 20));
            this.data.ogl = _.H(_.B(a, 5));
            c && (this.data.oggv = c)
        };
        _.v(Pb, _.Ob);
        _.Qb = function(a, c, d, e, f) {
            Pb.call(this, a, c);
            _.Ia(this.data, {
                jexpid: _.H(_.B(a, 9)),
                srcpg: "prop=" + _.H(_.B(a, 6)),
                jsr: Math.round(1 / e),
                emsg: d.name + ":" + d.message
            });
            if (f) {
                f._sn && (f._sn = "og." + f._sn);
                for (var g in f) this.data[(0, window.encodeURIComponent)(g)] = f[g]
            }
        };
        _.v(_.Qb, Pb);
        var Rb = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(Rb, _.z);
        _.Sb = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(_.Sb, _.z);
        var Yb;
        _.Tb = function() {
            this.b = {};
            this.f = {}
        };
        _.ma(_.Tb);
        _.Vb = function(a, c) {
            var d = _.Tb.Aa();
            if (a in d.b) {
                if (d.b[a] != c) throw new Ub;
            } else {
                d.b[a] = c;
                var e = d.f[a];
                if (e)
                    for (var f = 0, g = e.length; f < g; f++) e[f].b(d.b, a);
                delete d.f[a]
            }
        };
        _.Xb = function(a, c) {
            if (c in a.b) return a.b[c];
            throw new Wb;
        };
        Yb = function() {
            _.va.call(this)
        };
        _.v(Yb, _.va);
        var Ub = function() {
            _.va.call(this)
        };
        _.v(Ub, Yb);
        var Wb = function() {
            _.va.call(this)
        };
        _.v(Wb, Yb);
        var Zb = function(a, c, d, e) {
            this.b = e;
            this.Da = c;
            this.G = d;
            this.B = _.Ib(+_.C(a, 2, .001), .001);
            this.N = _.G(_.B(a, 1)) && Math.random() < this.B;
            this.C = _.Ib(_.C(a, 3, 1), 1);
            this.w = 0;
            this.o = null;
            this.F = _.G(_.C(a, 4, !0), !0)
        };
        _.v(Zb, Nb);
        Zb.prototype.log = function(a, c) {
            Zb.H.log.call(this, a, c);
            if (this.b && this.F) throw a;
        };
        Zb.prototype.A = function() {
            return this.b || this.N && this.w < this.C
        };
        Zb.prototype.j = function(a, c) {
            try {
                return (this.o || _.Xb(_.Tb.Aa(), "lm")).b(a, c)
            } catch (d) {
                return new _.Qb(this.Da, this.G, a, this.B, c)
            }
        };
        Zb.prototype.f = function(a) {
            Zb.H.f.call(this, a);
            this.w++
        };
        var $b = [1, 2, 3, 4, 5, 6, 9, 10, 11, 13, 14, 28, 29, 30, 34, 35, 37, 38, 39, 40, 41, 42, 43, 48, 49, 50, 51, 52, 53, 55, 56, 57, 58, 59, 500],
            bc = function(a, c, d, e, f, g) {
                Pb.call(this, a, c);
                _.Ia(this.data, {
                    oge: e,
                    ogex: _.H(_.B(a, 9)),
                    ogp: _.H(_.B(a, 6)),
                    ogsr: Math.round(1 / (ac(e) ? _.Ib(+_.C(d, 3, 1)) : _.Ib(+_.C(d, 2, 1E-4)))),
                    ogus: f
                });
                if (g) {
                    "ogw" in g && (this.data.ogw = g.ogw, delete g.ogw);
                    "ved" in g && (this.data.ved = g.ved, delete g.ved);
                    a = [];
                    for (var h in g) 0 != a.length && a.push(","), a.push((h + "").replace(".", "%2E").replace(",", "%2C")), a.push("."), a.push((g[h] + "").replace(".", "%2E").replace(",", "%2C"));
                    g = a.join("");
                    "" != g && (this.data.ogad = g)
                }
            };
        _.v(bc, Pb);
        var cc = null,
            ac = function(a) {
                if (!cc) {
                    cc = {};
                    for (var c = 0; c < $b.length; c++) cc[$b[c]] = !0
                }
                return !!cc[a]
            };
        var dc = function(a, c, d, e, f) {
            this.b = f;
            this.N = a;
            this.F = c;
            this.Da = e;
            this.C = _.Ib(+_.C(a, 2, 1E-4), 1E-4);
            this.w = _.Ib(+_.C(a, 3, 1), 1);
            c = Math.random();
            this.B = _.G(_.B(a, 1)) && c < this.C;
            this.o = _.G(_.B(a, 1)) && c < this.w;
            a = 0;
            _.G(_.B(d, 1)) && (a |= 1);
            _.G(_.B(d, 2)) && (a |= 2);
            _.G(_.B(d, 3)) && (a |= 4);
            this.G = a
        };
        _.v(dc, Nb);
        dc.prototype.A = function(a) {
            return this.b || (ac(a) ? this.o : this.B)
        };
        dc.prototype.j = function(a, c) {
            return new bc(this.F, this.Da, this.N, a, this.G, c)
        };
        var ec = function(a) {
            this.f = a;
            this.b = []
        };
        ec.prototype.then = function(a, c, d) {
            this.b.push(new fc(a, c, d));
            _.gc(this)
        };
        _.gc = function(a) {
            if (0 < a.b.length) {
                var c = void 0 !== a.f;
                if (c) {
                    c = c ? a.j : a.o;
                    try {
                        (0, _.Aa)(a.b, c, a)
                    } catch (d) {
                        window.console.error(d)
                    }
                    a.b = []
                }
            }
        };
        ec.prototype.j = function(a) {
            a.f && a.f.call(a.b, this.f)
        };
        ec.prototype.o = function(a) {
            a.j && a.j.call(a.b, void 0)
        };
        var fc = function(a, c, d) {
            this.f = a;
            this.j = c;
            this.b = d
        };
        _.hc = function() {
            this.f = new ec;
            this.b = new ec;
            this.w = new ec;
            this.j = new ec;
            this.o = new ec;
            this.B = new ec
        };
        _.ma(_.hc);
        _.k = _.hc.prototype;
        _.k.Pf = function() {
            return this.f
        };
        _.k.Vf = function() {
            return this.b
        };
        _.k.$f = function() {
            return this.w
        };
        _.k.Uf = function() {
            return this.j
        };
        _.k.Yf = function() {
            return this.o
        };
        _.k.ag = function() {
            return this.B
        };
        var ic = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(ic, _.z);
        _.kc = function() {
            return _.D(_.jc, _.Ab, 1)
        };
        _.lc = function() {
            return _.D(_.jc, _.Bb, 5)
        };
        var mc;
        window.gbar_ && window.gbar_.CONFIG ? mc = window.gbar_.CONFIG[0] || {} : mc = [];
        _.jc = new ic(mc);
        _.t("gbar_._DumpException", function(a) {
            if (this._D) throw a;
            _.I ? _.I.log(a) : window.console.error(a)
        });
        var nc, oc, pc, qc, rc;
        nc = _.D(_.jc, _.Sb, 3) || new _.Sb;
        oc = _.kc() || new _.Ab;
        _.I = new Zb(nc, oc, "quantum:gapiBuildLabel", !1);
        pc = _.kc() || new _.Ab;
        qc = _.lc() || new _.Bb;
        rc = _.D(_.jc, Rb, 4) || new Rb;
        _.sc = new dc(rc, pc, qc, "quantum:gapiBuildLabel", !1);
        _.tc = new Db(_.I);
        _.sc.log(8, {
            m: "BackCompat" == window.document.compatMode ? "q" : "s"
        });
        _.t("gbar.A", ec);
        ec.prototype.aa = ec.prototype.then;
        _.t("gbar.B", _.hc);
        _.hc.prototype.ba = _.hc.prototype.Vf;
        _.hc.prototype.bb = _.hc.prototype.$f;
        _.hc.prototype.bd = _.hc.prototype.Yf;
        _.hc.prototype.be = _.hc.prototype.ag;
        _.hc.prototype.bf = _.hc.prototype.Pf;
        _.hc.prototype.bg = _.hc.prototype.Uf;
        _.t("gbar.a", _.hc.Aa());
        var uc = new Cb(window);
        _.Vb("api", uc);
        var vc = _.lc() || new _.Bb,
            wc = _.H(_.B(vc, 8));
        window.__PVT = wc;
        _.Vb("eq", _.tc);

    } catch (e) {
        _._DumpException(e)
    }
    try {
        var xc;
        xc = function(a) {
            return _.y ? "webkit" + a : _.Pa ? "o" + a.toLowerCase() : a.toLowerCase()
        };
        _.yc = _.x ? "focusin" : "DOMFocusIn";
        _.zc = xc("AnimationEnd");
        _.Ac = xc("TransitionEnd");
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Bc = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(Bc, _.z);
        var Cc = function() {
            _.F.call(this);
            this.f = [];
            this.b = []
        };
        _.v(Cc, _.F);
        Cc.prototype.j = function(a, c) {
            this.f.push({
                Nc: a,
                options: c
            })
        };
        Cc.prototype.init = function(a, c, d) {
            window.gapi = {};
            var e = window.___jsl = {};
            e.h = _.H(_.B(a, 1));
            e.ms = _.H(_.B(a, 2));
            e.m = _.H(_.B(a, 3));
            e.l = [];
            _.B(c, 1) && (a = _.B(c, 3)) && this.b.push(a);
            _.B(d, 1) && (d = _.B(d, 2)) && this.b.push(d);
            _.t("gapi.load", (0, _.q)(this.j, this));
            return this
        };
        var Dc = _.D(_.jc, _.Gb, 14) || new _.Gb,
            Ec = _.H(_.B(Dc, 7));
        window.__PVT = Ec;
        var Fc = _.D(_.jc, _.Hb, 9) || new _.Hb,
            Gc = new Bc,
            Hc = new Cc;
        Hc.init(Dc, Fc, Gc);
        _.Vb("gs", Hc);
    } catch (e) {
        _._DumpException(e)
    }
})(this.gbar_);


                                var DEBUG = false;
                                if (!DEBUG) {
                                    if (!window.console) window.console = {};
                                    var methods = ["log", "debug", "warn", "info"];
                                    for (var i = 0; i < methods.length; i++) {
                                        console[methods[i]] = function() {};
                                    }
                                }
                                Function.prototype.bind || (Function.prototype.bind = function(a) {
                                    function b() {
                                        return e.apply(this instanceof c ? this : a, d.concat(Array.prototype.slice.call(arguments)))
                                    }

                                    function c() {}
                                    if ("function" !== typeof this) throw new TypeError("Function.prototype.bind - what is trying to be bound is not callable");
                                    var d = Array.prototype.slice.call(arguments, 1),
                                        e = this;
                                    c.prototype = this.prototype;
                                    b.prototype = new c;
                                    return b
                                });

                                function k() {
                                    return function() {}
                                }

                                function aa(a) {
                                    return function(b) {
                                        this[a] = b
                                    }
                                }

                                function m(a) {
                                    return function() {
                                        return this[a]
                                    }
                                }

                                function ba(a) {
                                    return function() {
                                        return a
                                    }
                                }
                                var q, ca = [];

                                function t(a) {
                                    return function() {
                                        return ca[a].apply(this, arguments)
                                    }
                                }

                                function u(a, b) {
                                    return ca[a] = b
                                }
                                var v = this;

                                function da(a, b) {
                                    for (var c = a.split("."), d = b || v, e; e = c.shift();)
                                        if (null != d[e]) d = d[e];
                                        else return null;
                                    return d
                                }

                                function ea() {}

                                function fa() {
                                    throw Error("unimplemented abstract method");
                                }

                                function ha(a) {
                                    var b = typeof a;
                                    if ("object" == b)
                                        if (a) {
                                            if (a instanceof Array) return "array";
                                            if (a instanceof Object) return b;
                                            var c = Object.prototype.toString.call(a);
                                            if ("[object Window]" == c) return "object";
                                            if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) return "array";
                                            if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) return "function"
                                        } else return "null";
                                    else if ("function" == b && "undefined" == typeof a.call) return "object";
                                    return b
                                }

                                function w(a) {
                                    return "string" == typeof a
                                }

                                function ia(a) {
                                    return "number" == typeof a
                                }

                                function ja(a) {
                                    return "function" == ha(a)
                                }

                                function ka(a, b, c) {
                                    return a.call.apply(a.bind, arguments)
                                }

                                function la(a, b, c) {
                                    if (!a) throw Error();
                                    if (2 < arguments.length) {
                                        var d = Array.prototype.slice.call(arguments, 2);
                                        return function() {
                                            var c = Array.prototype.slice.call(arguments);
                                            Array.prototype.unshift.apply(c, d);
                                            return a.apply(b, c)
                                        }
                                    }
                                    return function() {
                                        return a.apply(b, arguments)
                                    }
                                }

                                function x(a, b, c) {
                                    x = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? ka : la;
                                    return x.apply(null, arguments)
                                }

                                function ma(a, b) {
                                    var c = Array.prototype.slice.call(arguments, 1);
                                    return function() {
                                        var b = c.slice();
                                        b.push.apply(b, arguments);
                                        return a.apply(this, b)
                                    }
                                }
                                var y = Date.now || function() {
                                    return +new Date
                                };

                                function z(a, b) {
                                    var c = a.split("."),
                                        d = v;
                                    c[0] in d || !d.execScript || d.execScript("var " + c[0]);
                                    for (var e; c.length && (e = c.shift());) c.length || void 0 === b ? d[e] ? d = d[e] : d = d[e] = {} : d[e] = b
                                }

                                function A(a, b) {
                                    function c() {}
                                    c.prototype = b.prototype;
                                    a.wb = b.prototype;
                                    a.prototype = new c;
                                    a.prototype.constructor = a;
                                    a.Tg = function(a, c, f) {
                                        for (var d = Array(arguments.length - 2), e = 2; e < arguments.length; e++) d[e - 2] = arguments[e];
                                        return b.prototype[c].apply(a, d)
                                    }
                                };

                                function B(a, b, c) {
                                    var d = a.className ? a.className.split(" ") : [],
                                        e = -1 != d.indexOf(b),
                                        f = "undefined" == typeof c;
                                    !c && !f || e ? (!1 === c || f) && e && (d = d.filter(function(a) {
                                        return a != b
                                    })) : d.push(b);
                                    a.className = d.join(" ")
                                }

                                function C(a, b) {
                                    return -1 != a.className.split(" ").indexOf(b)
                                }

                                function na(a, b) {
                                    var c = (new RegExp("[?&]" + oa(encodeURIComponent(a)) + "=([^&]*)")).exec(b || D().query);
                                    return c ? decodeURIComponent(c[1]) : ""
                                }

                                function pa(a) {
                                    return (a = (new RegExp("[#&]" + oa(encodeURIComponent(a)) + "=([^&]*)")).exec(window.location.hash)) ? decodeURIComponent(a[1]) : ""
                                }

                                function qa(a, b) {
                                    var c = encodeURIComponent(a),
                                        d = encodeURIComponent(b),
                                        e = new RegExp("([#&]" + oa(c) + "=)([^&]*)"),
                                        c = e.test(window.location.hash) ? window.location.hash.replace(e, "$1" + d.replace("$", "$$")) : window.location.hash && "#" != window.location.hash ? window.location.hash + "&" + c + "=" + d : "#" + c + "=" + d;
                                    window.history.replaceState ? window.history.replaceState(null, "", c) : window.location.replace(c)
                                }

                                function ra(a) {
                                    a = oa(encodeURIComponent(a));
                                    a = new RegExp("(?:(#)|&)" + a + "=[^&]*$|([#&])" + a + "=[^&]*.");
                                    a.test(window.location.hash) && (a = window.location.hash.replace(a, "$1$2"), window.history.replaceState ? window.history.replaceState(null, "", a) : window.location.replace(a))
                                }

                                function oa(a) {
                                    return a.replace(/[-\/\\^$*+?.()|[\]{}]/g, "\\$&")
                                }

                                function sa(a) {
                                    var b = 0 > a.indexOf("?") ? "?" : "&",
                                        c = D().mendel_ids;
                                    c && c.length && (a += b + "mendel_ids=" + c.join(), b = "&");
                                    c = D();
                                    c.au && (a += b + "authuser=" + c.au);
                                    return a
                                }

                                function F(a) {
                                    var b = D(),
                                        c = b.ehn + "/" + (a.df || b.ehc) + "/apis/" + a.endpoint;
                                    a.params = a.params || {};
                                    a.params.key = a.Kd ? b.skey : b.key;
                                    a.params.rs = b.rs;
                                    var b = "",
                                        d;
                                    for (d in a.params)
                                        for (var e = Array.isArray(a.params[d]) ? a.params[d] : [a.params[d]], f = 0; f < e.length; ++f) b += (b ? "&" : "?") + encodeURIComponent(d) + "=" + encodeURIComponent(e[f]);
                                    c = sa(c + b);
                                    ta(c, a)
                                }

                                function ta(c, a) {}

                                function ua() {
                                    var a = D(),
                                        b = a.bcUrl;
                                    a.query && (b += a.query);
                                    return b + window.location.hash
                                }

                                function G(a, b, c) {
                                    var d = document.createEvent("Event");
                                    d.initEvent(b, !0, !0);
                                    c && (d.detail = c);
                                    a.dispatchEvent(d)
                                }
                                var va = [];

                                function H(a) {
                                    a = wa(a);
                                    for (var b = 0; b < va.length; b++) va[b](a);
                                    window.location = a.href
                                }

                                function xa(a) {
                                    var b = D();
                                    ya || (ya = wa(b.bcUrl));
                                    var c = a.getAttribute("href"),
                                        b = b ? b.legacy_url : null;
                                    return (0 == c.indexOf("http") || 0 == c.indexOf("//")) && (!b || -1 == c.indexOf(b)) && a.host != ya.host
                                }

                                function za(a) {
                                    a = a.getAttribute("href");
                                    return "#" == a[0] || 0 == a.indexOf("javascript:")
                                }

                                function wa(a) {
                                    var b = document.createElement("a");
                                    b.href = a;
                                    return b
                                }

                                function Aa(a) {
                                    return (a = /^\/([^/]+)/.exec(a.pathname)) ? a[1] : ""
                                }

                                function Ba(a) {
                                    G(document, a ? "sc_modalShow" : "sc_modalHide")
                                }

                                function D() {
                                    return window.sc_pageModel
                                }

                                function Ca() {
                                    return window.sc_scope || document
                                }

                                function Da() {
                                    var a = document.querySelector("#gb, .fixed-one-bar-placeholder");
                                    if (a && "fixed" == window.getComputedStyle(a).position) return a.offsetHeight
                                }
                                var ya, Ea = {
                                        id: 0,
                                        n: "unknown"
                                    },
                                    Fa = {
                                        id: 1,
                                        n: "homepage"
                                    },
                                    Ga = {
                                        id: 2,
                                        n: "zippy"
                                    },
                                    Ha = {
                                        id: 6,
                                        n: "hc survey"
                                    },
                                    Ia = {
                                        id: 8,
                                        n: "carousel"
                                    },
                                    Ja = {
                                        id: 10,
                                        n: "search"
                                    },
                                    Ka = {
                                        id: 11,
                                        n: "search results"
                                    },
                                    La = {
                                        id: 13,
                                        n: "proactive chat"
                                    },
                                    Ma = {
                                        id: 14,
                                        n: "contact flow"
                                    },
                                    Na = {
                                        id: 17,
                                        n: "contact flow deep link"
                                    },
                                    Oa = {
                                        id: 20,
                                        n: "article survey"
                                    },
                                    Pa = {
                                        id: 21,
                                        n: "contact form"
                                    },
                                    Qa = {
                                        id: 22,
                                        n: "recaptcha"
                                    },
                                    Ra = {
                                        id: 23,
                                        n: "portal"
                                    },
                                    Sa = {
                                        id: 25,
                                        n: "troubleshooter"
                                    },
                                    Ta = {
                                        id: 39,
                                        n: "screenshot"
                                    },
                                    Ua = {
                                        id: 40,
                                        n: "glossary"
                                    },
                                    Va = {
                                        id: 41,
                                        n: "page"
                                    },
                                    Wa = {
                                        id: 42,
                                        n: "appbar"
                                    },
                                    Xa = {
                                        id: 43,
                                        n: "dynamic_recommendation"
                                    },
                                    Ya = {
                                        id: 44,
                                        n: "video"
                                    },
                                    Za = {
                                        id: 48,
                                        n: "chat"
                                    },
                                    $a = {
                                        id: 49,
                                        n: "feedback"
                                    },
                                    ab = {
                                        id: 50,
                                        n: "forum thread"
                                    },
                                    bb = {
                                        id: 51,
                                        n: "forum message"
                                    },
                                    cb = {
                                        id: 52,
                                        n: "contact form c2c"
                                    },
                                    db = {
                                        id: 55,
                                        n: "forum overflow"
                                    },
                                    eb = {
                                        id: 56,
                                        n: "forum promoted messages"
                                    },
                                    fb = {
                                        b: Ea,
                                        zg: Fa,
                                        Eh: Ga,
                                        Sg: {
                                            id: 3,
                                            n: "sibling nav"
                                        },
                                        wh: {
                                            id: 4,
                                            n: "top nav"
                                        },
                                        Mg: {
                                            id: 5,
                                            n: "promotion"
                                        },
                                        Bc: Ha,
                                        Bg: {
                                            id: 7,
                                            n: "notification"
                                        },
                                        w: Ia,
                                        u: {
                                            id: 9,
                                            n: "breadcrumbs"
                                        },
                                        Qg: Ja,
                                        Rg: Ka,
                                        yg: {
                                            id: 12,
                                            n: "search results nav"
                                        },
                                        Jg: La,
                                        T: Ma,
                                        W: {
                                            id: 15,
                                            n: "contact flow issues"
                                        },
                                        ha: {
                                            id: 16,
                                            n: "contact flow login"
                                        },
                                        U: Na,
                                        Ta: {
                                            id: 18,
                                            n: "footer"
                                        },
                                        Ba: {
                                            id: 19,
                                            n: "context selector"
                                        },
                                        s: Oa,
                                        ra: Pa,
                                        Ng: Qa,
                                        Fg: Ra,
                                        uh: {
                                            id: 24,
                                            n: "topic"
                                        },
                                        zh: Sa,
                                        nh: {
                                            id: 26,
                                            n: "suggestions"
                                        },
                                        Ag: {
                                            id: 27,
                                            n: "known issues"
                                        },
                                        R: {
                                            id: 28,
                                            n: "checklist"
                                        },
                                        Ha: {
                                            id: 29,
                                            n: "faq"
                                        },
                                        Oa: {
                                            id: 30,
                                            n: "faq toc"
                                        },
                                        Ia: {
                                            id: 31,
                                            n: "faq questions"
                                        },
                                        i: {
                                            id: 32,
                                            n: "appbar"
                                        },
                                        S: {
                                            id: 33,
                                            n: "community button"
                                        },
                                        Eg: {
                                            id: 34,
                                            n: "policy"
                                        },
                                        g: {
                                            id: 35,
                                            n: "answer"
                                        },
                                        Kg: {
                                            id: 36,
                                            n: "product button"
                                        },
                                        Og: {
                                            id: 37,
                                            n: "related items"
                                        },
                                        yh: {
                                            id: 38,
                                            n: "translate"
                                        },
                                        Pg: Ta,
                                        zc: Ua,
                                        Dg: Va,
                                        o: Wa,
                                        Ca: Xa,
                                        VIDEO: Ya,
                                        Lg: {
                                            id: 45,
                                            n: "product selector"
                                        },
                                        Ac: {
                                            id: 46,
                                            n: "guide"
                                        },
                                        qa: {
                                            id: 47,
                                            n: "contact flow recommendation"
                                        },
                                        H: Za,
                                        Pa: $a,
                                        yc: ab,
                                        hb: bb,
                                        Aa: cb,
                                        kb: db,
                                        Ab: eb,
                                        Cg: {
                                            id: 57,
                                            n: "one bar"
                                        },
                                        V: {
                                            id: 58,
                                            n: "contact flow deep link inline"
                                        }
                                    },
                                    gb = {
                                        id: 0,
                                        n: "unknown"
                                    },
                                    hb = {
                                        id: 1,
                                        n: "view"
                                    },
                                    I = {
                                        id: 2,
                                        n: "expand"
                                    },
                                    ib = {
                                        id: 3,
                                        n: "collapse"
                                    },
                                    J = {
                                        id: 4,
                                        n: "show"
                                    },
                                    jb = {
                                        id: 5,
                                        n: "hide"
                                    },
                                    kb = {
                                        id: 6,
                                        n: "next"
                                    },
                                    lb = {
                                        id: 7,
                                        n: "previous"
                                    },
                                    mb = {
                                        id: 8,
                                        n: "select"
                                    },
                                    nb = {
                                        id: 9,
                                        n: "dismiss"
                                    },
                                    ob = {
                                        id: 10,
                                        n: "accept"
                                    },
                                    pb = {
                                        id: 11,
                                        n: "rejected"
                                    },
                                    qb = {
                                        id: 12,
                                        n: "suggested"
                                    },
                                    rb = {
                                        id: 14,
                                        n: "answered"
                                    },
                                    sb = {
                                        id: 15,
                                        n: "completed"
                                    },
                                    tb = {
                                        id: 17,
                                        n: "invalidated"
                                    },
                                    ub = {
                                        id: 18,
                                        n: "start"
                                    },
                                    vb = {
                                        id: 19,
                                        n: "end"
                                    },
                                    wb = {
                                        id: 20,
                                        n: "initialized"
                                    },
                                    xb = {
                                        id: 21,
                                        n: "error"
                                    },
                                    yb = {
                                        id: 22,
                                        n: "submit"
                                    },
                                    zb = {
                                        id: 23,
                                        n: "auto complete"
                                    },
                                    Ab = {
                                        id: 24,
                                        n: "edit"
                                    },
                                    Bb = {
                                        id: 25,
                                        n: "play"
                                    },
                                    Cb = {
                                        id: 26,
                                        n: "pause"
                                    },
                                    Db = {
                                        id: 27,
                                        n: "buffer"
                                    },
                                    Eb = {
                                        id: 28,
                                        n: "cue"
                                    },
                                    Fb = {
                                        b: gb,
                                        kb: hb,
                                        V: I,
                                        w: ib,
                                        Ia: J,
                                        W: jb,
                                        NEXT: kb,
                                        Ba: lb,
                                        Ha: mb,
                                        S: nb,
                                        g: ob,
                                        Ca: pb,
                                        Ta: qb,
                                        u: {
                                            id: 13,
                                            n: "categorized"
                                        },
                                        i: rb,
                                        H: sb,
                                        hb: {
                                            id: 16,
                                            n: "validated"
                                        },
                                        qa: tb,
                                        Oa: ub,
                                        U: vb,
                                        ha: wb,
                                        ERROR: xb,
                                        Pa: yb,
                                        o: zb,
                                        T: Ab,
                                        Aa: Bb,
                                        ra: Cb,
                                        s: Db,
                                        R: Eb
                                    };

                                function Gb(a) {
                                    this.b = [];
                                    this.g = [];
                                    a = Hb.exec(a);
                                    this.i = a[1];
                                    a[2] && (this.b = Ib(a[2]));
                                    a[3] && (this.g = Ib(a[3]))
                                }
                                var Hb = /^([^?#]*)(?:\?([^#]*))?(?:#(.*))?$/;

                                function Ib(a) {
                                    var b = [];
                                    a = a.split("&");
                                    for (var c = 0; c < a.length; c++) {
                                        var d = a[c].split("=");
                                        b.push({
                                            key: decodeURIComponent(d[0]),
                                            value: d[1] ? decodeURIComponent(d[1]) : ""
                                        })
                                    }
                                    return b
                                }

                                function K(a, b, c) {
                                    a: {
                                        for (var d = a.b, e = 0; e < d.length; e++) {
                                            var f = d[e];
                                            if (f.key == b) {
                                                f.value = c;
                                                c = d;
                                                for (e = e + 1 || 0; e < c.length;) c[e].key == b ? c.splice(e, 1) : e++;
                                                break a
                                            }
                                        }
                                        d.push({
                                            key: b,
                                            value: c
                                        })
                                    }
                                    return a
                                }
                                Gb.prototype.toString = function() {
                                    var a = this.i;
                                    0 < this.b.length && (a += "?" + Jb(this.b));
                                    0 < this.g.length && (a += "#" + Jb(this.g));
                                    return a
                                };

                                function Jb(a) {
                                    for (var b = "", c = 0; c < a.length; c++) {
                                        b && (b += "&");
                                        var d = a[c],
                                            b = b + encodeURIComponent(d.key);
                                        d.value && (b += "=" + encodeURIComponent(d.value))
                                    }
                                    return b
                                };
                                var Kb = String.prototype.trim ? function(a) {
                                    return a.trim()
                                } : function(a) {
                                    return a.replace(/^[\s\xa0]+|[\s\xa0]+$/g, "")
                                };

                                function Lb() {
                                    return -1 != Mb.toLowerCase().indexOf("webkit")
                                }

                                function Nb(a, b) {
                                    for (var c = 0, d = Kb(String(a)).split("."), e = Kb(String(b)).split("."), f = Math.max(d.length, e.length), g = 0; 0 == c && g < f; g++) {
                                        var h = d[g] || "",
                                            l = e[g] || "";
                                        do {
                                            h = /(\d*)(\D*)(.*)/.exec(h) || ["", "", "", ""];
                                            l = /(\d*)(\D*)(.*)/.exec(l) || ["", "", "", ""];
                                            if (0 == h[0].length && 0 == l[0].length) break;
                                            c = Ob(0 == h[1].length ? 0 : parseInt(h[1], 10), 0 == l[1].length ? 0 : parseInt(l[1], 10)) || Ob(0 == h[2].length, 0 == l[2].length) || Ob(h[2], l[2]);
                                            h = h[3];
                                            l = l[3]
                                        } while (0 == c)
                                    }
                                    return c
                                }

                                function Ob(a, b) {
                                    return a < b ? -1 : a > b ? 1 : 0
                                };
                                var Pb = "closure_listenable_" + (1E6 * Math.random() | 0),
                                    Qb = 0;

                                function Rb(a) {
                                    return /^\s*$/.test(a) ? !1 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))
                                }

                                function Sb(a) {
                                    a = String(a);
                                    if (Rb(a)) try {
                                        return eval("(" + a + ")")
                                    } catch (b) {}
                                    throw Error("Invalid JSON string: " + a);
                                };
                                var Tb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

                                function Ub(a, b) {
                                    for (var c, d, e = 1; e < arguments.length; e++) {
                                        d = arguments[e];
                                        for (c in d) a[c] = d[c];
                                        for (var f = 0; f < Tb.length; f++) c = Tb[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
                                    }
                                };

                                function Vb(a) {
                                    Vb[" "](a);
                                    return a
                                }
                                Vb[" "] = ea;

                                function Wb(a, b) {
                                    var c = Xb;
                                    return Object.prototype.hasOwnProperty.call(c, a) ? c[a] : c[a] = b(a)
                                };

                                function Yb() {
                                    this.g = this.g;
                                    this.i = this.i
                                }
                                Yb.prototype.g = !1;
                                Yb.prototype.o = t(0);
                                Yb.prototype.mb = t(2);
                                var Mb;
                                a: {
                                    var Zb = v.navigator;
                                    if (Zb) {
                                        var $b = Zb.userAgent;
                                        if ($b) {
                                            Mb = $b;
                                            break a
                                        }
                                    }
                                    Mb = ""
                                }

                                function L(a) {
                                    return -1 != Mb.indexOf(a)
                                };
                                var ac = Array.prototype.indexOf ? function(a, b, c) {
                                        return Array.prototype.indexOf.call(a, b, c)
                                    } : function(a, b, c) {
                                        c = null == c ? 0 : 0 > c ? Math.max(0, a.length + c) : c;
                                        if (w(a)) return w(b) && 1 == b.length ? a.indexOf(b, c) : -1;
                                        for (; c < a.length; c++)
                                            if (c in a && a[c] === b) return c;
                                        return -1
                                    },
                                    bc = Array.prototype.forEach ? function(a, b, c) {
                                        Array.prototype.forEach.call(a, b, c)
                                    } : function(a, b, c) {
                                        for (var d = a.length, e = w(a) ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c, e[f], f, a)
                                    },
                                    cc = Array.prototype.filter ? function(a, b, c) {
                                        return Array.prototype.filter.call(a, b, c)
                                    } : function(a, b, c) {
                                        for (var d = a.length, e = [], f = 0, g = w(a) ? a.split("") : a, h = 0; h < d; h++)
                                            if (h in g) {
                                                var l = g[h];
                                                b.call(c, l, h, a) && (e[f++] = l)
                                            }
                                        return e
                                    },
                                    dc = Array.prototype.map ? function(a, b, c) {
                                        return Array.prototype.map.call(a, b, c)
                                    } : function(a, b, c) {
                                        for (var d = a.length, e = Array(d), f = w(a) ? a.split("") : a, g = 0; g < d; g++) g in f && (e[g] = b.call(c, f[g], g, a));
                                        return e
                                    },
                                    ec = Array.prototype.some ? function(a, b, c) {
                                        return Array.prototype.some.call(a, b, c)
                                    } : function(a, b, c) {
                                        for (var d = a.length, e = w(a) ? a.split("") : a, f = 0; f < d; f++)
                                            if (f in e && b.call(c, e[f], f, a)) return !0;
                                        return !1
                                    };

                                function fc(a, b) {
                                    this.type = a;
                                    this.b = this.target = b;
                                    this.g = !1;
                                    this.rd = !0
                                }
                                fc.prototype.stopPropagation = function() {
                                    this.g = !0
                                };
                                fc.prototype.preventDefault = function() {
                                    this.rd = !1
                                };

                                function gc(a, b, c, d, e) {
                                    this.listener = a;
                                    this.b = null;
                                    this.src = b;
                                    this.type = c;
                                    this.Db = !!d;
                                    this.Jb = e;
                                    this.key = ++Qb;
                                    this.Ya = this.Cb = !1
                                }

                                function hc(a) {
                                    a.Ya = !0;
                                    a.listener = null;
                                    a.b = null;
                                    a.src = null;
                                    a.Jb = null
                                };

                                function ic(a) {
                                    this.src = a;
                                    this.b = {};
                                    this.g = 0
                                }

                                function jc(a, b, c, d, e) {
                                    var f = b.toString();
                                    b = a.b[f];
                                    b || (b = a.b[f] = [], a.g++);
                                    var g = kc(b, c, d, e); - 1 < g ? (a = b[g], a.Cb = !1) : (a = new gc(c, a.src, f, !!d, e), a.Cb = !1, b.push(a));
                                    return a
                                }

                                function lc(a, b) {
                                    var c = b.type;
                                    if (!(c in a.b)) return !1;
                                    var d = a.b[c],
                                        e = ac(d, b),
                                        f;
                                    (f = 0 <= e) && Array.prototype.splice.call(d, e, 1);
                                    f && (hc(b), 0 == a.b[c].length && (delete a.b[c], a.g--));
                                    return f
                                }

                                function kc(a, b, c, d) {
                                    for (var e = 0; e < a.length; ++e) {
                                        var f = a[e];
                                        if (!f.Ya && f.listener == b && f.Db == !!c && f.Jb == d) return e
                                    }
                                    return -1
                                };

                                function mc() {
                                    return L("Trident") || L("MSIE")
                                };

                                function nc() {
                                    return L("Gecko") && !(Lb() && !L("Edge")) && !(L("Trident") || L("MSIE")) && !L("Edge")
                                };
                                var oc = L("Opera"),
                                    M = mc(),
                                    pc = L("Edge"),
                                    qc = nc(),
                                    rc = Lb() && !L("Edge");

                                function sc() {
                                    var a = v.document;
                                    return a ? a.documentMode : void 0
                                }
                                var tc;
                                a: {
                                    var uc = "",
                                        vc = function() {
                                            var a = Mb;
                                            if (qc) return /rv\:([^\);]+)(\)|;)/.exec(a);
                                            if (pc) return /Edge\/([\d\.]+)/.exec(a);
                                            if (M) return /\b(?:MSIE|rv)[:]([^\);]+)(\)|;)/.exec(a);
                                            if (rc) return /WebKit\/(\S+)/.exec(a);
                                            if (oc) return /(?:Version)[ \/]?(\S+)/.exec(a)
                                        }();vc && (uc = vc ? vc[1] : "");
                                    if (M) {
                                        var wc = sc();
                                        if (null != wc && wc > parseFloat(uc)) {
                                            tc = String(wc);
                                            break a
                                        }
                                    }
                                    tc = uc
                                }
                                var xc = tc,
                                    Xb = {};

                                function N(a) {
                                    return Wb(a, function() {
                                        return 0 <= Nb(xc, a)
                                    })
                                }
                                var yc;
                                var zc = v.document;
                                yc = zc && M ? sc() || ("CSS1Compat" == zc.compatMode ? parseInt(xc, 10) : 5) : void 0;
                                !qc && !M || M && 9 <= Number(yc) || qc && N("1.9.1");
                                M && N("9");
                                var Ac = !M || 9 <= Number(yc),
                                    Bc = M && !N("9");
                                !rc || N("528");
                                qc && N("1.9b") || M && N("8") || oc && N("9.5") || rc && N("528");
                                qc && !N("8") || M && N("9");

                                function Cc(a, b) {
                                    fc.call(this, a ? a.type : "");
                                    this.b = this.target = null;
                                    this.keyCode = this.button = 0;
                                    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
                                    this.i = null;
                                    a && this.init(a, b)
                                }
                                A(Cc, fc);
                                Cc.prototype.init = function(a, b) {
                                    this.type = a.type;
                                    this.target = a.target || a.srcElement;
                                    this.b = b;
                                    var c = a.relatedTarget;
                                    if (c && qc) try {
                                        Vb(c.nodeName)
                                    } catch (d) {}
                                    this.button = a.button;
                                    this.keyCode = a.keyCode || 0;
                                    this.ctrlKey = a.ctrlKey;
                                    this.altKey = a.altKey;
                                    this.shiftKey = a.shiftKey;
                                    this.metaKey = a.metaKey;
                                    this.i = a;
                                    a.defaultPrevented && this.preventDefault()
                                };
                                Cc.prototype.stopPropagation = function() {
                                    Cc.wb.stopPropagation.call(this);
                                    this.i.stopPropagation ? this.i.stopPropagation() : this.i.cancelBubble = !0
                                };
                                Cc.prototype.preventDefault = function() {
                                    Cc.wb.preventDefault.call(this);
                                    var a = this.i;
                                    if (a.preventDefault) a.preventDefault();
                                    else if (a.returnValue = !1, Bc) try {
                                        if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
                                    } catch (b) {}
                                };
                                var Dc = "closure_lm_" + (1E6 * Math.random() | 0),
                                    Ec = {},
                                    Fc = 0;

                                function Gc(a, b, c, d, e) {
                                    if ("array" == ha(b))
                                        for (var f = 0; f < b.length; f++) Gc(a, b[f], c, d, e);
                                    else if (c = Hc(c), a && a[Pb]) a.Oc(b, c, d, e);
                                    else {
                                        if (!b) throw Error("Invalid event type");
                                        var f = !!d,
                                            g = Ic(a);
                                        g || (a[Dc] = g = new ic(a));
                                        c = jc(g, b, c, d, e);
                                        if (!c.b) {
                                            d = Jc();
                                            c.b = d;
                                            d.src = a;
                                            d.listener = c;
                                            if (a.addEventListener) a.addEventListener(b.toString(), d, f);
                                            else if (a.attachEvent) a.attachEvent(Kc(b.toString()), d);
                                            else throw Error("addEventListener and attachEvent are unavailable.");
                                            Fc++
                                        }
                                    }
                                }

                                function Jc() {
                                    var a = Lc,
                                        b = Ac ? function(c) {
                                            return a.call(b.src, b.listener, c)
                                        } : function(c) {
                                            c = a.call(b.src, b.listener, c);
                                            if (!c) return c
                                        };
                                    return b
                                }

                                function Mc(a, b, c, d, e) {
                                    if ("array" == ha(b))
                                        for (var f = 0; f < b.length; f++) Mc(a, b[f], c, d, e);
                                    else(c = Hc(c), a && a[Pb]) ? a.Pc(b, c, d, e) : a && (a = Ic(a)) && (b = a.b[b.toString()], a = -1, b && (a = kc(b, c, !!d, e)), (c = -1 < a ? b[a] : null) && Nc(c))
                                }

                                function Nc(a) {
                                    if (!ia(a) && a && !a.Ya) {
                                        var b = a.src;
                                        if (b && b[Pb]) b.wc(a);
                                        else {
                                            var c = a.type,
                                                d = a.b;
                                            b.removeEventListener ? b.removeEventListener(c, d, a.Db) : b.detachEvent && b.detachEvent(Kc(c), d);
                                            Fc--;
                                            (c = Ic(b)) ? (lc(c, a), 0 == c.g && (c.src = null, b[Dc] = null)) : hc(a)
                                        }
                                    }
                                }

                                function Kc(a) {
                                    return a in Ec ? Ec[a] : Ec[a] = "on" + a
                                }

                                function Oc(a, b, c, d) {
                                    var e = !0;
                                    if (a = Ic(a))
                                        if (b = a.b[b.toString()])
                                            for (b = b.concat(), a = 0; a < b.length; a++) {
                                                var f = b[a];
                                                f && f.Db == c && !f.Ya && (f = Pc(f, d), e = e && !1 !== f)
                                            }
                                        return e
                                }

                                function Pc(a, b) {
                                    var c = a.listener,
                                        d = a.Jb || a.src;
                                    a.Cb && Nc(a);
                                    return c.call(d, b)
                                }

                                function Lc(a, b) {
                                    if (a.Ya) return !0;
                                    if (!Ac) {
                                        var c = b || da("window.event"),
                                            d = new Cc(c, this),
                                            e = !0;
                                        if (!(0 > c.keyCode || void 0 != c.returnValue)) {
                                            a: {
                                                var f = !1;
                                                if (0 == c.keyCode) try {
                                                    c.keyCode = -1;
                                                    break a
                                                } catch (l) {
                                                    f = !0
                                                }
                                                if (f || void 0 == c.returnValue) c.returnValue = !0
                                            }
                                            c = [];
                                            for (f = d.b; f; f = f.parentNode) c.push(f);
                                            for (var f = a.type, g = c.length - 1; !d.g && 0 <= g; g--) {
                                                d.b = c[g];
                                                var h = Oc(c[g], f, !0, d),
                                                    e = e && h
                                            }
                                            for (g = 0; !d.g && g < c.length; g++) d.b = c[g],
                                            h = Oc(c[g], f, !1, d),
                                            e = e && h
                                        }
                                        return e
                                    }
                                    return Pc(a, new Cc(b, this))
                                }

                                function Ic(a) {
                                    a = a[Dc];
                                    return a instanceof ic ? a : null
                                }
                                var Qc = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);

                                function Hc(a) {
                                    if (ja(a)) return a;
                                    a[Qc] || (a[Qc] = function(b) {
                                        return a.handleEvent(b)
                                    });
                                    return a[Qc]
                                };

                                function O() {
                                    Yb.call(this);
                                    this.b = new ic(this);
                                    this.u = this;
                                    this.s = null
                                }
                                A(O, Yb);
                                O.prototype[Pb] = !0;
                                q = O.prototype;
                                q.rb = t(4);
                                q.addEventListener = function(a, b, c, d) {
                                    Gc(this, a, b, c, d)
                                };
                                q.removeEventListener = function(a, b, c, d) {
                                    Mc(this, a, b, c, d)
                                };
                                q.Wa = t(6);
                                q.mb = t(1);
                                q.Oc = function(a, b, c, d) {
                                    return jc(this.b, String(a), b, c, d)
                                };
                                q.Pc = function(a, b, c, d) {
                                    var e;
                                    e = this.b;
                                    a = String(a).toString();
                                    if (a in e.b) {
                                        var f = e.b[a];
                                        b = kc(f, b, c, d); - 1 < b ? (hc(f[b]), Array.prototype.splice.call(f, b, 1), 0 == f.length && (delete e.b[a], e.g--), e = !0) : e = !1
                                    } else e = !1;
                                    return e
                                };
                                q.wc = function(a) {
                                    return lc(this.b, a)
                                };
                                q.Mb = t(10);
                                q.Qa = t(8);

                                function Rc(a) {
                                    this.b = a
                                };

                                function Sc(a, b) {
                                    this.b = a;
                                    this.g = b
                                }
                                A(Sc, Rc);
                                Sc.prototype.then = function(a, b, c) {
                                    var d;
                                    a && (d = Tc(this, a));
                                    this.b.aa(d, b, c)
                                };

                                function Tc(a, b) {
                                    var c = a.g;
                                    return function(a) {
                                        b.call(this, new c(a))
                                    }
                                };

                                function Uc(a) {
                                    this.b = a
                                }
                                A(Uc, Rc);
                                Uc.prototype.ma = function() {
                                    return this.b.xa
                                };

                                function Vc(a) {
                                    this.b = a
                                }
                                A(Vc, Rc);
                                Vc.prototype[Pb] = !0;
                                q = Vc.prototype;
                                q.Oc = function(a, b, c, d) {
                                    return this.b.za(a, function(a) {
                                        return b.call(d || v, new Uc(a))
                                    }, c)
                                };
                                q.Pc = function() {
                                    throw Error("Not implemented.");
                                };
                                q.wc = function() {
                                    throw Error("Not implemented.");
                                };
                                q.Wa = t(5);
                                q.Mb = t(9);
                                q.rb = t(3);
                                q.Qa = t(7);

                                function Wc(a) {
                                    this.b = a
                                }
                                A(Wc, Vc);

                                function Xc(a) {
                                    this.b = a || gbar.a;
                                    this.g = null
                                }
                                A(Xc, Rc);
                                Xc.Yb = function() {
                                    return Xc.b ? Xc.b : Xc.b = new Xc
                                };

                                function Yc() {
                                    var a = Xc.Yb();
                                    a.g || (a.g = new Sc(a.b.bb(), Wc));
                                    return a.g
                                };

                                function Zc() {}
                                Zc.prototype.init = function() {
                                    Yc().then(function(a) {
                                        var b = a.b.gj();
                                        b.addEventListener("submit", function(a) {
                                            a.preventDefault();
                                            if (a = b.elements.q.value) window.sc_trackStatsEvent(Ja, yb, a), H(K(new Gb(b.action), "q", a).toString())
                                        })
                                    })
                                };
                                z("hcfe.SearchMaterialOneBar", Zc);

                                function $c(a) {
                                    this.b = a;
                                    this.g = []
                                }
                                var ad = !1,
                                    bd = {},
                                    cd = {};
                                $c.prototype.init = function() {
                                    dd(this);
                                    this.b.visit_id || (this.b.visit_id = window.sc_visit_id);
                                    if (!ad) {
                                        var a = document.getElementsByTagName("body")[0],
                                            b = this.o.bind(this);
                                        a.addEventListener("click", b);
                                        ad = !0;
                                        document.addEventListener("pjaxunload", function() {
                                            a.removeEventListener("click", b);
                                            ad = !1
                                        })
                                    }
                                    ed();
                                    fd(this)
                                };
                                $c.prototype.i = function(a) {
                                    for (var b = 0; b < a.length; b++) this.g.push(a[b])
                                };
                                $c.prototype.o = function(a) {
                                    for (var b = 1 !== a.target.nodeType ? a.target.parentNode : a.target, c = !1, d = !1, e = "", f = !1; b && b.getAttribute;) {
                                        var g = b.getAttribute("href");
                                        if ("A" === b.nodeName && g) {
                                            f = "_blank" == b.target || a.ctrlKey || a.shiftKey || a.metaKey || 1 == a.button;
                                            xa(b) ? c = !0 : za(b) || (d = !0, e = Aa(b));
                                            break
                                        } else b = b.parentNode
                                    }
                                    a = {
                                        event: a,
                                        element: b,
                                        blank: f,
                                        external: c,
                                        hc_internal: d,
                                        href: g,
                                        target_hc: e
                                    };
                                    window.sc_visitManagerProcessClick(a);
                                    for (b = 0; b < this.g.length; b++) this.g[b](a)
                                };

                                function ed() {
                                    for (var a = (window.sc_scope || document).querySelectorAll("select"), b = 0; b < a.length; b++) {
                                        var c = a[b];
                                        c.addEventListener("mousedown", function() {
                                            Ba(!0)
                                        });
                                        c.addEventListener("change", function() {
                                            Ba(!1)
                                        })
                                    }
                                }

                                function dd(a) {
                                    var b = [];
                                    if (window.localStorage) try {
                                        var c = window.localStorage;
                                        c.setItem("__storage_test__", "__storage_test__");
                                        c.removeItem("__storage_test__")
                                    } catch (d) {
                                        b.push(2)
                                    } else b.push(1);
                                    navigator.cookieEnabled || b.push(3);
                                    0 < b.length && (a.b.request_attributes = b)
                                }

                                function fd(a) {
                                    a.i([function(a) {
                                        a.href && "#" == a.href[0] && gd(a.href.substring(1)) && a.event.preventDefault()
                                    }.bind(a)]);
                                    window.addEventListener("hashchange", function(a) {
                                        gd(window.location.hash.substring(1)) && a.preventDefault()
                                    }.bind(a));
                                    window.addEventListener("load", function() {
                                        gd(window.location.hash.substring(1))
                                    }.bind(a))
                                }

                                function gd(a) {
                                    a = document.getElementById(a) || document.getElementsByName(a)[0];
                                    if (!a) return !1;
                                    var b = Da();
                                    if (!b) return !1;
                                    window.scroll(0, window.pageYOffset + a.getBoundingClientRect().top - b);
                                    return !0
                                }
                                window.sc_initPage = function(a) {
                                    a = new $c(a);
                                    a.init();
                                    if (1 == window.sc_refresh) {
                                        var b;
                                        window.sc_pageModel && (b = window.sc_pageModel.iro);
                                        window.sc_pageModel = a.b;
                                        b && (window.sc_pageModel.iro = b);
                                        window.sc_registerPageClickHandlers = a.i.bind(a)
                                    }
                                };
                                z("hcfe.Page", $c);
                                z("hcfe.Page.setData", function(a, b) {
                                    bd[a] = b
                                });
                                z("hcfe.Page.getData", function(a) {
                                    return bd[a]
                                });
                                z("hcfe.Page.setString", function(a, b) {
                                    cd[a] = b
                                });
                                z("hcfe.Page.getString", function(a) {
                                    return cd[a]
                                });

this.gbar_ = this.gbar_ || {};
(function(_) {
    var window = this;
    try {
        var Ic = window.document.querySelector(".gb_ea .gb_b");
        Ic && _.Eb(_.tc, Ic, "click");
    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.Jc = function(a, c) {
            var d = Array.prototype.slice.call(arguments, 1);
            return function() {
                var c = d.slice();
                c.push.apply(c, arguments);
                return a.apply(this, c)
            }
        };
        _.Kc = function(a) {
            var c = a.length;
            if (0 < c) {
                for (var d = Array(c), e = 0; e < c; e++) d[e] = a[e];
                return d
            }
            return []
        };
        _.Lc = function(a) {
            var c = typeof a;
            return "object" == c && null != a || "function" == c
        };

    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.Mc = function(a) {
            var c = [],
                d = 0,
                e;
            for (e in a) c[d++] = a[e];
            return c
        };
        _.Nc = function(a) {
            var c = _.na(a);
            return "array" == c || "object" == c && "number" == typeof a.length
        };
        _.Oc = !_.x || _.eb(9);
        _.Pc = !_.Sa && !_.x || _.x && _.eb(9) || _.Sa && _.cb("1.9.1");
        _.Qc = _.x && !_.cb("9");
        _.Rc = _.x || _.Pa || _.y;
        _.Tc = function() {
            this.b = "";
            this.f = _.Sc
        };
        _.Tc.prototype.Mb = !0;
        _.Tc.prototype.Ab = function() {
            return this.b
        };
        _.Tc.prototype.toString = function() {
            return "Const{" + this.b + "}"
        };
        _.Sc = {};
        _.Uc = function(a) {
            var c = new _.Tc;
            c.b = a;
            return c
        };
        _.Uc("");
        _.Wc = function() {
            this.b = "";
            this.f = _.Vc
        };
        _.Wc.prototype.Mb = !0;
        _.Vc = {};
        _.Wc.prototype.Ab = function() {
            return this.b
        };
        _.Xc = function(a) {
            var c = new _.Wc;
            c.b = a;
            return c
        };
        _.Yc = _.Xc("");
        _.$c = function() {
            this.b = "";
            this.f = _.Zc
        };
        _.$c.prototype.Mb = !0;
        _.$c.prototype.Ab = function() {
            return this.b
        };
        _.$c.prototype.Md = !0;
        _.$c.prototype.Yb = function() {
            return 1
        };
        _.Zc = {};
        _.ad = function(a) {
            var c = new _.$c;
            c.b = a;
            return c
        };
        _.ad("about:blank");
        var bd;
        _.cd = function() {
            this.b = "";
            this.f = bd
        };
        _.cd.prototype.Mb = !0;
        _.cd.prototype.Ab = function() {
            return this.b
        };
        _.cd.prototype.Md = !0;
        _.cd.prototype.Yb = function() {
            return 1
        };
        _.dd = function(a) {
            if (a instanceof _.cd && a.constructor === _.cd && a.f === bd) return a.b;
            _.na(a);
            return "type_error:TrustedResourceUrl"
        };
        bd = {};
        _.ed = function(a) {
            var c = new _.cd;
            c.b = a;
            return c
        };
        _.gd = function() {
            this.b = "";
            this.j = _.fd;
            this.f = null
        };
        _.gd.prototype.Md = !0;
        _.gd.prototype.Yb = function() {
            return this.f
        };
        _.gd.prototype.Mb = !0;
        _.gd.prototype.Ab = function() {
            return this.b
        };
        _.fd = {};
        _.hd = function(a, c) {
            var d = new _.gd;
            d.b = a;
            d.f = c;
            return d
        };
        _.hd("<!DOCTYPE html>", 0);
        _.id = _.hd("", 0);
        _.jd = _.hd("<br>", 0);
        _.kd = function(a, c) {
            return _.n(c) ? a.getElementById(c) : c
        };
        _.ld = function(a, c) {
            return (c || window.document).getElementsByTagName(String(a))
        };
        _.md = function(a, c) {
            return a.createElement(String(c))
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var nd = function(a) {
                var c = arguments.length;
                if (1 == c && _.oa(arguments[0])) return nd.apply(null, arguments[0]);
                for (var d = {}, e = 0; e < c; e++) d[arguments[e]] = !0;
                return d
            },
            od;
        nd("A AREA BUTTON HEAD INPUT LINK MENU META OPTGROUP OPTION PROGRESS STYLE SELECT SOURCE TEXTAREA TITLE TRACK".split(" "));
        _.pd = function(a, c) {
            c ? a.setAttribute("role", c) : a.removeAttribute("role")
        };
        _.J = function(a, c, d) {
            _.oa(d) && (d = d.join(" "));
            var e = "aria-" + c;
            "" === d || void 0 == d ? (od || (od = {
                atomic: !1,
                autocomplete: "none",
                dropeffect: "none",
                haspopup: !1,
                live: "off",
                multiline: !1,
                multiselectable: !1,
                orientation: "vertical",
                readonly: !1,
                relevant: "additions text",
                required: !1,
                sort: "none",
                busy: !1,
                disabled: !1,
                hidden: !1,
                invalid: "false"
            }), d = od, c in d ? a.setAttribute(e, d[c]) : a.removeAttribute(e)) : a.setAttribute(e, d)
        };

    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.qd = function(a) {
            return "function" == _.na(a)
        };
        _.rd = function(a) {
            return _.Xb(_.Tb.Aa(), a)
        };
        _.sd = function(a) {
            a = a.split(".");
            for (var c = _.m, d; d = a.shift();)
                if (null != c[d]) c = c[d];
                else return null;
            return c
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var td;
        td = function(a) {
            return /^\s*$/.test(a) ? !1 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))
        };
        _.ud = function(a) {
            a = String(a);
            if (td(a)) try {
                return eval("(" + a + ")")
            } catch (c) {}
            throw Error("c`" + a);
        };
        _.vd = function(a) {
            return function() {
                return a
            }
        }(!0);

    } catch (e) {
        _._DumpException(e)
    }
    try {
        var zd;
        _.K = function(a, c, d) {
            c < a.B ? a.j[c + a.A] = d : a.o[c] = d
        };
        _.wd = function(a) {
            return a
        };
        _.xd = function(a, c, d) {
            a.b || (a.b = {});
            d = d || [];
            for (var e = [], f = 0; f < d.length; f++) e[f] = d[f].nb();
            a.b[c] = d;
            _.K(a, c, e)
        };
        _.yd = function(a, c, d) {
            a.b || (a.b = {});
            var e = d ? d.nb() : d;
            a.b[c] = d;
            _.K(a, c, e)
        };
        zd = function(a, c, d) {
            this.o = d;
            this.j = a;
            this.w = c;
            this.f = 0;
            this.b = null
        };
        zd.prototype.get = function() {
            var a;
            0 < this.f ? (this.f--, a = this.b, this.b = a.next, a.next = null) : a = this.j();
            return a
        };
        var Ad = function(a, c) {
            a.w(c);
            a.f < a.o && (a.f++, c.next = a.b, a.b = c)
        };
        var Bd = function(a) {
                _.m.setTimeout(function() {
                    throw a;
                }, 0)
            },
            Cd, Dd = function() {
                var a = _.m.MessageChannel;
                "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !_.w("Presto") && (a = function() {
                    var a = window.document.createElement("IFRAME");
                    a.style.display = "none";
                    a.src = "";
                    window.document.documentElement.appendChild(a);
                    var c = a.contentWindow,
                        a = c.document;
                    a.open();
                    a.write("");
                    a.close();
                    var d = "callImmediate" + Math.random(),
                        e = "file:" == c.location.protocol ? "*" : c.location.protocol +
                        "//" + c.location.host,
                        a = (0, _.q)(function(a) {
                            if (("*" == e || a.origin == e) && a.data == d) this.port1.onmessage()
                        }, this);
                    c.addEventListener("message", a, !1);
                    this.port1 = {};
                    this.port2 = {
                        postMessage: function() {
                            c.postMessage(d, e)
                        }
                    }
                });
                if ("undefined" !== typeof a && !_.w("Trident") && !_.w("MSIE")) {
                    var c = new a,
                        d = {},
                        e = d;
                    c.port1.onmessage = function() {
                        if (_.ka(d.next)) {
                            d = d.next;
                            var a = d.le;
                            d.le = null;
                            a()
                        }
                    };
                    return function(a) {
                        e.next = {
                            le: a
                        };
                        e = e.next;
                        c.port2.postMessage(0)
                    }
                }
                return "undefined" !== typeof window.document && "onreadystatechange" in
                    window.document.createElement("SCRIPT") ? function(a) {
                        var c = window.document.createElement("SCRIPT");
                        c.onreadystatechange = function() {
                            c.onreadystatechange = null;
                            c.parentNode.removeChild(c);
                            c = null;
                            a();
                            a = null
                        };
                        window.document.documentElement.appendChild(c)
                    } : function(a) {
                        _.m.setTimeout(a, 0)
                    }
            };
        var Ed = function() {
                this.f = this.b = null
            },
            Gd = new zd(function() {
                return new Fd
            }, function(a) {
                a.reset()
            }, 100);
        Ed.prototype.remove = function() {
            var a = null;
            this.b && (a = this.b, this.b = this.b.next, this.b || (this.f = null), a.next = null);
            return a
        };
        var Fd = function() {
            this.next = this.scope = this.b = null
        };
        Fd.prototype.set = function(a, c) {
            this.b = a;
            this.scope = c;
            this.next = null
        };
        Fd.prototype.reset = function() {
            this.next = this.scope = this.b = null
        };
        var Ld = function(a, c) {
                Hd || Id();
                Jd || (Hd(), Jd = !0);
                var d = Kd,
                    e = Gd.get();
                e.set(a, c);
                d.f ? d.f.next = e : d.b = e;
                d.f = e
            },
            Hd, Id = function() {
                var a = _.m.Promise;
                if (-1 != String(a).indexOf("[native code]")) {
                    var c = a.resolve(void 0);
                    Hd = function() {
                        c.then(Md)
                    }
                } else Hd = function() {
                    var a = Md;
                    !_.qd(_.m.setImmediate) || _.m.Window && _.m.Window.prototype && !_.w("Edge") && _.m.Window.prototype.setImmediate == _.m.setImmediate ? (Cd || (Cd = Dd()), Cd(a)) : _.m.setImmediate(a)
                }
            },
            Jd = !1,
            Kd = new Ed,
            Md = function() {
                for (var a; a = Kd.remove();) {
                    try {
                        a.b.call(a.scope)
                    } catch (c) {
                        Bd(c)
                    }
                    Ad(Gd, a)
                }
                Jd = !1
            };
        _.Nd = function(a) {
            a.prototype.then = a.prototype.then;
            a.prototype.$goog_Thenable = !0
        };
        _.Od = function(a) {
            if (!a) return !1;
            try {
                return !!a.$goog_Thenable
            } catch (c) {
                return !1
            }
        };
        var Rd;
        _.Qd = function(a, c) {
            this.b = 0;
            this.A = void 0;
            this.o = this.f = this.j = null;
            this.w = this.B = !1;
            if (a != _.la) try {
                var d = this;
                a.call(c, function(a) {
                    Pd(d, 2, a)
                }, function(a) {
                    Pd(d, 3, a)
                })
            } catch (e) {
                Pd(this, 3, e)
            }
        };
        Rd = function() {
            this.next = this.context = this.f = this.j = this.b = null;
            this.o = !1
        };
        Rd.prototype.reset = function() {
            this.context = this.f = this.j = this.b = null;
            this.o = !1
        };
        var Sd = new zd(function() {
                return new Rd
            }, function(a) {
                a.reset()
            }, 100),
            Td = function(a, c, d) {
                var e = Sd.get();
                e.j = a;
                e.f = c;
                e.context = d;
                return e
            };
        _.Qd.prototype.then = function(a, c, d) {
            return Ud(this, _.qd(a) ? a : null, _.qd(c) ? c : null, d)
        };
        _.Nd(_.Qd);
        _.Qd.prototype.cancel = function(a) {
            0 == this.b && Ld(function() {
                var c = new Vd(a);
                Wd(this, c)
            }, this)
        };
        var Wd = function(a, c) {
                if (0 == a.b)
                    if (a.j) {
                        var d = a.j;
                        if (d.f) {
                            for (var e = 0, f = null, g = null, h = d.f; h && (h.o || (e++, h.b == a && (f = h), !(f && 1 < e))); h = h.next) f || (g = h);
                            f && (0 == d.b && 1 == e ? Wd(d, c) : (g ? (e = g, e.next == d.o && (d.o = e), e.next = e.next.next) : Xd(d), Yd(d, f, 3, c)))
                        }
                        a.j = null
                    } else Pd(a, 3, c)
            },
            $d = function(a, c) {
                a.f || 2 != a.b && 3 != a.b || Zd(a);
                a.o ? a.o.next = c : a.f = c;
                a.o = c
            },
            Ud = function(a, c, d, e) {
                var f = Td(null, null, null);
                f.b = new _.Qd(function(a, h) {
                    f.j = c ? function(d) {
                        try {
                            var f = c.call(e, d);
                            a(f)
                        } catch (r) {
                            h(r)
                        }
                    } : a;
                    f.f = d ? function(c) {
                        try {
                            var f =
                                d.call(e, c);
                            !_.ka(f) && c instanceof Vd ? h(c) : a(f)
                        } catch (r) {
                            h(r)
                        }
                    } : h
                });
                f.b.j = a;
                $d(a, f);
                return f.b
            };
        _.Qd.prototype.F = function(a) {
            this.b = 0;
            Pd(this, 2, a)
        };
        _.Qd.prototype.N = function(a) {
            this.b = 0;
            Pd(this, 3, a)
        };
        var Pd = function(a, c, d) {
                if (0 == a.b) {
                    a === d && (c = 3, d = new TypeError("Promise cannot resolve to itself"));
                    a.b = 1;
                    var e;
                    a: {
                        var f = d,
                            g = a.F,
                            h = a.N;
                        if (f instanceof _.Qd) $d(f, Td(g || _.la, h || null, a)),
                        e = !0;
                        else if (_.Od(f)) f.then(g, h, a),
                        e = !0;
                        else {
                            if (_.Lc(f)) try {
                                var l = f.then;
                                if (_.qd(l)) {
                                    ae(f, l, g, h, a);
                                    e = !0;
                                    break a
                                }
                            } catch (p) {
                                h.call(a, p);
                                e = !0;
                                break a
                            }
                            e = !1
                        }
                    }
                    e || (a.A = d, a.b = c, a.j = null, Zd(a), 3 != c || d instanceof Vd || be(a, d))
                }
            },
            ae = function(a, c, d, e, f) {
                var g = !1,
                    h = function(a) {
                        g || (g = !0, d.call(f, a))
                    },
                    l = function(a) {
                        g || (g = !0, e.call(f,
                            a))
                    };
                try {
                    c.call(a, h, l)
                } catch (p) {
                    l(p)
                }
            },
            Zd = function(a) {
                a.B || (a.B = !0, Ld(a.C, a))
            },
            Xd = function(a) {
                var c = null;
                a.f && (c = a.f, a.f = c.next, c.next = null);
                a.f || (a.o = null);
                return c
            };
        _.Qd.prototype.C = function() {
            for (var a; a = Xd(this);) Yd(this, a, this.b, this.A);
            this.B = !1
        };
        var Yd = function(a, c, d, e) {
                if (3 == d && c.f && !c.o)
                    for (; a && a.w; a = a.j) a.w = !1;
                if (c.b) c.b.j = null, ce(c, d, e);
                else try {
                    c.o ? c.j.call(c.context) : ce(c, d, e)
                } catch (f) {
                    de.call(null, f)
                }
                Ad(Sd, c)
            },
            ce = function(a, c, d) {
                2 == c ? a.j.call(a.context, d) : a.f && a.f.call(a.context, d)
            },
            be = function(a, c) {
                a.w = !0;
                Ld(function() {
                    a.w && de.call(null, c)
                })
            },
            de = Bd,
            Vd = function(a) {
                _.va.call(this, a)
            };
        _.v(Vd, _.va);
        Vd.prototype.name = "cancel";

    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.ee = function(a, c) {
            var d = (0, _.za)(a, c),
                e;
            (e = 0 <= d) && Array.prototype.splice.call(a, d, 1);
            return e
        };
        _.fe = !_.x || _.eb(9);
        _.ge = !_.x || _.eb(9);
        _.he = _.x && !_.cb("9");
        !_.y || _.cb("528");
        _.Sa && _.cb("1.9b") || _.x && _.cb("8") || _.Pa && _.cb("9.5") || _.y && _.cb("528");
        _.Sa && !_.cb("8") || _.x && _.cb("9");
        _.ie = function(a, c) {
            this.type = a;
            this.b = this.target = c;
            this.o = !1;
            this.Ye = !0
        };
        _.ie.prototype.stopPropagation = function() {
            this.o = !0
        };
        _.ie.prototype.preventDefault = function() {
            this.Ye = !1
        };
        var le;
        _.je = "closure_listenable_" + (1E6 * Math.random() | 0);
        _.ke = function(a) {
            return !(!a || !a[_.je])
        };
        le = 0;
        var me;
        me = function(a, c, d, e, f) {
            this.listener = a;
            this.b = null;
            this.src = c;
            this.type = d;
            this.Lc = !!e;
            this.Xc = f;
            this.key = ++le;
            this.dc = this.Kc = !1
        };
        _.ne = function(a) {
            a.dc = !0;
            a.listener = null;
            a.b = null;
            a.src = null;
            a.Xc = null
        };
        _.oe = function(a) {
            this.src = a;
            this.b = {};
            this.f = 0
        };
        _.qe = function(a, c, d, e, f, g) {
            var h = c.toString();
            c = a.b[h];
            c || (c = a.b[h] = [], a.f++);
            var l = _.pe(c, d, f, g); - 1 < l ? (a = c[l], e || (a.Kc = !1)) : (a = new me(d, a.src, h, !!f, g), a.Kc = e, c.push(a));
            return a
        };
        _.oe.prototype.remove = function(a, c, d, e) {
            a = a.toString();
            if (!(a in this.b)) return !1;
            var f = this.b[a];
            c = _.pe(f, c, d, e);
            return -1 < c ? (_.ne(f[c]), Array.prototype.splice.call(f, c, 1), 0 == f.length && (delete this.b[a], this.f--), !0) : !1
        };
        _.re = function(a, c) {
            var d = c.type;
            if (!(d in a.b)) return !1;
            var e = _.ee(a.b[d], c);
            e && (_.ne(c), 0 == a.b[d].length && (delete a.b[d], a.f--));
            return e
        };
        _.pe = function(a, c, d, e) {
            for (var f = 0; f < a.length; ++f) {
                var g = a[f];
                if (!g.dc && g.listener == c && g.Lc == !!d && g.Xc == e) return f
            }
            return -1
        };
        var te, ye;
        _.se = "closure_lm_" + (1E6 * Math.random() | 0);
        te = {};
        _.ue = 0;
        _.xe = function(a) {
            if (_.pa(a) || !a || a.dc) return !1;
            var c = a.src;
            if (_.ke(c)) return c.nd(a);
            var d = a.type,
                e = a.b;
            c.removeEventListener ? c.removeEventListener(d, e, a.Lc) : c.detachEvent && c.detachEvent(_.ve(d), e);
            _.ue--;
            (d = _.we(c)) ? (_.re(d, a), 0 == d.f && (d.src = null, c[_.se] = null)) : _.ne(a);
            return !0
        };
        _.ve = function(a) {
            return a in te ? te[a] : te[a] = "on" + a
        };
        _.we = function(a) {
            a = a[_.se];
            return a instanceof _.oe ? a : null
        };
        ye = "__closure_events_fn_" + (1E9 * Math.random() >>> 0);
        _.ze = function(a) {
            if (_.qd(a)) return a;
            a[ye] || (a[ye] = function(c) {
                return a.handleEvent(c)
            });
            return a[ye]
        };

    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.Ae = function(a, c, d, e, f) {
            a = a.b[c.toString()];
            c = -1;
            a && (c = _.pe(a, d, e, f));
            return -1 < c ? a[c] : null
        };
        _.Be = function(a, c, d) {
            return 2 >= arguments.length ? Array.prototype.slice.call(a, c) : Array.prototype.slice.call(a, c, d)
        };
        _.Ce = function(a, c, d, e, f) {
            if (_.oa(c))
                for (var g = 0; g < c.length; g++) _.Ce(a, c[g], d, e, f);
            else d = _.ze(d), _.ke(a) ? a.Ed(c, d, e, f) : a && (a = _.we(a)) && (c = _.Ae(a, c, d, !!e, f)) && _.xe(c)
        };
        _.L = function() {
            _.F.call(this);
            this.N = new _.oe(this);
            this.qb = this;
            this.Ga = null
        };
        _.v(_.L, _.F);
        _.L.prototype[_.je] = !0;
        _.k = _.L.prototype;
        _.k.vc = function() {
            return this.Ga
        };
        _.k.Sb = function(a) {
            this.Ga = a
        };
        _.k.removeEventListener = function(a, c, d, e) {
            _.Ce(this, a, c, d, e)
        };
        _.k.K = function(a) {
            var c, d = this.vc();
            if (d)
                for (c = []; d; d = d.vc()) c.push(d);
            var d = this.qb,
                e = a.type || a;
            if (_.n(a)) a = new _.ie(a, d);
            else if (a instanceof _.ie) a.target = a.target || d;
            else {
                var f = a;
                a = new _.ie(e, d);
                _.Ia(a, f)
            }
            var f = !0,
                g;
            if (c)
                for (var h = c.length - 1; !a.o && 0 <= h; h--) g = a.b = c[h], f = g.Hb(e, !0, a) && f;
            a.o || (g = a.b = d, f = g.Hb(e, !0, a) && f, a.o || (f = g.Hb(e, !1, a) && f));
            if (c)
                for (h = 0; !a.o && h < c.length; h++) g = a.b = c[h], f = g.Hb(e, !1, a) && f;
            return f
        };
        _.k.L = function() {
            _.L.H.L.call(this);
            this.hd();
            this.Ga = null
        };
        _.k.Sa = function(a, c, d, e) {
            return _.qe(this.N, String(a), c, !1, d, e)
        };
        _.k.Vc = function(a, c, d, e) {
            return _.qe(this.N, String(a), c, !0, d, e)
        };
        _.k.Ed = function(a, c, d, e) {
            return this.N.remove(String(a), c, d, e)
        };
        _.k.nd = function(a) {
            return _.re(this.N, a)
        };
        _.k.hd = function(a) {
            var c;
            if (this.N) {
                c = this.N;
                a = a && a.toString();
                var d = 0,
                    e;
                for (e in c.b)
                    if (!a || e == a) {
                        for (var f = c.b[e], g = 0; g < f.length; g++) ++d, _.ne(f[g]);
                        delete c.b[e];
                        c.f--
                    }
                c = d
            } else c = 0;
            return c
        };
        _.k.Hb = function(a, c, d) {
            a = this.N.b[String(a)];
            if (!a) return !0;
            a = a.concat();
            for (var e = !0, f = 0; f < a.length; ++f) {
                var g = a[f];
                if (g && !g.dc && g.Lc == c) {
                    var h = g.listener,
                        l = g.Xc || g.src;
                    g.Kc && this.nd(g);
                    e = !1 !== h.call(l, d) && e
                }
            }
            return e && 0 != d.Ye
        };
        _.k.Dd = function(a, c, d, e) {
            return _.Ae(this.N, String(a), c, d, e)
        };

    } catch (e) {
        _._DumpException(e)
    }
    try {
        var De, He, Ie, Je, Ke, Le, Me, Ne, Oe, Qe, Se, Ye, ef, kf, of, sf, zf;
        De = function(a, c) {
            var d = a.listener,
                e = a.Xc || a.src;
            a.Kc && _.xe(a);
            return d.call(e, c)
        };
        _.Ee = function(a, c) {
            try {
                return _.Ma(a[c]), !0
            } catch (d) {}
            return !1
        };
        _.Fe = function(a, c, d, e) {
            var f = !0;
            if (a = _.we(a))
                if (c = a.b[c.toString()])
                    for (c = c.concat(), a = 0; a < c.length; a++) {
                        var g = c[a];
                        g && g.Lc == d && !g.dc && (g = De(g, e), f = f && !1 !== g)
                    }
                return f
        };
        _.Ge = function(a, c) {
            _.ie.call(this, a ? a.type : "");
            this.relatedTarget = this.b = this.target = null;
            this.w = this.keyCode = this.button = this.clientY = this.clientX = 0;
            this.B = this.shiftKey = this.f = this.j = !1;
            this.Za = this.state = null;
            a && this.init(a, c)
        };
        _.v(_.Ge, _.ie);
        _.Ge.prototype.init = function(a, c) {
            var d = this.type = a.type,
                e = a.changedTouches ? a.changedTouches[0] : null;
            this.target = a.target || a.srcElement;
            this.b = c;
            var f = a.relatedTarget;
            f ? _.Sa && (_.Ee(f, "nodeName") || (f = null)) : "mouseover" == d ? f = a.fromElement : "mouseout" == d && (f = a.toElement);
            this.relatedTarget = f;
            null === e ? (this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY) : (this.clientX = void 0 !== e.clientX ? e.clientX : e.pageX, this.clientY = void 0 !== e.clientY ? e.clientY : e.pageY);
            this.button = a.button;
            this.keyCode = a.keyCode || 0;
            this.w = a.charCode || ("keypress" == d ? a.keyCode : 0);
            this.j = a.ctrlKey;
            this.f = a.altKey;
            this.shiftKey = a.shiftKey;
            this.B = a.metaKey;
            this.state = a.state;
            this.Za = a;
            a.defaultPrevented && this.preventDefault()
        };
        _.Ge.prototype.stopPropagation = function() {
            _.Ge.H.stopPropagation.call(this);
            this.Za.stopPropagation ? this.Za.stopPropagation() : this.Za.cancelBubble = !0
        };
        _.Ge.prototype.preventDefault = function() {
            _.Ge.H.preventDefault.call(this);
            var a = this.Za;
            if (a.preventDefault) a.preventDefault();
            else if (a.returnValue = !1, _.he) try {
                if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
            } catch (c) {}
        };
        He = function(a, c) {
            if (a.dc) return !0;
            if (!_.ge) {
                var d = c || _.sd("window.event"),
                    e = new _.Ge(d, this),
                    f = !0;
                if (!(0 > d.keyCode || void 0 != d.returnValue)) {
                    a: {
                        var g = !1;
                        if (0 == d.keyCode) try {
                            d.keyCode = -1;
                            break a
                        } catch (p) {
                            g = !0
                        }
                        if (g || void 0 == d.returnValue) d.returnValue = !0
                    }
                    d = [];
                    for (g = e.b; g; g = g.parentNode) d.push(g);
                    for (var g = a.type, h = d.length - 1; !e.o && 0 <= h; h--) {
                        e.b = d[h];
                        var l = _.Fe(d[h], g, !0, e),
                            f = f && l
                    }
                    for (h = 0; !e.o && h < d.length; h++) e.b = d[h],
                    l = _.Fe(d[h], g, !1, e),
                    f = f && l
                }
                return f
            }
            return De(a, new _.Ge(c, this))
        };
        Ie = /&/g;
        Je = /</g;
        Ke = />/g;
        Le = /"/g;
        Me = /'/g;
        Ne = /\x00/g;
        Oe = /[\x00&<>"']/;
        _.Pe = function(a) {
            if (!Oe.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Ie, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Je, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Ke, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Le, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Me, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Ne, "&#0;"));
            return a
        };
        Qe = function(a) {
            if (a && "number" == typeof a.length) {
                if (_.Lc(a)) return "function" == typeof a.item || "string" == typeof a.item;
                if (_.qd(a)) return "function" == typeof a.item
            }
            return !1
        };
        _.Re = function(a) {
            return "CSS1Compat" == a.compatMode
        };
        Se = {
            cellpadding: "cellPadding",
            cellspacing: "cellSpacing",
            colspan: "colSpan",
            frameborder: "frameBorder",
            height: "height",
            maxlength: "maxLength",
            nonce: "nonce",
            role: "role",
            rowspan: "rowSpan",
            type: "type",
            usemap: "useMap",
            valign: "vAlign",
            width: "width"
        };
        _.Te = function(a, c) {
            this.f = a;
            this.b = c
        };
        _.Ue = function(a) {
            return new _.Te(a.f, a.b)
        };
        _.Te.prototype.j = function() {
            return this.f * this.b
        };
        _.Te.prototype.Nb = function() {
            return !this.j()
        };
        _.Te.prototype.floor = function() {
            this.f = Math.floor(this.f);
            this.b = Math.floor(this.b);
            return this
        };
        _.Te.prototype.round = function() {
            this.f = Math.round(this.f);
            this.b = Math.round(this.b);
            return this
        };
        _.Ve = function(a) {
            if (a instanceof _.gd && a.constructor === _.gd && a.j === _.fd) return a.b;
            _.na(a);
            return "type_error:SafeHtml"
        };
        _.We = function(a, c, d) {
            for (var e in a) c.call(d, a[e], e, a)
        };
        _.Xe = function(a, c) {
            return 0 <= (0, _.za)(a, c)
        };
        Ye = function(a, c, d) {
            function e(d) {
                d && c.appendChild(_.n(d) ? a.createTextNode(d) : d)
            }
            for (var f = 2; f < d.length; f++) {
                var g = d[f];
                !_.Nc(g) || _.Lc(g) && 0 < g.nodeType ? e(g) : (0, _.Aa)(Qe(g) ? _.Kc(g) : g, e)
            }
        };
        _.Ze = function(a) {
            return a.parentWindow || a.defaultView
        };
        _.$e = function(a) {
            return a.scrollingElement ? a.scrollingElement : !_.y && _.Re(a) ? a.documentElement : a.body || a.documentElement
        };
        _.af = function(a, c) {
            _.We(c, function(c, e) {
                "style" == e ? a.style.cssText = c : "class" == e ? a.className = c : "for" == e ? a.htmlFor = c : Se.hasOwnProperty(e) ? a.setAttribute(Se[e], c) : 0 == e.lastIndexOf("aria-", 0) || 0 == e.lastIndexOf("data-", 0) ? a.setAttribute(e, c) : a[e] = c
            })
        };
        _.bf = function(a, c) {
            var d, e, f, g;
            d = window.document;
            d = c || d;
            if (d.querySelectorAll && d.querySelector && a) return d.querySelectorAll("" + (a ? "." + a : ""));
            if (a && d.getElementsByClassName) {
                var h = d.getElementsByClassName(a);
                return h
            }
            h = d.getElementsByTagName("*");
            if (a) {
                g = {};
                for (e = f = 0; d = h[e]; e++) {
                    var l = d.className;
                    "function" == typeof l.split && _.Xe(l.split(/\s+/), a) && (g[f++] = d)
                }
                g.length = f;
                return g
            }
            return h
        };
        _.cf = function(a, c) {
            this.b = _.ka(a) ? a : 0;
            this.P = _.ka(c) ? c : 0
        };
        _.cf.prototype.floor = function() {
            this.b = Math.floor(this.b);
            this.P = Math.floor(this.P);
            return this
        };
        _.cf.prototype.round = function() {
            this.b = Math.round(this.b);
            this.P = Math.round(this.P);
            return this
        };
        _.df = function(a, c) {
            a.innerHTML = _.Ve(c)
        };
        ef = function() {
            var a = _.ge ? function(c) {
                return He.call(a.src, a.listener, c)
            } : function(c) {
                c = He.call(a.src, a.listener, c);
                if (!c) return c
            };
            return a
        };
        _.ff = function(a) {
            try {
                return a && a.activeElement
            } catch (c) {}
            return null
        };
        _.gf = function(a, c) {
            if (!a || !c) return !1;
            if (a.contains && 1 == c.nodeType) return a == c || a.contains(c);
            if ("undefined" != typeof a.compareDocumentPosition) return a == c || !!(a.compareDocumentPosition(c) & 16);
            for (; c && a != c;) c = c.parentNode;
            return c == a
        };
        _.hf = function(a) {
            return a && a.parentNode ? a.parentNode.removeChild(a) : null
        };
        _.jf = function(a) {
            for (var c; c = a.firstChild;) a.removeChild(c)
        };
        kf = function(a, c) {
            var d = String(c[0]),
                e = c[1];
            if (!_.Oc && e && (e.name || e.type)) {
                d = ["<", d];
                e.name && d.push(' name="', _.Pe(e.name), '"');
                if (e.type) {
                    d.push(' type="', _.Pe(e.type), '"');
                    var f = {};
                    _.Ia(f, e);
                    delete f.type;
                    e = f
                }
                d.push(">");
                d = d.join("")
            }
            d = a.createElement(d);
            e && (_.n(e) ? d.className = e : _.oa(e) ? d.className = e.join(" ") : _.af(d, e));
            2 < c.length && Ye(a, d, c);
            return d
        };
        _.lf = function(a) {
            return a ? _.Ze(a) : window
        };
        _.mf = function(a) {
            var c = _.$e(a);
            a = _.Ze(a);
            return _.x && _.cb("10") && a.pageYOffset != c.scrollTop ? new _.cf(c.scrollLeft, c.scrollTop) : new _.cf(a.pageXOffset || c.scrollLeft, a.pageYOffset || c.scrollTop)
        };
        _.nf = function(a) {
            a = (a || window).document;
            a = _.Re(a) ? a.documentElement : a.body;
            return new _.Te(a.clientWidth, a.clientHeight)
        };
        _.M = function(a, c) {
            var d = c || window.document,
                e = null;
            d.getElementsByClassName ? e = d.getElementsByClassName(a)[0] : d.querySelectorAll && d.querySelector ? e = d.querySelector("." + a) : e = _.bf(a, c)[0];
            return e || null
        };
        of = function(a, c, d, e, f, g) {
            if (!c) throw Error("o");
            var h = !!f,
                l = _.we(a);
            l || (a[_.se] = l = new _.oe(a));
            d = _.qe(l, c, d, e, f, g);
            if (d.b) return d;
            e = ef();
            d.b = e;
            e.src = a;
            e.listener = d;
            if (a.addEventListener) a.addEventListener(c.toString(), e, h);
            else if (a.attachEvent) a.attachEvent(_.ve(c.toString()), e);
            else throw Error("p");
            _.ue++;
            return d
        };
        _.pf = function(a) {
            this.b = a || _.m.document || window.document
        };
        _.k = _.pf.prototype;
        _.k.D = function(a) {
            return _.kd(this.b, a)
        };
        _.k.Pa = function(a, c, d) {
            return kf(this.b, arguments)
        };
        _.k.createElement = function(a) {
            return _.md(this.b, a)
        };
        _.k.Uc = function(a, c) {
            a.appendChild(c)
        };
        _.k.Ae = _.jf;
        _.k.Be = _.hf;
        _.k.contains = _.gf;
        _.qf = function(a) {
            return 9 == a.nodeType ? a : a.ownerDocument || a.document
        };
        _.rf = function(a) {
            return _.Lc(a) && 1 == a.nodeType
        };
        _.tf = function(a) {
            return String(a).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08")
        };
        _.uf = function(a) {
            return /^[\s\xa0]*$/.test(a)
        };
        _.vf = function(a, c, d, e, f) {
            if (_.oa(c)) {
                for (var g = 0; g < c.length; g++) _.vf(a, c[g], d, e, f);
                return null
            }
            d = _.ze(d);
            return _.ke(a) ? a.Vc(c, d, e, f) : of(a, c, d, !0, e, f)
        };
        _.N = function(a, c, d, e, f) {
            if (_.oa(c)) {
                for (var g = 0; g < c.length; g++) _.N(a, c[g], d, e, f);
                return null
            }
            d = _.ze(d);
            return _.ke(a) ? a.Sa(c, d, e, f) : of(a, c, d, !1, e, f)
        };
        _.O = function(a, c, d) {
            return kf(window.document, arguments)
        };
        _.wf = function(a) {
            return a ? new _.pf(_.qf(a)) : sf || (sf = new _.pf)
        };
        _.xf = function(a, c) {
            return a == c ? !0 : a && c ? a.f == c.f && a.b == c.b : !1
        };
        _.yf = function(a, c) {
            var d = a.length - c.length;
            return 0 <= d && a.indexOf(c, d) == d
        };
        zf = function(a) {
            if (a.classList) return a.classList;
            a = a.className;
            return _.n(a) && a.match(/\S+/g) || []
        };
        _.P = function(a, c) {
            return a.classList ? a.classList.contains(c) : _.Xe(zf(a), c)
        };
        _.Q = function(a, c) {
            a.classList ? a.classList.add(c) : _.P(a, c) || (a.className += 0 < a.className.length ? " " + c : c)
        };
        _.Af = function(a, c) {
            if (a.classList)(0, _.Aa)(c, function(c) {
                _.Q(a, c)
            });
            else {
                var d = {};
                (0, _.Aa)(zf(a), function(a) {
                    d[a] = !0
                });
                (0, _.Aa)(c, function(a) {
                    d[a] = !0
                });
                a.className = "";
                for (var e in d) a.className += 0 < a.className.length ? " " + e : e
            }
        };
        _.R = function(a, c) {
            a.classList ? a.classList.remove(c) : _.P(a, c) && (a.className = (0, _.Ba)(zf(a), function(a) {
                return a != c
            }).join(" "))
        };
        _.Bf = function(a, c) {
            a.classList ? (0, _.Aa)(c, function(c) {
                _.R(a, c)
            }) : a.className = (0, _.Ba)(zf(a), function(a) {
                return !_.Xe(c, a)
            }).join(" ")
        };
        var Ff;
        _.Cf = function(a) {
            _.F.call(this);
            this.Y = a;
            this.R = {}
        };
        _.v(_.Cf, _.F);
        var Df = [];
        _.Cf.prototype.b = function(a, c, d, e) {
            return Ef(this, a, c, d, e)
        };
        _.Cf.prototype.B = function(a, c, d, e, f) {
            return Ef(this, a, c, d, e, f)
        };
        var Ef = function(a, c, d, e, f, g) {
            _.oa(d) || (d && (Df[0] = d.toString()), d = Df);
            for (var h = 0; h < d.length; h++) {
                var l = _.N(c, d[h], e || a.handleEvent, f || !1, g || a.Y || a);
                if (!l) break;
                a.R[l.key] = l
            }
            return a
        };
        _.Cf.prototype.O = function(a, c, d, e) {
            return Ff(this, a, c, d, e)
        };
        Ff = function(a, c, d, e, f, g) {
            if (_.oa(d))
                for (var h = 0; h < d.length; h++) Ff(a, c, d[h], e, f, g);
            else {
                c = _.vf(c, d, e || a.handleEvent, f, g || a.Y || a);
                if (!c) return a;
                a.R[c.key] = c
            }
            return a
        };
        _.Gf = function(a) {
            _.We(a.R, function(a, d) {
                this.R.hasOwnProperty(d) && _.xe(a)
            }, a);
            a.R = {}
        };
        _.Cf.prototype.L = function() {
            _.Cf.H.L.call(this);
            _.Gf(this)
        };
        _.Cf.prototype.handleEvent = function() {
            throw Error("q");
        };
        var Kf;
        _.Jf = function(a, c, d, e, f, g) {
            if (!(_.x || _.Qa || _.y && _.cb("525"))) return !0;
            if (_.Ta && f) return _.Hf(a);
            if (f && !e) return !1;
            _.pa(c) && (c = _.If(c));
            f = 17 == c || 18 == c || _.Ta && 91 == c;
            if ((!d || _.Ta) && f || _.Ta && 16 == c && (e || g)) return !1;
            if ((_.y || _.Qa) && e && d) switch (a) {
                case 220:
                case 219:
                case 221:
                case 192:
                case 186:
                case 189:
                case 187:
                case 188:
                case 190:
                case 191:
                case 192:
                case 222:
                    return !1
            }
            if (_.x && e && c == a) return !1;
            switch (a) {
                case 13:
                    return !0;
                case 27:
                    return !(_.y || _.Qa)
            }
            return _.Hf(a)
        };
        _.Hf = function(a) {
            if (48 <= a && 57 >= a || 96 <= a && 106 >= a || 65 <= a && 90 >= a || (_.y || _.Qa) && 0 == a) return !0;
            switch (a) {
                case 32:
                case 43:
                case 63:
                case 64:
                case 107:
                case 109:
                case 110:
                case 111:
                case 186:
                case 59:
                case 189:
                case 187:
                case 61:
                case 188:
                case 190:
                case 191:
                case 192:
                case 222:
                case 219:
                case 220:
                case 221:
                    return !0;
                default:
                    return !1
            }
        };
        _.If = function(a) {
            if (_.Sa) a = Kf(a);
            else if (_.Ta && _.y) switch (a) {
                case 93:
                    a = 91
            }
            return a
        };
        Kf = function(a) {
            switch (a) {
                case 61:
                    return 187;
                case 59:
                    return 186;
                case 173:
                    return 189;
                case 224:
                    return 91;
                case 0:
                    return 224;
                default:
                    return a
            }
        };
        _.Lf = function(a, c) {
            var d = _.qf(a);
            return d.defaultView && d.defaultView.getComputedStyle && (d = d.defaultView.getComputedStyle(a, null)) ? d[c] || d.getPropertyValue(c) || "" : ""
        };
        _.Mf = function(a, c) {
            return _.Lf(a, c) || (a.currentStyle ? a.currentStyle[c] : null) || a.style && a.style[c]
        };
        _.Of = function(a, c, d) {
            var e;
            c instanceof _.cf ? (e = c.b, c = c.P) : (e = c, c = d);
            a.style.left = _.Nf(e, !1);
            a.style.top = _.Nf(c, !1)
        };
        _.Pf = function(a) {
            var c;
            try {
                c = a.getBoundingClientRect()
            } catch (d) {
                return {
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0
                }
            }
            _.x && a.ownerDocument.body && (a = a.ownerDocument, c.left -= a.documentElement.clientLeft + a.body.clientLeft, c.top -= a.documentElement.clientTop + a.body.clientTop);
            return c
        };
        _.Qf = function(a, c, d) {
            if (c instanceof _.Te) d = c.b, c = c.f;
            else if (void 0 == d) throw Error("r");
            a.style.width = _.Nf(c, !0);
            a.style.height = _.Nf(d, !0)
        };
        _.Nf = function(a, c) {
            "number" == typeof a && (a = (c ? Math.round(a) : a) + "px");
            return a
        };
        _.Sf = function(a) {
            var c = _.Rf;
            if ("none" != _.Mf(a, "display")) return c(a);
            var d = a.style,
                e = d.display,
                f = d.visibility,
                g = d.position;
            d.visibility = "hidden";
            d.position = "absolute";
            d.display = "inline";
            a = c(a);
            d.display = e;
            d.position = g;
            d.visibility = f;
            return a
        };
        _.Rf = function(a) {
            var c = a.offsetWidth,
                d = a.offsetHeight,
                e = _.y && !c && !d;
            return _.ka(c) && !e || !a.getBoundingClientRect ? new _.Te(c, d) : (a = _.Pf(a), new _.Te(a.right - a.left, a.bottom - a.top))
        };
        _.Tf = function(a, c) {
            a.style.display = c ? "" : "none"
        };
        _.Uf = _.Sa ? "MozUserSelect" : _.y || _.Qa ? "WebkitUserSelect" : null;

    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Yf, $f, cg;
        _.Vf = function(a) {
            a && "function" == typeof a.ka && a.ka()
        };
        _.Wf = function(a, c, d, e, f, g) {
            if (_.oa(d))
                for (var h = 0; h < d.length; h++) _.Wf(a, c, d[h], e, f, g);
            else e = e || a.handleEvent, g = g || a.Y || a, e = _.ze(e), f = !!f, d = _.ke(c) ? c.Dd(d, e, f, g) : c ? (c = _.we(c)) ? _.Ae(c, d, e, f, g) : null : null, d && (_.xe(d), delete a.R[d.key])
        };
        _.Xf = function(a, c) {
            var d = _.Jc(_.Vf, c);
            a.Da ? _.ka(void 0) ? d.call(void 0) : d() : (a.yb || (a.yb = []), a.yb.push(_.ka(void 0) ? (0, _.q)(d, void 0) : d))
        };
        Yf = 0;
        _.Zf = function(a) {
            return a[_.qa] || (a[_.qa] = ++Yf)
        };
        $f = function(a, c, d, e) {
            Array.prototype.splice.apply(a, _.Be(arguments, 1))
        };
        _.ag = function(a, c) {
            if ("textContent" in a) a.textContent = c;
            else if (3 == a.nodeType) a.data = c;
            else if (a.firstChild && 3 == a.firstChild.nodeType) {
                for (; a.lastChild != a.firstChild;) a.removeChild(a.lastChild);
                a.firstChild.data = c
            } else _.jf(a), a.appendChild(_.qf(a).createTextNode(String(c)))
        };
        _.bg = function(a) {
            return a.contentDocument || a.contentWindow.document
        };
        cg = function(a, c) {
            return null !== a && c in a ? a[c] : void 0
        };
        _.dg = function(a, c) {
            _.L.call(this);
            this.j = a || 1;
            this.f = c || _.m;
            this.o = (0, _.q)(this.B, this);
            this.w = (0, _.ua)()
        };
        _.v(_.dg, _.L);
        _.dg.prototype.enabled = !1;
        _.dg.prototype.b = null;
        _.dg.prototype.B = function() {
            if (this.enabled) {
                var a = (0, _.ua)() - this.w;
                0 < a && a < .8 * this.j ? this.b = this.f.setTimeout(this.o, this.j - a) : (this.b && (this.f.clearTimeout(this.b), this.b = null), this.K("tick"), this.enabled && (this.b = this.f.setTimeout(this.o, this.j), this.w = (0, _.ua)()))
            }
        };
        _.dg.prototype.start = function() {
            this.enabled = !0;
            this.b || (this.b = this.f.setTimeout(this.o, this.j), this.w = (0, _.ua)())
        };
        _.eg = function(a) {
            a.enabled = !1;
            a.b && (a.f.clearTimeout(a.b), a.b = null)
        };
        _.dg.prototype.L = function() {
            _.dg.H.L.call(this);
            _.eg(this);
            delete this.f
        };
        _.fg = function(a, c, d) {
            if (_.qd(a)) d && (a = (0, _.q)(a, d));
            else if (a && "function" == typeof a.handleEvent) a = (0, _.q)(a.handleEvent, a);
            else throw Error("s");
            return 2147483647 < Number(c) ? -1 : _.m.setTimeout(a, c || 0)
        };
        _.gg = function(a, c, d) {
            _.F.call(this);
            this.j = a;
            this.w = c || 0;
            this.o = d;
            this.b = (0, _.q)(this.B, this)
        };
        _.v(_.gg, _.F);
        _.gg.prototype.f = 0;
        _.gg.prototype.L = function() {
            _.gg.H.L.call(this);
            _.hg(this);
            delete this.j;
            delete this.o
        };
        _.gg.prototype.start = function(a) {
            _.hg(this);
            this.f = _.fg(this.b, _.ka(a) ? a : this.w)
        };
        _.hg = function(a) {
            0 != a.f && _.m.clearTimeout(a.f);
            a.f = 0
        };
        _.gg.prototype.B = function() {
            this.f = 0;
            this.j && this.j.call(this.o)
        };
        _.ig = function() {};
        _.ma(_.ig);
        _.ig.prototype.b = 0;
        _.jg = function(a) {
            return ":" + (a.b++).toString(36)
        };
        var mg, ng;
        _.S = function(a) {
            _.L.call(this);
            this.j = a || _.wf();
            this.ha = kg;
            this.Z = null;
            this.wa = !1;
            this.b = null;
            this.J = void 0;
            this.F = this.B = this.f = this.w = null;
            this.Qa = !1
        };
        _.v(_.S, _.L);
        _.S.prototype.Ya = _.ig.Aa();
        var kg = null;
        _.S.prototype.getId = function() {
            return this.Z || (this.Z = _.jg(this.Ya))
        };
        _.S.prototype.D = function() {
            return this.b
        };
        _.lg = function(a) {
            a.J || (a.J = new _.Cf(a));
            return a.J
        };
        mg = function(a, c) {
            if (a == c) throw Error("t");
            var d;
            if (d = c && a.f && a.Z) {
                d = a.f;
                var e = a.Z;
                d = d.F && e ? cg(d.F, e) || null : null
            }
            if (d && a.f != c) throw Error("t");
            a.f = c;
            _.S.H.Sb.call(a, c)
        };
        _.S.prototype.Sb = function(a) {
            if (this.f && this.f != a) throw Error("u");
            _.S.H.Sb.call(this, a)
        };
        _.S.prototype.Jb = function() {
            this.b = this.j.createElement("DIV")
        };
        _.S.prototype.Qb = function(a) {
            ng(this, a)
        };
        ng = function(a, c, d) {
            if (a.wa) throw Error("v");
            a.b || a.Jb();
            c ? c.insertBefore(a.b, d || null) : a.j.b.body.appendChild(a.b);
            a.f && !a.f.wa || a.ta()
        };
        _.og = function(a, c) {
            if (a.wa) throw Error("v");
            if (c) {
                a.Qa = !0;
                var d = _.qf(c);
                a.j && a.j.b == d || (a.j = _.wf(c));
                a.Ub(c);
                a.ta()
            } else throw Error("w");
        };
        _.k = _.S.prototype;
        _.k.Ub = function(a) {
            this.b = a
        };
        _.k.ta = function() {
            this.wa = !0;
            _.pg(this, function(a) {
                !a.wa && a.D() && a.ta()
            })
        };
        _.k.Ka = function() {
            _.pg(this, function(a) {
                a.wa && a.Ka()
            });
            this.J && _.Gf(this.J);
            this.wa = !1
        };
        _.k.L = function() {
            this.wa && this.Ka();
            this.J && (this.J.ka(), delete this.J);
            _.pg(this, function(a) {
                a.ka()
            });
            !this.Qa && this.b && _.hf(this.b);
            this.f = this.w = this.b = this.F = this.B = null;
            _.S.H.L.call(this)
        };
        _.k.Fb = function(a, c, d) {
            if (a.wa && (d || !this.wa)) throw Error("v");
            if (0 > c || c > _.qg(this)) throw Error("x");
            this.F && this.B || (this.F = {}, this.B = []);
            if (a.f == this) {
                var e = a.getId();
                this.F[e] = a;
                _.ee(this.B, a)
            } else {
                var e = this.F,
                    f = a.getId();
                if (null !== e && f in e) throw Error("a`" + f);
                e[f] = a
            }
            mg(a, this);
            $f(this.B, c, 0, a);
            a.wa && this.wa && a.f == this ? (d = this.b, c = d.childNodes[c] || null, c != a.D() && d.insertBefore(a.D(), c)) : d ? (this.b || this.Jb(), c = _.rg(this, c + 1), ng(a, this.b, c ? c.b : null)) : this.wa && !a.wa && a.b && a.b.parentNode && 1 == a.b.parentNode.nodeType &&
                a.ta()
        };
        _.qg = function(a) {
            return a.B ? a.B.length : 0
        };
        _.rg = function(a, c) {
            return a.B ? a.B[c] || null : null
        };
        _.pg = function(a, c, d) {
            a.B && (0, _.Aa)(a.B, c, d)
        };
        _.S.prototype.removeChild = function(a, c) {
            if (a) {
                var d = _.n(a) ? a : a.getId();
                a = this.F && d ? cg(this.F, d) || null : null;
                if (d && a) {
                    var e = this.F;
                    d in e && delete e[d];
                    _.ee(this.B, a);
                    c && (a.Ka(), a.b && _.hf(a.b));
                    mg(a, null)
                }
            }
            if (!a) throw Error("y");
            return a
        };

    } catch (e) {
        _._DumpException(e)
    }
    try {
        var sg, wg, xg, Bg;
        sg = [1, 4, 2];
        _.tg = function(a, c, d, e) {
            d.b(c, e, void 0, a.Y || a, a)
        };
        _.ug = function(a) {
            return (_.fe ? 0 == a.Za.button : "click" == a.type ? !0 : !!(a.Za.button & sg[0])) && !(_.y && _.Ta && a.j)
        };
        _.vg = function(a, c, d) {
            for (var e = 0; a && (null == d || e <= d);) {
                if (c(a)) return a;
                a = a.parentNode;
                e++
            }
            return null
        };
        wg = function(a) {
            a = a.tabIndex;
            return _.pa(a) && 0 <= a && 32768 > a
        };
        xg = function(a) {
            return _.x && !_.cb("9") ? (a = a.getAttributeNode("tabindex"), null != a && a.specified) : a.hasAttribute("tabindex")
        };
        _.T = function(a, c, d) {
            d ? _.Q(a, c) : _.R(a, c)
        };
        _.yg = function(a, c) {
            var d = a.getAttribute("aria-" + c);
            return null == d || void 0 == d ? "" : String(d)
        };
        _.zg = function(a, c, d, e) {
            if (null != a)
                for (a = a.firstChild; a;) {
                    if (c(a) && (d.push(a), e) || _.zg(a, c, d, e)) return !0;
                    a = a.nextSibling
                }
            return !1
        };
        _.Ag = function(a) {
            var c;
            if ((c = "A" == a.tagName || "INPUT" == a.tagName || "TEXTAREA" == a.tagName || "SELECT" == a.tagName || "BUTTON" == a.tagName ? !a.disabled && (!xg(a) || wg(a)) : xg(a) && wg(a)) && _.x) {
                var d;
                !_.qd(a.getBoundingClientRect) || _.x && null == a.parentElement ? d = {
                    height: a.offsetHeight,
                    width: a.offsetWidth
                } : d = a.getBoundingClientRect();
                a = null != d && 0 < d.height && 0 < d.width
            } else a = c;
            return a
        };
        Bg = function(a, c) {
            var d = [];
            _.zg(a, c, d, !1);
            return d
        };
        var Cg, Dg;
        Cg = function() {};
        _.U = new Cg;
        Dg = ["click", _.Sa ? "keypress" : "keydown", "keyup"];
        Cg.prototype.b = function(a, c, d, e, f) {
            var g = function(a) {
                var d = _.ze(c),
                    f = _.rf(a.target) ? a.target.getAttribute("role") || null : null;
                "click" == a.type && _.ug(a) ? d.call(e, a) : 13 != a.keyCode && 3 != a.keyCode || "keyup" == a.type ? 32 != a.keyCode || "keyup" != a.type || "button" != f && "tab" != f || (d.call(e, a), a.preventDefault()) : (a.type = "keypress", d.call(e, a))
            };
            g.j = c;
            g.b = e;
            f ? f.b(a, Dg, g, d) : _.N(a, Dg, g, d)
        };
        var Eg;
        Eg = function(a) {
            return null != _.vg(a, function(a) {
                return 1 == a.nodeType && "true" == _.yg(a, "hidden")
            })
        };
        _.Fg = function(a) {
            return a ? Bg(a, function(a) {
                return 1 == a.nodeType && _.Ag(a) && !Eg(a)
            }) : []
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.Gg = !_.x;
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Hg = function(a) {
            _.F.call(this);
            this.w = a;
            this.o = this.b = null;
            this.f = {};
            this.B = {};
            this.j = {}
        };
        _.v(Hg, _.F);
        var Ig = new Hg(_.I);
        _.Vb("dd", Ig);
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Kg, Ng, Og, Pg, Ug, Vg;
        _.Jg = function(a) {
            a.b && a.b.close();
            a.b = null
        };
        Kg = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(Kg, _.z);
        _.Lg = function(a, c) {
            if (void 0 !== a.f) throw Error("g");
            a.f = c;
            _.gc(a)
        };
        _.Mg = function(a) {
            return String(a).replace(/([A-Z])/g, "-$1").toLowerCase()
        };
        Ng = {
            IMG: " ",
            BR: "\n"
        };
        Og = {
            SCRIPT: 1,
            STYLE: 1,
            HEAD: 1,
            IFRAME: 1,
            OBJECT: 1
        };
        Pg = function(a, c) {
            return c ? _.vg(a, function(a) {
                return !c || _.n(a.className) && _.Xe(a.className.split(/\s+/), c)
            }, void 0) : null
        };
        _.Qg = function(a, c, d) {
            if (!(a.nodeName in Og))
                if (3 == a.nodeType) d ? c.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : c.push(a.nodeValue);
                else if (a.nodeName in Ng) c.push(Ng[a.nodeName]);
            else
                for (a = a.firstChild; a;) _.Qg(a, c, d), a = a.nextSibling
        };
        _.Rg = function(a, c) {
            var d = a.getAttribute("aria-" + c);
            return null == d ? d : "boolean" == typeof d ? d : "true" == d
        };
        _.Sg = function(a) {
            if (_.Qc && null !== a && "innerText" in a) a = a.innerText.replace(/(\r\n|\r|\n)/g, "\n");
            else {
                var c = [];
                _.Qg(a, c, !0);
                a = c.join("")
            }
            a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
            a = a.replace(/\u200B/g, "");
            _.Qc || (a = a.replace(/ +/g, " "));
            " " != a && (a = a.replace(/^\s*/, ""));
            return a
        };
        _.Tg = function(a, c) {
            c ? a.tabIndex = 0 : (a.tabIndex = -1, a.removeAttribute("tabIndex"))
        };
        Ug = function(a, c) {
            var d = [];
            return _.zg(a, c, d, !0) ? d[0] : void 0
        };
        Vg = function(a, c) {
            var d = c.parentNode;
            d && d.replaceChild(a, c)
        };
        _.Wg = function(a, c) {
            return _.M(a, c)
        };
        _.Xg = function(a, c) {
            var d = c || window.document;
            return d.querySelectorAll && d.querySelector ? d.querySelectorAll("." + a) : _.bf(a, c)
        };
        _.Zg = function(a, c) {
            _.L.call(this);
            this.b = a;
            this.j = Yg(this.b);
            this.A = c || 100;
            this.o = _.N(a, "resize", this.w, !1, this)
        };
        _.v(_.Zg, _.L);
        _.Zg.prototype.L = function() {
            _.xe(this.o);
            _.Zg.H.L.call(this)
        };
        _.Zg.prototype.w = function() {
            this.f || (this.f = new _.gg(this.B, this.A, this), _.Xf(this, this.f));
            this.f.start()
        };
        _.Zg.prototype.B = function() {
            if (!this.b.Da) {
                var a = this.j,
                    c = Yg(this.b);
                this.j = c;
                if (a) {
                    var d = !1;
                    a.f != c.f && (this.K("b"), d = !0);
                    a.b != c.b && (this.K("a"), d = !0);
                    d && this.K("resize")
                } else this.K("a"), this.K("b"), this.K("resize")
            }
        };
        var $g = function(a) {
                _.L.call(this);
                this.f = a || window;
                this.j = _.N(this.f, "resize", this.o, !1, this);
                this.b = _.nf(this.f)
            },
            ah, Yg;
        _.v($g, _.L);
        _.bh = function() {
            var a = window,
                c = _.Zf(a);
            return ah[c] = ah[c] || new $g(a)
        };
        ah = {};
        Yg = function(a) {
            return a.b ? _.Ue(a.b) : null
        };
        $g.prototype.L = function() {
            $g.H.L.call(this);
            this.j && (_.xe(this.j), this.j = null);
            this.b = this.f = null
        };
        $g.prototype.o = function() {
            var a = _.nf(this.f);
            _.xf(a, this.b) || (this.b = a, this.K("resize"))
        };
        _.ch = function(a) {
            this.f = a;
            this.b = null
        };
        _.dh = function(a) {
            a.b || (a.b = _.N(a.f, "keydown", a.j, !1, a))
        };
        _.ch.prototype.j = function(a) {
            9 != a.keyCode || _.P(this.f, "gb_6") || (_.T(this.f, "gb_6", !0), _.eh(this))
        };
        _.eh = function(a) {
            a.b && (_.xe(a.b), a.b = null)
        };
        _.V = function(a, c) {
            _.L.call(this);
            this.B = a;
            c && (this.B.id = c)
        };
        _.v(_.V, _.L);
        _.V.prototype.D = function() {
            return this.B
        };
        _.V.prototype.getId = function() {
            return this.B.id
        };
        _.V.prototype.U = function() {
            var a = this.B.id;
            a || (a = "gb$" + _.jg(_.ig.Aa()), this.B.id = a);
            return a
        };
        _.V.prototype.L = function() {
            _.hf(this.B);
            _.V.H.L.call(this)
        };
        _.fh = function(a) {
            _.V.call(this, a);
            _.U.b(a, this.b, !1, this)
        };
        _.v(_.fh, _.V);
        _.fh.prototype.b = function(a) {
            this.K("click") || a.preventDefault()
        };
        _.gh = function(a) {
            return Ug(a, function(a) {
                return _.rf(a) && _.Ag(a)
            })
        };
        _.hh = function(a) {
            (a = _.gh(a)) && a.focus()
        };
        var ih = function() {};
        var jh = function(a, c, d) {
            this.f = a;
            this.j = c;
            this.b = d || _.m
        };
        var kh = function() {
            this.b = []
        };
        kh.prototype.f = function(a, c, d) {
            this.w(a, c, d);
            this.b.push(new jh(a, c, d))
        };
        kh.prototype.w = function(a, c, d) {
            d = d || _.m;
            for (var e = 0, f = this.b.length; e < f; e++) {
                var g = this.b[e];
                if (g.f == a && g.j == c && g.b == d) {
                    this.b.splice(e, 1);
                    break
                }
            }
        };
        kh.prototype.j = function(a) {
            for (var c = 0, d = this.b.length; c < d; c++) {
                var e = this.b[c];
                "catc" == e.f && e.j.call(e.b, a)
            }
        };
        var lh;
        _.mh = function(a, c, d) {
            this.o = new kh;
            this.C = a;
            this.B = c;
            this.b = lh(a.offsetWidth, this.B);
            this.F = d || new _.Zg(_.bh(), 10);
            _.N(this.F, "b", function() {
                window.requestAnimationFrame ? window.requestAnimationFrame((0, _.q)(this.A, this)) : this.A()
            }, !1, this)
        };
        lh = function(a, c) {
            for (var d = 0, e = c.length - 1, f = c[0]; d < e;) {
                if (a <= f.max) return f.id;
                f = c[++d]
            }
            return c[e].id
        };
        _.mh.prototype.A = function() {
            var a = lh(this.C.offsetWidth, this.B);
            a != this.b && (this.b = a, this.j(new ih))
        };
        _.mh.prototype.f = function(a, c, d) {
            this.o.f(a, c, d)
        };
        _.mh.prototype.w = function(a, c) {
            this.o.w(a, c)
        };
        _.mh.prototype.j = function(a) {
            this.o.j(a)
        };
        var nh = {
            Kh: "gb_2b",
            Xh: "gb_Ue",
            Ih: "gb_4b"
        };
        var oh = function(a, c) {
            c || (c = this.createElement(), a.Ec().appendChild(c));
            _.V.call(this, c);
            this.w = new _.Cf(this);
            _.tg(this.w, this.D(), _.U, this.mg)
        };
        _.v(oh, _.V);
        _.k = oh.prototype;
        _.k.createElement = function() {
            var a = _.md(window.document, "LI");
            _.Q(a, "gb_9b");
            _.pd(a, "menuitem");
            return a
        };
        _.k.qh = function(a) {
            if (a) {
                var c = this.D();
                _.Gg && c.dataset ? c.dataset.item = a : c.setAttribute("data-" + _.Mg("item"), a)
            } else a = this.D(), _.Gg && a.dataset ? (_.Gg && a.dataset ? "item" in a.dataset : a.hasAttribute ? a.hasAttribute("data-" + _.Mg("item")) : a.getAttribute("data-" + _.Mg("item"))) && delete a.dataset.item : a.removeAttribute("data-" + _.Mg("item"));
            return this
        };
        _.k.Dc = function() {
            var a = this.D();
            return _.Gg && a.dataset ? "item" in a.dataset ? a.dataset.item : null : a.getAttribute("data-" + _.Mg("item"))
        };
        _.k.hc = function(a) {
            _.T(this.D(), "gb_ac", a);
            return this
        };
        _.k.focus = function() {
            _.hh(this.D())
        };
        _.k.mg = function() {
            this.K("click")
        };
        var ph = function(a, c) {
            oh.call(this, a, c);
            this.o = _.Wg("gb_bc", this.D());
            this.b = _.M("gb_dc", this.o);
            this.f = null;
            this.j = _.M("gb_cc", this.o)
        };
        _.v(ph, oh);
        _.k = ph.prototype;
        _.k.createElement = function() {
            var a = ph.H.createElement.call(this);
            _.Q(a, "gb_ec");
            var c = _.O("A", "gb_bc");
            _.Tg(c, !0);
            a.appendChild(c);
            var d = _.O("SPAN", "gb_cc");
            c.appendChild(d);
            return a
        };
        _.k.Dc = function() {
            return ph.H.Dc.call(this) || this.Pe()
        };
        _.k.Pe = function() {
            return _.Sg(this.j)
        };
        _.k.rh = function(a) {
            _.ag(this.j, a);
            return this
        };
        _.k.Eh = function(a) {
            if (!this.b)
                if (this.b = _.O("IMG", "gb_dc"), this.f) Vg(this.b, this.f), this.f = null;
                else {
                    var c = this.j;
                    c.parentNode && c.parentNode.insertBefore(this.b, c)
                }
            this.b.setAttribute("src", a);
            return this
        };
        _.k.Dh = function(a) {
            if (!(a instanceof window.Element && "svg" == a.tagName.toLowerCase())) return this;
            if (this.b) Vg(a, this.b), this.b = null;
            else if (this.f) Vg(a, this.f);
            else {
                var c = this.j;
                c.parentNode && c.parentNode.insertBefore(a, c)
            }
            _.Q(a, "gb_dc");
            this.f = a;
            return this
        };
        _.k.focus = function() {
            this.o.focus()
        };
        _.qh = function(a) {
            _.V.call(this, a);
            this.b = [];
            this.F = {}
        };
        _.v(_.qh, _.V);
        _.V.prototype.Ec = function() {
            return this.D()
        };
        _.qh.prototype.ha = function(a) {
            var c = this.F[a];
            if (c) return c;
            var d = window.document.getElementById(a);
            if (d)
                for (var e = 0, f = this.b.length; e < f; ++e)
                    if (c = this.b[e], c.D() == d) return this.F[a] = c;
            return null
        };
        _.qh.prototype.f = function(a) {
            a.Sb(this);
            this.b.push(a);
            var c = a.getId();
            c && (this.F[c] = a)
        };
        _.qh.prototype.T = function() {
            for (var a = 0, c = this.b.length; a < c; a++) this.b[a].ka();
            this.F = {};
            this.b = []
        };
        var rh = function(a, c) {
            _.qh.call(this, c || this.createElement());
            this.w = a;
            for (var d = this.D().getElementsByClassName("gb_9b"), e = 0; e < d.length; e++) {
                var f = d[e];
                _.P(f, "gb_ec") ? this.f(new ph(this, f)) : this.f(new oh(this, f))
            }
        };
        _.v(rh, _.qh);
        rh.prototype.createElement = function() {
            var a = _.md(window.document, "UL");
            _.Q(a, "gb_8b");
            return a
        };
        rh.prototype.f = function(a) {
            rh.H.f.call(this, a);
            var c = this.w,
                d = a.D(),
                d = d.id || (d.id = "gbm" + _.jg(_.ig.Aa()));
            c.G[d] = a
        };
        rh.prototype.j = function() {
            var a = new oh(this);
            this.f(a);
            return a
        };
        rh.prototype.o = function() {
            var a = new ph(this);
            this.f(a);
            return a
        };
        var W = function(a, c) {
                _.qh.call(this, a);
                this.j = c;
                this.o = _.M("gb_5b", this.j);
                this.M = new _.ch(this.o);
                this.A = _.M("gb_6b", this.o);
                this.C = _.M("gb_7b", this.o);
                this.G = {};
                this.J = [];
                this.w = new _.Cf(this);
                sh(this);
                for (var d = this.o.getElementsByClassName("gb_8b"), e = 0; e < d.length; e++) this.f(new rh(this, d[e]))
            },
            sh;
        _.v(W, _.qh);
        var th = "click mousedown scroll touchstart wheel keydown".split(" ");
        W.prototype.L = function() {
            W.H.L.call(this);
            uh(this)
        };
        W.prototype.Ec = function() {
            return this.o
        };
        W.prototype.V = function() {
            vh(this);
            return wh(this, this.A)
        };
        W.prototype.S = function() {
            vh(this);
            return wh(this, this.C)
        };
        var wh = function(a, c) {
                var d = new rh(a),
                    e = d.D();
                c.appendChild(e);
                a.f(d);
                return d
            },
            vh = function(a) {
                a.A || (a.A = _.md(window.document, "DIV"), _.Q(a.A, "gb_6b"), a.o.appendChild(a.A), a.C = _.md(window.document, "DIV"), _.Q(a.C, "gb_7b"), a.o.appendChild(a.C))
            };
        _.k = W.prototype;
        _.k.Gh = function(a) {
            _.T(this.j, "gb_3b", 1 == a)
        };
        _.k.getStyle = function() {
            return xh(this) ? 0 : 1
        };
        _.k.Ca = function() {
            return !_.P(this.D(), "gb_6a")
        };
        _.k.Ud = function() {
            this.K("beforeshow");
            _.Q(this.j, "gb_g");
            _.J(this.D(), "expanded", !0);
            _.hh(this.o);
            _.dh(this.M);
            this.K("open");
            this.w.B(window.document.body, th, this.O, !0, this);
            this.w.b(window.document.body, _.yc, this.R)
        };
        _.k.close = function() {
            _.R(this.j, "gb_g");
            _.J(this.D(), "expanded", !1);
            window.document.activeElement == this.D() && this.D().blur();
            var a = this.M;
            _.eh(a);
            _.T(a.f, "gb_6", !1);
            this.K("close");
            uh(this)
        };
        _.yh = function(a) {
            return _.P(a.j, "gb_g")
        };
        sh = function(a) {
            _.tg(a.w, a.D(), _.U, a.W);
            a.D().addEventListener("keydown", function(a) {
                32 == a.keyCode && a.preventDefault()
            });
            _.tg(a.w, a.o, _.U, a.Z);
            a.w.b(a.j, "keydown", a.$)
        };
        W.prototype.W = function() {
            _.yh(this) ? this.close() : this.Ud()
        };
        var xh = function(a) {
            return !_.P(a.j, "gb_3b") || _.P(a.j, "gb_2b") || _.P(a.j, "gb_Ue")
        };
        W.prototype.$ = function(a) {
            if (9 === a.keyCode && _.yh(this) && xh(this)) {
                var c = a.target,
                    d = _.Fg(this.j);
                0 < d.length && (c == d[0] && a.shiftKey ? (d[d.length - 1].focus(), a.preventDefault()) : c != d[d.length - 1] || a.shiftKey || (d[0].focus(), a.preventDefault()))
            }
        };
        W.prototype.Z = function(a) {
            if (a.target instanceof window.Node) {
                a: {
                    a = a.target;
                    for (var c = this.o; a && a !== c;) {
                        var d = a.id;
                        if (d in this.G) {
                            a = this.G[d];
                            break a
                        }
                        a = a.parentNode
                    }
                    a = null
                }
                if (a) {
                    a = a.Dc();
                    c = 0;
                    for (d = this.J.length; c < d; ++c) {
                        var e = this.J[c];
                        e.b.call(e.f, a)
                    }
                    this.close()
                }
            }
        };
        W.prototype.O = function(a) {
            _.yh(this) && a.target instanceof window.Node && xh(this) && ("keydown" == a.type ? 27 == a.keyCode && (a.preventDefault(), a.stopPropagation(), this.close(), this.D().focus()) : Pg(a.target, "gb_ga") || Pg(a.target, "gb_Zb") || _.gf(this.j, a.target) || ("touchstart" == a.type && (a.preventDefault(), a.stopPropagation()), this.close()))
        };
        W.prototype.R = function() {
            _.yh(this) && (!xh(this) || Pg(window.document.activeElement, "gb_1b") || Pg(window.document.activeElement, "gb_ga") || _.hh(this.o))
        };
        var uh = function(a) {
            _.Wf(a.w, window.document.body, th, a.O, !1, a);
            _.Wf(a.w, window.document.body, _.yc, a.R)
        };
        W.prototype.Y = function(a, c) {
            this.J.push(new zh(a, c))
        };
        var zh = function(a, c) {
            this.b = a;
            this.f = c
        };
        _.Ah = function(a) {
            _.V.call(this, a);
            _.N(a, "click", this.b, !1, this)
        };
        _.v(_.Ah, _.V);
        _.Ah.prototype.f = function() {
            return _.Rg(this.D(), "pressed") || !1
        };
        _.Ah.prototype.b = function(a) {
            a = a.b;
            var c = _.yg(a, "pressed");
            _.uf(null == c ? "" : String(c)) || "true" == c || "false" == c ? _.J(a, "pressed", "true" == c ? "false" : "true") : a.removeAttribute("aria-pressed");
            this.K("click")
        };
        var Bh, Dh;
        _.Ch = function() {
            _.L.prototype.za = _.Jc(Bh, _.L.prototype.Sa);
            _.L.prototype.zb = _.L.prototype.vc;
            _.t("gbar.I", _.V);
            _.V.prototype.ia = _.V.prototype.getId;
            _.V.prototype.ib = _.V.prototype.D;
            _.V.prototype.ic = _.V.prototype.U;
            _.t("gbar.J", _.qh);
            _.qh.prototype.ja = _.qh.prototype.ha;
            _.qh.prototype.jb = _.qh.prototype.T;
            _.t("gbar.K", _.fh);
            _.t("gbar.L", _.Ah);
            _.Ah.prototype.la = _.Ah.prototype.f
        };
        Bh = function(a, c, d, e, f) {
            return a.call(this, c, _.Jc(Dh, d), e, f)
        };
        Dh = function(a, c) {
            c.xa = c.type;
            c.xb = c.target;
            return a.call(this, c)
        };
        var Gh = function(a, c, d, e) {
            _.L.call(this);
            this.f = a;
            this.C = c;
            this.R = d;
            this.Y = "";
            this.S = e;
            this.A = this.b = null;
            this.M = this.J = !1;
            this.T = _.M("gb_yc", this.f);
            this.F = _.G(_.B(c, 6), !1);
            this.$ = _.M("gb_zc", this.T);
            this.j = _.M("gb_bd", this.f);
            this.w = _.M("gb_cd", this.f);
            this.G = _.M("gb_hc", this.f);
            this.o = Array.prototype.slice.call(_.Xg("gb_gd", this.f));
            this.B = new _.mh(this.f, Eh);
            Fh(this, this.B.b);
            this.B.f("catc", this.V, this)
        };
        _.v(Gh, _.L);
        var Eh = [{
            id: "gb_2b",
            max: 599
        }, {
            id: "gb_Ue",
            max: 1023
        }, {
            id: "gb_4b"
        }];
        Gh.prototype.D = function() {
            return this.f
        };
        Gh.prototype.ma = function(a) {
            _.ag(this.$, a || "");
            _.T(this.T, "gb_6a", !a);
            this.F = !!a;
            Fh(this, this.B.b)
        };
        var Fh = function(a, c) {
            var d = "gb_2b" == c,
                e = "gb_Ue" == c,
                f = _.G(_.B(a.C, 5), !1),
                g = _.G(_.B(a.C, 7), !1),
                h = _.G(_.B(a.C, 2), !1),
                l = _.G(_.B(a.C, 1), !1),
                e = h && (d || e && (f || a.F));
            a.J = !(a.F || d && (f || g));
            d = !a.F;
            e || l ? (a.b || ((l = _.M("gb_Zb", a.f)) ? (f = _.M("gb_1b")) ? (a.b = new W(l, f), a.b.Sa("open", a.Z, !1, a), a.b.Sa("close", a.U, !1, a), _.Ch(), _.t("gbar.C", W), W.prototype.ca = W.prototype.Ec, W.prototype.cb = W.prototype.V, W.prototype.cc = W.prototype.Y, W.prototype.cd = W.prototype.Gh, W.prototype.ce = W.prototype.S, W.prototype.cf = W.prototype.Ud,
                    W.prototype.cg = W.prototype.close, W.prototype.ch = W.prototype.getStyle, _.t("gbar.D", rh), rh.prototype.da = rh.prototype.j, rh.prototype.db = rh.prototype.o, _.t("gbar.E", oh), oh.prototype.ea = oh.prototype.D, oh.prototype.eb = oh.prototype.hc, oh.prototype.ec = oh.prototype.qh, oh.prototype.ed = oh.prototype.Dc, _.t("gbar.F", ph), ph.prototype.fa = ph.prototype.rh, ph.prototype.fb = ph.prototype.Eh, ph.prototype.fc = ph.prototype.Dh, ph.prototype.fd = ph.prototype.Pe, ph.prototype.ed = ph.prototype.Dc, _.Lg(_.hc.Aa().b, a.b)) : a.R.log(Error("z")) :
                a.R.log(Error("A"))), a.b && !a.b.Ca() && _.R(a.b.D(), "gb_6a")) : a.b && a.b.Ca() && (l = a.b, l.close(), _.Q(l.D(), "gb_6a"));
            a.b && e ? _.Hh(a) || (e = _.M("gb_kd"), a.G.parentNode != e && e.insertBefore(a.G, e.childNodes[0] || null), _.Jg(_.rd("dd")), a.K("upi")) : _.Hh(a) && (a.j.appendChild(a.G), _.Jg(_.rd("dd")), a.K("upo"));
            a.A && (e = a.A.D(), _.T(e, "gb_6a", !d), d && a.A.j(a.J));
            _.P(a.f, "gb_2b");
            a.b && a.b.Ca() && !xh(a.b) && (a.M = _.yh(a.b));
            e = _.Mc(nh);
            _.Bf(a.f, e);
            _.Q(a.f, c);
            a.b && (l = a.b.j, _.Bf(l, e), _.Q(l, c), xh(a.b) ? _.M("gb_ld", void 0).appendChild(l) :
                a.f.appendChild(l), a.b.Ca() && (e = !xh(a.b), l = _.yh(a.b), e && !l && a.M ? a.b.Ud() : !e && l && a.b.close()));
            _.Ih(a)
        };
        Gh.prototype.V = function() {
            Fh(this, this.B.b);
            this.b && _.Jh(this, _.yh(this.b), !1);
            this.K("ffc")
        };
        _.Jh = function(a, c, d) {
            a.b && (xh(a.b) && (c = !1), a = window.document.body, _.T(a, "gb_pd", c), _.T(a, "gb_od", d))
        };
        Gh.prototype.Z = function() {
            _.Jh(this, !0, !0)
        };
        Gh.prototype.U = function() {
            _.Jh(this, !1, !0)
        };
        _.Hh = function(a) {
            return !!a.b && a.G.parentNode != a.j
        };
        Gh.prototype.getHeight = function() {
            return this.f.offsetHeight
        };
        _.Ih = function(a) {
            var c = a.getHeight() + "px";
            a.Y != c && (a.Y = c, a.S && (a.S.style.height = c), a.K("resize"))
        };
        Gh.prototype.W = function() {
            this.w && _.Ih(this)
        };
        Gh.prototype.O = function() {
            if (!this.w) {
                var a = _.md(window.document, "DIV");
                _.Af(a, ["gb_cd", "gb_gd"]);
                var c;
                c = this.o[0];
                c = c.classList.contains("gb_id") ? 1 : c.classList.contains("gb_hd") ? 2 : 0;
                Kh(a, c);
                a.style.backgroundColor = this.o[0].style.backgroundColor;
                this.o.push(a);
                c = this.j;
                c.parentNode && c.parentNode.insertBefore(a, c.nextSibling);
                this.w = a
            }
            return this.w
        };
        Gh.prototype.ha = function() {
            _.hf(this.w);
            this.w = null;
            _.Ih(this)
        };
        Gh.prototype.sa = function(a) {
            for (var c = 0; c < this.o.length; c++) Kh(this.o[c], a)
        };
        var Kh = function(a, c) {
            _.Bf(a, ["gb_hd", "gb_id"]);
            1 == c ? _.Q(a, "gb_id") : 2 == c && _.Q(a, "gb_hd")
        };
        Gh.prototype.qa = function(a) {
            for (var c = 0; c < this.o.length; c++) this.o[c].style.backgroundColor = a
        };
        var Lh;
        var Mh = _.M("gb_fc");
        if (null == Mh) Lh = null;
        else {
            var Nh = _.D(_.jc, Kg, 6) || new Kg,
                Oh = new Gh(Mh, Nh, _.I, _.M("gb_ad"));
            _.t("gbar.P", Gh);
            Gh.prototype.pa = Gh.prototype.getHeight;
            Gh.prototype.pb = Gh.prototype.ma;
            Gh.prototype.pc = Gh.prototype.sa;
            Gh.prototype.pd = Gh.prototype.qa;
            Gh.prototype.pe = Gh.prototype.O;
            Gh.prototype.pf = Gh.prototype.W;
            Gh.prototype.pg = Gh.prototype.ha;
            _.Lg(_.hc.Aa().f, Oh);
            Lh = Oh
        }
        _.X = Lh;

    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Ph = window.document.querySelector(".gb_fb .gb_b");
        Ph && _.Eb(_.tc, Ph, "click");
    } catch (e) {
        _._DumpException(e)
    }
    try {
        for (var Qh = window.document.querySelectorAll(".gb_Ub"), Rh = 0; Rh < Qh.length; Rh++) _.Eb(_.tc, Qh[Rh], "click");
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Sh = window.document.querySelector(".gb_qc");
        if (Sh) {
            var Th = Sh.querySelector(".gb_b");
            Th && _.Eb(_.tc, Th, "click")
        };
    } catch (e) {
        _._DumpException(e)
    }
})(this.gbar_);




this.gbar_ = this.gbar_ || {};
(function(_) {
    var window = this;
    try {
        if (_.X) {
            var Uh;
            if (Uh = _.B(_.X.C, 3))
                for (var Vh = _.Xg(Uh), Wh = 0; Wh < Vh.length; Wh++) {
                    var Xh = Vh[Wh];
                    _.Gg && Xh.dataset ? Xh.dataset.ogpc = "" : Xh.setAttribute("data-" + _.Mg("ogpc"), "")
                }
            _.Jh(_.X, !!_.X.b && _.yh(_.X.b), !1)
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Yh = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(Yh, _.z);
        var Zh = function(a) {
            _.A(this, a, 0, -1, null)
        };
        _.v(Zh, _.z);
        var $h = function(a) {
            _.Uc("From proto message. b/12014412");
            a = _.B(a, 4) || "";
            return _.ed(a)
        };
        var ai = _.D(_.jc, Yh, 17) || new Yh,
            bi = _.D(ai, Zh, 1),
            ci = bi ? $h(bi) : null,
            di = _.D(ai, Zh, 2),
            ei = di ? $h(di) : null,
            fi = function(a, c, d) {
                _.sc.log(46, {
                    att: a,
                    max: c,
                    url: d
                })
            },
            hi = function(a, c, d) {
                _.sc.log(47, {
                    att: a,
                    max: c,
                    url: d
                });
                a < c ? gi(a + 1, c) : _.I.log(Error("B`" + a + "`" + c), {
                    url: d
                })
            },
            gi = function(a, c) {
                if (ci) {
                    var d = _.md(window.document, "SCRIPT");
                    d.async = !0;
                    d.type = "text/javascript";
                    d.charset = "UTF-8";
                    d.src = _.dd(ci);
                    d.onload = _.Jc(fi, a, c, d.src);
                    d.onerror = _.Jc(hi, a, c, d.src);
                    _.sc.log(45, {
                        att: a,
                        max: c,
                        url: d.src
                    });
                    _.ld("HEAD")[0].appendChild(d)
                }
            };
        gi(1, 2);
        if (ei) {
            var ii = _.md(window.document, "LINK");
            ii.setAttribute("type", "text/css");
            ii.rel = "stylesheet";
            ii.href = _.dd(ei);
            _.ld("HEAD")[0].appendChild(ii)
        };
    } catch (e) {
        _._DumpException(e)
    }
})(this.gbar_);
// Google Inc.


(function() {
    var bcUrl = 'https://support.google.com/chrome/';
    var rr = false;
    window['sc_refresh'] = !rr ? true : false;
    if (!window['sc_dbg']) {
        window['sc_dbg'] = function() {};
    }
})();


function rh(a, b, c) {
    var d = window.localStorage;
    if (!d) return null;
    try {
        var e = d.getItem(a);
        if (!e) return null;
        c && (e = JSON.parse(e));
        if (b) {
            var f = window.localStorage;
            f && f.removeItem(a)
        }
        return e
    } catch (g) {
        return window.sc_trackStatsEvent(Va, xb, "local storage - get local data"), null
    }
}

function sh(a, b, c) {
    var d = window.localStorage;
    if (!d) return !1;
    try {
        var e = c ? JSON.stringify(b) : b;
        d.setItem(a, e);
        return !0
    } catch (f) {
        return window.sc_trackStatsEvent(Va, xb, "local storage - persist local data"), !1
    }
};
(function() {
    var au = '';
    var bcUrl = 'https://support.google.com/chrome/';
    var dt = 1;
    var ehc = 'chrome';
    var ehn = 'https://support.google.com';
    var fbapi = '//ssl.gstatic.com/feedback/api.js';
    var fbid = 0;
    var hc = 'chrome';
    var hcid = '167';
    var host = 'support.google.com';
    var key = 'support-content';
    var lang = 'en';
    var li = true;
    var material = false;
    var mxp = [10800027, 10800107, 10800133, 10800141];
    var ncc = 2;
    var pid = '2952242';
    var pvid = '00054098b30857160a8e9713d50753de';
    var pt = 0;
    var query = 'p\x3dhelp\x26ctx\x3dkeyboard';
    var ii = false;
    var iro = 1;
    var rs = 1;
    var rr = false;
    var rtl = false;
    var sb_uri = '';
    var skey = 'support-content';
    var use_new_render_api_logic = true;
    var visit_id = '';
    var xsrf = '';
    var legacy_url = 'google.com/support';
    var query_params = [{
        key: 'p',
        value: 'help'
    }, {
        key: 'ctx',
        value: 'keyboard'
    }];
    var cl = '137972013';
    var ff = true;
    var vid = -1288560061;
    var ccExp = true;
    window['sc_initPage']({
        'au': au,
        'bcUrl': bcUrl,
        'dt': dt,
        'ehc': ehc,
        'ehn': ehn,
        'fbapi': fbapi,
        'fbid': fbid,
        'hc': hc,
        'hcid': hcid,
        'host': host,
        'ii': ii,
        'iro': iro,
        'key': key,
        'lang': lang,
        'li': li,
        'material': material,
        'mendel_ids': mxp || [],
        'ncc': ncc,
        'pid': pid,
        'pvid': pvid,
        'pt': pt,
        'query': '?' + query,
        'rr': rr,
        'rs': rs,
        'rtl': rtl,
        'sb_uri': sb_uri,
        'skey': skey,
        'unral': use_new_render_api_logic,
        'vid': vid,
        'visit_id': visit_id,
        'xsrf': xsrf,
        'query_params': query_params,
        'cl': cl,
        'ff': ff,
        'ccExp': ccExp
    });
})();


function Af() {
    this.b = !1
}
Af.prototype.init = function() {
    window.addEventListener("load", function() {
        if (!this.b) {
            var a = document.querySelector(".csi");
            if (a && !a.value) {
                var b = (new Date).getTime(),
                    c = window.prt - window.start,
                    d = b - window.start,
                    e = window.performance && window.performance.timing;
                e && (c = window.prt - e.responseStart, d = b - e.responseStart);
                window.sc_trackStatsLatency({
                    ol: d,
                    prt: c
                });
                window.sc_pageLatency = {
                    ol: d,
                    prt: c
                };
                a.value = 1;
                this.b = !0
            }
        }
    }.bind(this), !1)
};
window.sc_initCsiLite = function() {
    window.sc_initCsiLiteDone || ((new Af).init(), window.sc_initCsiLiteDone = !0)
};

(function() {
    var curl = 'https://support.google.com/chrome/?p\x3dhelp\x26ctx\x3dkeyboard';
    window['sc_initCsiLite']({
        'curl': curl
    });
})();


function yn(a) {
    this.b = a
}
var zn = {
    "primary-button": 1,
    "action-button": 2,
    "default-button": 3,
    "product-link": 4
};
q = yn.prototype;
q.init = function() {
    window.sc_registerPageClickHandlers([this.Pf.bind(this), this.If.bind(this)])
};
q.vg = function() {
    var a = D(),
        b = rh("statsDeferred", !0, !0);
    b && (b.event.common_params.context_params.visit_id = a.visit_id, An(b.event, void 0, b.ehc));
    if (window.sc_refresh) {
        var a = parseInt(rh("refererViewId", !1, !1), 10),
            a = isNaN(a) ? 0 : a,
            b = this.Ua(1),
            c = b.resource.stats[0].page_view = {
                changelist: parseInt(this.b.cl, 10)
            };
        a && (c.referer_view_id = a);
        An(b)
    }
    this.Id()
};
q.Id = function(a) {
    a = (a || document).querySelectorAll("[st-imp]");
    for (var b = [], c = 0; c < a.length; c++) {
        var d = Z(a[c], "st-ve", Ea.id, !0),
            e = Z(a[c], "st-id"),
            f = Z(a[c], "st-idx");
        b.push([parseInt(d, 10), e, f])
    }
    0 != b.length && this.vc(b)
};
q.tg = function(a, b) {
    var c;
    c = b ? b.id : parseInt(Z(a, "st-ve", Ea.id, !0), 10);
    var d = Z(a, "st-id"),
        e = Z(a, "st-idx");
    this.vc([
        [c, d, e]
    ])
};
q.vc = function(a) {
    for (var b = this.Ua(3), c = b.resource.stats[0].impressions = [], d = 0; d < a.length; d++) {
        var e = a[d],
            f = {
                type: e[0]
            };
        e[1] && (f.id = e[1]);
        Bn(f, e[2]);
        c.push(f)
    }
    An(b)
};
q.Hd = function(a, b, c, d, e) {
    a = a.id;
    var f = b.id;
    b = this.Ua(5);
    a = {
        type: a,
        action: f
    };
    c && (a.id = c);
    Bn(a, d);
    (b.resource.stats[0].events = []).push(a);
    An(b, e)
};
q.sg = function(a, b, c, d, e, f) {
    b || (b = parseInt(Z(a, "st-ve", Ea.id, !0), 10), b = Cn(fb, b));
    c || (c = parseInt(Z(a, "st-action", gb.id, f), 10), c = Cn(Fb, c));
    d = d || Z(a, "st-id", void 0, f);
    a = e || Z(a, "st-idx", void 0, f);
    this.Hd(b, c, d, a)
};

function Cn(a, b) {
    var c, d;
    for (d in a) {
        var e = a[d];
        if (e.id == b) return e;
        0 == e.id && (c = e)
    }
    return c
}
q.ug = function(a) {
    var b = this.Ua(2);
    b.resource.stats[0].latency = a;
    An(b)
};
q.Pf = function(a) {
    a.hc_internal && sh("refererViewId", D().vid)
};
q.If = function(a) {
    if (a.hc_internal || a.external) {
        var b = a.event,
            c = a.element,
            d;
        a: {
            d = c;
            var e;
            if (e = d) {
                b: {
                    for (e = d; e;) {
                        if (e.hasAttribute && e.hasAttribute("st-ignore")) {
                            e = !0;
                            break b
                        }
                        e = e.parentNode
                    }
                    e = !1
                }
                e = !e
            }
            if (e)
                for (; d;) {
                    if (d.hasAttribute && d.hasAttribute("st-action") || "A" === d.tagName) break a;
                    d = d.parentNode
                }
            d = null
        }
        if (c && d) {
            c = Dn(a);
            e = d;
            var f = Z(e, "st-ve", Ea.id, !0),
                g = Z(e, "st-action", mb.id),
                h = Z(e, "st-id", e.href, !0);
            a = this.Ua(4);
            f = a.resource.stats[0].click_tracking = {
                click_method: c,
                type: parseInt(f, 10),
                action: parseInt(g, 10)
            };
            h && (f.id = h);
            Bn(f, Z(e, "st-idx"));
            for (var l in zn)
                if (C(e, l)) {
                    f.content_attribute = {
                        style: zn[l]
                    };
                    break
                }
            switch (c) {
                case 2:
                    l = d;
                    b.preventDefault();
                    An(a, this.Ec.bind(this, l));
                    break;
                case 3:
                    An(a);
                    break;
                case 1:
                    sh("statsDeferred", {
                        event: a,
                        ehc: D().ehc
                    }, !0) || (l = d, b.preventDefault(), An(a, this.Ec.bind(this, l)))
            }
        }
    }
};
q.Ua = function(a) {
    var b = D();
    a = {
        common_params: {
            language: b.lang,
            context_params: {
                connection_class: b.ncc,
                device_type: b.dt,
                page_type: b.pt,
                referer: this.b.ref,
                request_source: b.rs,
                request_url: b.bcUrl,
                visit_id: b.visit_id,
                view_id: b.vid,
                experiment_id: [10800112]
            }
        },
        resource: {
            stats: [{
                type: a,
                request_state: {
                    view_id: b.vid,
                    initial_request_origin: b.iro,
                    page_id: b.pid
                }
            }]
        }
    };
    var c = b.mendel_ids;
    if (c && c.length)
        for (var d = 0; d < c.length; d++) a.common_params.context_params.experiment_id.push(c[d]);
    if (this.b.exp) {
        if (c = this.b.exp) {
            for (var d = [], e = 0, f; f = c[e]; e++) f && (f = f.active_groups) && d.push(f);
            d = d.join(";")
        } else d = "";
        c = a.common_params.context_params.gkms_experiment = [];
        d = d.split(";");
        for (e = 0; e < d.length; e++) f = d[e].split("::"), 2 == f.length && c.push({
            experiment_id: f[0],
            group_id: f[1]
        })
    }
    b.request_attributes && (a.resource.stats[0].request_state.request_attributes = b.request_attributes);
    return a
};
q.Ec = function(a) {
    var b;
    if (a.getAttribute && a.getAttribute("st-delay-url")) b = a.getAttribute("st-delay-url");
    else if ("A" === a.nodeName && a.href) {
        if ("_blank" === a.target) {
            window.open(a.href, "_blank");
            return
        }
        b = a.href
    }(a = window.sc_delayLocationHandler) && a instanceof Function ? a(b) : H(b)
};

function Z(a, b, c, d) {
    c = void 0 !== c ? c.toString() : void 0;
    if (d)
        for (; a;)
            if (a.getAttribute && a.getAttribute(b)) {
                c = a.getAttribute(b);
                break
            } else a = a.parentNode;
    else a.getAttribute && a.getAttribute(b) && (c = a.getAttribute(b));
    return c ? c.toLowerCase() : void 0
}

function Dn(a) {
    var b = a.element.getAttribute("st-method");
    if (b) switch (b.toUpperCase()) {
        case "DELAY":
            return 2;
        case "IMMEDIATE":
            return 3;
        case "DEFER":
            return 1
    }
    return a.blank ? 3 : a.external ? 2 : a.hc_internal ? 1 : 3
}

function Bn(a, b) {
    if (b) {
        var c = b.split(",");
        c[0] && (a.idx = parseInt(c[0], 10));
        c[1] && (a.count = parseInt(c[1], 10))
    }
}

function An(a, b, c) {
    F({
        ua: "POST",
        endpoint: "metrics",
        params: {
            v: window.sc_useNewMetricsApi ? "1" : "0"
        },
        Ga: a,
        df: c,
        Fa: b,
        Ra: b,
        Kd: !0
    });
    G(document, "sc_statsEvent", a)
}
window.sc_initStats = function(a) {
    if (!window.sc_refresh) {
        var b = window.sc_trackStatsScopedImpressions;
        if (b) {
            b(window.sc_scope);
            return
        }
    }
    a = new yn(a);
    a.init();
    window.sc_trackStatsEvent = a.Hd.bind(a);
    window.sc_trackStatsEventByElement = a.sg.bind(a);
    window.sc_trackStatsScopedImpressions = a.Id.bind(a);
    window.sc_trackStatsImpressions = a.vc.bind(a);
    window.sc_trackStatsImpressionByElement = a.tg.bind(a);
    window.sc_trackStatsLatency = a.ug.bind(a);
    window.sc_trackStatsPageView = a.vg.bind(a);
    window.sc_createStatsRequest =
        a.Ua.bind(a)
};

(function() {
    var cl = '137972013';
    var exp = [{
        active_groups: '2392284_IPR_P2::original'
    }, {
        active_groups: '2765944_IPR_P2::original'
    }];
    var ref = '';
    window['sc_initStats']({
        'cl': cl,
        'exp': exp,
        'ref': ref
    });
})();

function En(a) {
    this.g = a;
    this.i = "vid-" + D().ehc;
    Fn(this)
}

function Fn(a) {
    var b = {
        visit_id: D().visit_id,
        time: (new Date).getTime()
    };
    sh(a.i, b, !0);
    a.b(void 0, b);
    va.push(function(a) {
        xa(a) || za(a) || this.b(Aa(a))
    }.bind(a))
}
En.prototype.o = function(a) {
    a.hc_internal && this.b(a.target_hc)
};
En.prototype.b = function(a, b) {
    var c = D(),
        d = b;
    d || (d = rh(a && a != c.ehc ? "vid-" + a : this.i, !1, !0));
    var e = "",
        f = "Thu, 01-Jan-1970 00:00:01 GMT";
    if (d) {
        var g = (new Date).getTime();
        d.time + this.g.vttl < g || (e = encodeURIComponent(d.visit_id), f = (new Date(g + this.g.vttl)).toUTCString())
    }
    d = document.createElement("a");
    d.href = c.ehn;
    document.cookie = "SUPPORT_CONTENT=" + c.hcid + "|" + e + ";domain=" + d.hostname + ";path=/;max-age=" + Math.floor(this.g.vttl / 1E3) + ";expires=" + f
};
window.sc_initVisitManager = function(a) {
    a = new En(a);
    window.sc_visitManagerProcessClick = a.o.bind(a);
    window.sc_setVisitIdCookie = a.b.bind(a)
};

(function() {
    var vttl = 1800000;
    window['sc_initVisitManager']({
        'vttl': vttl
    });
})();

function fm(a) {
    this.s = a;
    this.b = [];
    this.o = "hidden";
    this.u = this.g = this.i = 0;
    gm(this)
}

function gm(a) {
    if (-1 != a.s.delays) {
        for (var b = a.s.delays.split(","), c = 0; c < b.length; c++) a.b.push(parseInt(b[c], 10));
        for (var b = "", d = ["moz", "ms", "webkit"], c = 0; c < d.length; c++) {
            var b = d[c],
                e = b + "Hidden";
            "undefined" != typeof document[e] && (a.o = e)
        }
        document.addEventListener(b + "visibilitychange", a.w.bind(a));
        hm(a, a.b[0]);
        document.addEventListener("pjaxunload", function() {
            im(this);
            this.b = []
        }.bind(a))
    }
}
fm.prototype.w = function() {
    document[this.o] ? this.g && im(this) : !this.g && 0 < this.b.length && hm(this, this.u)
};

function hm(a, b) {
    a.i = Date.now() + b;
    a.g = window.setTimeout(a.H.bind(a), b)
}

function im(a) {
    a.u = a.i - Date.now();
    window.clearTimeout(a.g);
    a.g = 0
}
fm.prototype.H = function() {
    var a;
    a = D();
    a = {
        template_set: 1,
        uri: ua(),
        initial_request_origin: a.iro,
        request_source: a.rs,
        page_type: a.pt,
        device_type: a.dt,
        network_connection_class: a.ncc
    };
    a.top = this.b[0] / 1E3;
    a.page_view_id = D().pvid;
    var b = window.sc_createStatsRequest(6);
    b && (a.common_params = b.common_params, a.resource = b.resource);
    F({
        ua: "POST",
        endpoint: "top",
        Ga: a,
        Kd: !0
    });
    a = this.b.shift();
    0 < this.b.length ? hm(this, this.b[0] - a) : this.g = 0
};
window.sc_initTopTimer = function(a) {
    new fm(a)
};

(function() {
    var delays = '2000,5000,10000,30000,60000';
    if (window['sc_refresh'] == true) {
        window['sc_initTopTimer']({
            'delays': delays
        });
    }
})();

function Hg(a) {
    this.b = a || document;
    a = this.b.querySelectorAll(".accordion-homepage h2");
    for (var b = 0; b < a.length; b++) {
        var c = a[b],
            d = c.parentElement;
        Ig(d);
        c.addEventListener("click", this.g.bind(this, d))
    }
    var e;
    (a = pa("topic")) && (e = this.b.querySelector('.accordion-homepage .parent[data-id="' + a + '"]'));
    e || (e = this.b.querySelector(".accordion-homepage .parent"));
    e && this.g(e)
}

function Ig(a) {
    var b = a.querySelector(".children");
    b.style.marginTop = -(b.offsetTop - b.parentElement.offsetTop + b.offsetHeight) + "px";
    Jg(a, !1)
}

function Jg(a, b) {
    a.querySelector("h2").setAttribute("aria-expanded", b);
    a.querySelector(".children").setAttribute("aria-hidden", !b)
}
Hg.prototype.g = function(a) {
    var b = this.b.querySelector(".accordion-homepage .selected");
    b && b != a && (Kg(b), Jg(b, !1));
    Kg(a);
    b = C(a, "selected");
    Jg(a, b);
    qa("topic", b ? a.getAttribute("data-id") : "")
};

function Kg(a) {
    B(a, "selected");
    var b;
    C(a, "selected") ? (a.querySelector(".children").style.marginTop = 0, b = I) : (Ig(a), b = ib);
    window.sc_trackStatsEventByElement(a, Fa, b)
}
window.sc_initHomepage = function() {
    new Hg(window.sc_scope)
};

window['sc_initHomepage']();

function vd(a, b) {
    this.s = a;
    this.S = void 0 !== b ? b : !0;
    this.g = 0;
    this.u = this.w = this.b = this.H = null;
    this.o = 0;
    wd(this)
}

function wd(a) {
    a.H = a.s.querySelector(".reel");
    a.b = a.s.querySelectorAll(".slide-buttons a");
    for (var b = 0; b < a.b.length; b++) a.b[b].addEventListener("click", a.i.bind(a, b, !0, hb));
    a.w = a.s.querySelector(".previous");
    a.w.addEventListener("click", function() {
        this.i(this.g - 1, !0, lb)
    }.bind(a));
    a.u = a.s.querySelector(".next");
    a.u.addEventListener("click", function() {
        this.i(this.g + 1, !0, kb)
    }.bind(a));
    1 == a.b.length && (a.s.querySelector(".slide-buttons").style.display = "none", a.w.style.display = "none", a.u.style.display = "none");
    window.addEventListener("resize", function() {
        this.i(this.g)
    }.bind(a));
    a.i(0);
    a.S && (a.o = window.setInterval(function() {
        this.g == this.b.length - 1 && (window.clearInterval(this.o), this.o = 0);
        this.i(this.g + 1)
    }.bind(a), 5E3))
}
vd.prototype.i = function(a, b, c) {
    var d = this.b.length;
    a = (a % d + d) % d;
    this.H.style[D().rtl ? "right" : "left"] = a * -this.H.clientWidth + "px";
    B(this.b[this.g], "selected", !1);
    B(this.b[a], "selected", !0);
    B(this.w, "disabled", 0 == a);
    B(this.u, "disabled", a == this.b.length - 1);
    this.g = a;
    window.setTimeout(function() {
        G(document, "imgLazyLoad")
    }, 600);
    b && this.o && (window.clearInterval(this.o), this.o = 0);
    c && window.sc_trackStatsEvent(Ia, c, void 0, a + 1 + "," + d)
};
vd.prototype.R = m("g");
window.sc_initCarousel = function(a, b) {
    var c = new vd(a, b);
    return {
        showSlide: c.i.bind(c),
        getCurrentSlide: c.R.bind(c)
    }
};

var carousel = (window['sc_scope'] || document).querySelector('.homepage-carousel');
if (carousel) {
    window['sc_initCarousel'](carousel);
}

function Al(a) {
    this.b = null;
    this.g = !1;
    this.o = a
}

function Bl(a) {
    B(a.b, "show-search");
    var b = document.getElementById("search-toggle");
    if (C(a.b, "show-search")) {
        var c = document.getElementById("search-box");
        c && c.focus();
        b.setAttribute("aria-label", a.o.close)
    } else b.setAttribute("aria-label", a.o.search);
    a = document.getElementsByClassName("search-toggle");
    for (b = 0; b < a.length; b++) B(a[b], "active")
}
Al.prototype.i = function() {
    this.g ? window.history.go(-1) : Bl(this)
};
Al.prototype.s = function(a) {
    if (C(a, "active")) {
        if (a = document.getElementById("search-box")) a.value = "", a.focus()
    } else Bl(this)
};
Al.prototype.init = function() {
    if (this.b = document.getElementById("search-container")) {
        this.g = C(this.b, "always-show-search");
        var a = this.b.getElementsByTagName("form")[0];
        if (a) {
            var b = document.getElementById("search-back"),
                c = document.getElementById("search-toggle"),
                d = document.getElementsByClassName("search-overlay")[0];
            b && b.addEventListener("click", this.i.bind(this));
            c && c.addEventListener("click", this.s.bind(this, c));
            d && d.addEventListener("click", this.i.bind(this));
            var e = !1;
            a.addEventListener("submit", function(b) {
                b.preventDefault();
                (b = a.elements.q.value) && !e && (window.sc_trackStatsEvent(Ja, yb, b), e = !0, H(K(new Gb(a.action), "q", b).toString()))
            })
        }
    }
};
window.sc_initSearch = function(a) {
    (new Al(a)).init()
};

(function() {
    var close = 'Close';
    var search = 'Search';
    window['sc_initSearch']({
        close: close,
        search: search
    });
})();

function yl() {
    this.b = window.sc_scope || document;
    zl(this)
}

function zl(a) {
    var b = a.b.querySelector(".non-one-bar form, .gaiabar form");
    if (b) {
        var c = !1;
        b.addEventListener("submit", function(a) {
            a.preventDefault();
            (a = b.elements.q.value) && !c && (window.sc_trackStatsEvent(Ja, yb, a), c = !0, H(K(new Gb(b.action), "q", a).toString()))
        })
    }
}
window.sc_initSearchFullLayout = function() {
    new yl
};


window['sc_initSearchFullLayout']();

O.prototype.Qa = u(8, function(a, b, c) {
    a = this.b.b[String(a)];
    if (!a) return !0;
    a = a.concat();
    for (var d = !0, e = 0; e < a.length; ++e) {
        var f = a[e];
        if (f && !f.Ya && f.Db == b) {
            var g = f.listener,
                h = f.Jb || f.src;
            f.Cb && this.wc(f);
            d = !1 !== g.call(h, c) && d
        }
    }
    return d && 0 != c.rd
});
Vc.prototype.Qa = u(7, function() {
    throw Error("Not implemented.");
});
O.prototype.Wa = u(6, function(a) {
    var b, c = this.rb();
    if (c) {
        b = [];
        for (var d = 1; c; c = c.rb()) b.push(c), ++d
    }
    c = this.u;
    d = a.type || a;
    if (w(a)) a = new fc(a, c);
    else if (a instanceof fc) a.target = a.target || c;
    else {
        var e = a;
        a = new fc(d, c);
        Ub(a, e)
    }
    var e = !0,
        f;
    if (b)
        for (var g = b.length - 1; !a.g && 0 <= g; g--) f = a.b = b[g], e = f.Qa(d, !0, a) && e;
    a.g || (f = a.b = c, e = f.Qa(d, !0, a) && e, a.g || (e = f.Qa(d, !1, a) && e));
    if (b)
        for (g = 0; !a.g && g < b.length; g++) f = a.b = b[g], e = f.Qa(d, !1, a) && e;
    return e
});
Vc.prototype.Wa = u(5, function() {
    throw Error("Not implemented.");
});
O.prototype.rb = u(4, m("s"));
Vc.prototype.rb = u(3, function() {
    throw Error("Not implemented.");
});

function Rh(a) {
    var b = /rv: *([\d\.]*)/.exec(a);
    if (b && b[1]) return b[1];
    var b = "",
        c = /MSIE +([\d\.]+)/.exec(a);
    if (c && c[1])
        if (a = /Trident\/(\d.\d)/.exec(a), "7.0" == c[1])
            if (a && a[1]) switch (a[1]) {
                case "4.0":
                    b = "8.0";
                    break;
                case "5.0":
                    b = "9.0";
                    break;
                case "6.0":
                    b = "10.0";
                    break;
                case "7.0":
                    b = "11.0"
            } else b = "7.0";
            else b = c[1];
    return b
}

function Sh() {
    return (L("Chrome") || L("CriOS")) && !L("Edge")
}

function Th(a) {
    for (var b = RegExp("(\\w[\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"), c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
    return c
}

function Uh(a, b) {
    return null !== a && b in a
}

function Vh() {
    function a(a) {
        var b;
        a: {
            b = d;
            for (var e = a.length, h = w(a) ? a.split("") : a, l = 0; l < e; l++)
                if (l in h && b.call(void 0, h[l], l, a)) {
                    b = l;
                    break a
                }
            b = -1
        }
        return c[0 > b ? null : w(a) ? a.charAt(b) : a[b]] || ""
    }
    var b = Mb;
    if (mc()) return Rh(b);
    var b = Th(b),
        c = {};
    bc(b, function(a) {
        c[a[0]] = a[1]
    });
    var d = ma(Uh, c);
    return L("Opera") ? a(["Version", "Opera"]) : L("Edge") ? a(["Edge"]) : Sh() ? a(["Chrome", "CriOS"]) : (b = b[2]) && b[1] || ""
};

function Wh(a) {
    this.b = a
}
var Xh = new Wh({});
Wh.prototype.contains = function(a) {
    return a in this.b
};
Wh.prototype.Ea = function(a) {
    return this.b[a] || ""
};
var Yh = /^[6-9]$/,
    Zh = /<\/?(?:b|em)>/gi;

function $h(a, b, c, d, e, f) {
    this.i = a;
    this.b = b;
    this.o = c;
    this.s = d;
    this.u = e;
    this.H = f || Xh;
    this.g = !1;
    switch (this.s) {
        case 0:
        case 32:
        case 38:
        case 400:
        case 407:
        case 35:
        case 33:
        case 41:
        case 34:
        case 44:
        case 45:
        case 40:
        case 46:
        case 56:
        case 30:
        case 411:
        case 410:
        case 71:
        case 42:
            this.g = !0
    }
}
$h.prototype.w = m("o");
$h.prototype.ma = m("s");
$h.prototype.ta = m("H");

function ai(a) {
    this.s = a
}
ai.prototype.Da = fa;
ai.prototype.ma = m("s");
ai.prototype.o = ba(!0);

function bi(a) {
    if (a.classList) return a.classList;
    a = a.className;
    return w(a) && a.match(/\S+/g) || []
}

function ci(a, b) {
    var c;
    a.classList ? c = a.classList.contains(b) : (c = bi(a), c = 0 <= ac(c, b));
    return c
}

function di(a, b) {
    a.classList ? a.classList.remove(b) : ci(a, b) && (a.className = cc(bi(a), function(a) {
        return a != b
    }).join(" "))
};
var ei = /^\s/,
    fi = /\s+/,
    gi = /\s+/g,
    hi = /^\s+|\s+$/g,
    ii = /^\s+$/,
    ji = /<[^>]*>/g,
    ki = /&nbsp;/g,
    li = /&#x3000;/g,
    mi = [/&/g, /&amp;/g, /</g, /&lt;/g, />/g, /&gt;/g, /"/g, /&quot;/g, /'/g, /&#39;/g, /{/g, /&#123;/g],
    ni = document.getElementsByTagName("head")[0],
    oi = 0,
    pi = 1;

function qi(a) {
    var b = {};
    if (a)
        for (var c = 0; c < a.length; ++c) b[a[c]] = !0;
    return b
}

function ri(a, b) {
    function c() {
        return b
    }
    void 0 === b && (b = a);
    return {
        Hb: c,
        Mc: function() {
            return a
        },
        De: c,
        g: function() {
            return a < b
        },
        b: function(c) {
            return c && a == c.Mc() && b == c.De()
        }
    }
}

function S(a, b, c, d) {
    if (null == b || "" === b) {
        if (!d) return;
        b = ""
    }
    c.push(a + "=" + encodeURIComponent(String(b)))
}

function si(a) {
    return !!a && !ii.test(a)
}

function ti(a) {
    for (var b = mi.length, c = 0; c < b; c += 2) a = a.replace(mi[c], mi[c + 1].source);
    return a
}

function ui(a) {
    for (var b = mi.length, c = 0; c < b; c += 2) a = a.replace(mi[c + 1], mi[c].source);
    a = a.replace(ki, " ");
    return a.replace(li, "\u3000")
}

function vi(a, b) {
    return a && (-1 < a.indexOf(" ") || fi.test(a)) ? (a = a.replace(gi, " "), a.replace(b ? hi : ei, "")) : a
}

function wi(a, b, c) {
    c && (a = a.toLowerCase(), b = b.toLowerCase());
    return b.length <= a.length && a.substring(0, b.length) == b
}

function xi() {}

function yi(a) {
    var b = zi;
    if (b.indexOf) return b.indexOf(a);
    for (var c = 0, d = b.length; c < d; ++c)
        if (b[c] === a) return c;
    return -1
}

function Ai(a, b) {
    return b.b() - a.b()
}

function Bi(a) {
    var b = {},
        c;
    for (c in a) b[c] = a[c];
    return b
};
var Ci = mc(),
    Di = Ci && 0 <= Nb(Vh(), 10),
    Ei = nc();
Ei && Nb(Vh(), 4);
var Fi = L("Opera"),
    Gi = Lb() && !L("Edge"),
    Hi = L("Safari") && !(Sh() || L("Coast") || L("Opera") || L("Edge") || L("Silk") || L("Android")),
    Ii = Sh(),
    Ji = L("Android"),
    Ki = L("Macintosh"),
    Li = !(L("iPad") || L("Android") && !L("Mobile") || L("Silk")) && (L("iPod") || L("iPhone") || L("Android") || L("IEMobile"));

function Mi(a, b) {
    this.b = a;
    this.T = b;
    this.g = (oi++).toString(36);
    this.S = this.b.toLowerCase();
    this.H = vi(this.S);
    this.R = {};
    this.i = {};
    this.s = this.o = !1;
    this.w = 1
}
Mi.prototype.getId = m("g");

function Ni(a) {
    a = parseInt(a.g, 36);
    return isNaN(a) ? -1 : a
}
Mi.prototype.ta = m("R");

function Oi(a, b, c, d) {
    a.o || (a.R[b] = c, d && (a.i[b] = c))
};

function Pi() {
    this.g = {};
    this.b = {}
}
Pi.prototype.set = function(a, b) {
    this.g[a] = b
};
Pi.prototype.has = function(a) {
    return !!this.g[a]
};

function Qi(a, b, c) {
    b in a.b || (a.b[b] = []);
    a.b[b].push(c)
};

function Ri(a, b, c, d, e) {
    this.b = a;
    this.g = b;
    this.i = c;
    this.s = d;
    this.o = e;
    this.u = !0;
    this.g ? this.g.length && 33 == this.g[0].ma() && (this.o = this.u = !1) : this.g = [];
    this.i || (this.i = Xh)
}
Ri.prototype.ta = m("i");
Ri.prototype.ma = m("u");

function Si() {
    var a = document.body || document.documentElement,
        b;
    a: {
        b = 9 == a.nodeType ? a : a.ownerDocument || a.document;
        if (b.defaultView && b.defaultView.getComputedStyle && (b = b.defaultView.getComputedStyle(a, null))) {
            b = b.direction || b.getPropertyValue("direction") || "";
            break a
        }
        b = ""
    }
    return b || (a.currentStyle ? a.currentStyle.direction : null) || a.style && a.style.direction
};

function Ti() {}
q = Ti.prototype;
q.search = k();
q.redirect = k();
q.Gc = k();
q.Hc = k();
q.$c = k();
q.Ic = k();

function Ui(a, b, c, d, e, f) {
    this.s = a;
    this.R = b;
    this.H = c;
    this.i = d;
    this.o = e;
    this.u = f;
    this.w = {};
    this.b = {};
    this.g = [];
    a = this.R;
    d = a.g;
    for (var g in d)
        if (b = g, c = d[b]) this.w[b] = c, this.g.push(c);
    a = a.b;
    for (g in a) {
        b = g;
        c = a[b];
        d = this.b[b] || [];
        for (e = 0; e < c.length; ++e)
            if (f = c[e]) d.push(f), this.g.push(f);
        this.b[b] = d
    }
    this.g.sort(Vi);
    for (g = 0; a = this.g[g++];) a.Sa(this.H, this.i);
    this.s.$c(this.i, this.H);
    this.i.Td();
    for (g = 0; a = this.g[g++];) a.ya(this);
    for (g = 0; a = this.g[g++];) a.setup(this.u);
    for (g = 0; a = this.g[g++];) a.Eb(this.u);
    for (g =
        0; a = this.g[g++];) a.wa(this.u)
}
var zi = [127, 149, 134, 494, 123, 121, 126, 553, 118, 115, 128, 160, 173, 119, 116, 152, 153, 129, 120, 374, 124, 158, 155, 131, 130, 147, 570, 141, 142, 137, 143, 138, 144, 139, 140, 135, 136];
Ui.prototype.get = function(a) {
    return this.w[a]
};

function Vi(a, b) {
    var c = yi(a.ma()),
        d = yi(b.ma());
    return 0 > c ? 1 : 0 > d ? -1 : c - d
};

function Wi() {
    return {
        Yb: function() {
            return {
                Rb: "hp",
                qc: "hp",
                Zd: "google.com",
                Ad: "",
                Zb: "en",
                Dc: "",
                Sf: "",
                Qh: "",
                Cc: 0,
                yf: "",
                Cd: "",
                Jc: !1,
                od: "",
                nc: "",
                Tb: 0,
                transport: null,
                Jd: !1,
                Ih: !1,
                lf: !1,
                ee: !0,
                bh: 10,
                de: !0,
                fe: !0,
                Zg: !1,
                ve: !1,
                uf: !1,
                vf: !1,
                th: !1,
                ff: !0,
                $d: !1,
                hf: 500,
                We: !1,
                kh: !0,
                oh: !0,
                Kh: !1,
                Ye: !1,
                hd: "",
                Ah: "//www.google.com/textinputassistant",
                Bh: "",
                Dh: 7,
                lh: !1,
                mh: !1,
                Ze: !1,
                Xe: !0,
                $e: !1,
                Sc: !1,
                Zf: !1,
                Yf: !1,
                Dd: 1,
                Af: !0,
                Ub: !1,
                se: !1,
                ie: !1,
                Rf: 10,
                Te: !1,
                Tf: !0,
                Ja: document.body,
                af: !0,
                Bd: null,
                je: {},
                ah: {},
                Fh: 0,
                we: !1,
                mf: !0,
                lb: !1,
                dh: !1,
                Mh: null,
                he: !1,
                xh: null,
                Nh: null,
                $g: !1,
                jf: !0,
                Xd: !1,
                Ph: 1,
                Mf: !1,
                $f: "Search",
                te: "I'm  Feeling Lucky",
                ag: "",
                wf: "Learn more",
                Hh: "Remove",
                Gh: "This search was removed from your Web History",
                qh: "",
                Yg: "Did you mean:",
                Ch: "",
                Jh: "",
                Th: "Search by voice",
                Sh: 'Listening for "Ok Google"',
                Rh: 'Say "Ok Google"',
                Xg: "Clear Search",
                rh: null,
                nf: 0,
                qf: 0,
                Xc: "",
                uc: "",
                isRtl: !1,
                Gb: "absolute",
                Ue: !1,
                Se: !1,
                md: null,
                Ve: !0,
                Fb: [0, 0, 0],
                ae: null,
                ng: null,
                Wd: [0],
                Lh: !0,
                Gd: "",
                og: "",
                lg: "",
                eh: null,
                hh: "",
                fh: "",
                Vg: 1,
                Ld: !1,
                Kc: !1
            }
        }
    }
};

function T(a) {
    this.g = a
}
q = T.prototype;
q.Sa = k();
q.ya = k();
q.setup = k();
q.Eb = k();
q.wa = k();
q.ma = m("g");

function Xi(a) {
    this.g = 156;
    this.i = a
}
A(Xi, T);

function Yi(a, b) {
    var c = "productId:" + a.i;
    c.length && Oi(b, "requiredfields", c, !0);
    return 1
}
Xi.prototype.b = ba(28);

function Zi(a) {
    var b = cc(a, function(a) {
        return "HELP_ACTION" == a.ta().Ea("t")
    });
    a = cc(a, function(a) {
        return "HELP_ACTION" != a.ta().Ea("t")
    });
    return b.concat(a)
}

function $i(a, b, c) {
    this.g = 122;
    this.s = a;
    this.o = b || [];
    this.i = c || null
}
A($i, T);
$i.prototype.b = ba(12);

function aj(a, b) {
    var c = cc(b.g, function(a) {
        if (!a) return !1;
        a = a.ta().Ea("t");
        return !a || 0 <= this.o.indexOf(a)
    }, a);
    a.i && (c = cc(c, function(a) {
        var b = a.ta().b.p || null || {};
        return this.i.filter(a.ta().Ea("t"), b)
    }, a));
    c = Zi(c);
    c = dc(c, function(a, b) {
        return new $h(a.i, a.b, b, a.ma(), a.u || [], a.ta())
    }, a);
    c = c.slice(0, a.s);
    return new Ri(b.b, c, b.ta(), b.s, b.o)
};

function bj() {
    this.g = 157
}
A(bj, T);

function cj() {
    this.g = 115;
    this.o = {}
}
A(cj, T);
var dj = {
    Uc: "left",
    tf: !0,
    Va: null,
    marginWidth: 0
};
cj.prototype.ya = function(a) {
    this.s = a.get(116);
    a = a.b[154] || [];
    for (var b = 0, c; c = a[b++];) this.o[ej] = c
};
cj.prototype.wa = function() {
    this.i = !1
};
cj.prototype.La = m("i");

function fj(a) {
    if (a.i) {
        var b = a.s;
        b.H = 0;
        gj(b.Za.o, !1);
        hj(b.Fc, !1);
        hj(b.Ma, !1);
        ij(b, b.xd);
        U(b.sc, 9);
        a.i = !1
    }
};

function jj() {
    this.g = 118
}
A(jj, T);
q = jj.prototype;
q.ya = function(a) {
    this.o = a.get(119);
    this.S = a.get(130);
    this.Ba = a.get(145);
    this.w = a.get(117);
    this.qa = a.get(123);
    this.T = a.get(374);
    this.ha = a.get(121);
    this.Ca = a.get(553);
    this.i = a.get(128);
    this.ra = a.get(139);
    this.Ha = a.get(173);
    this.Ia = a.b[160] || []
};
q.setup = function(a) {
    this.u = a;
    this.b = this.s = this.o.b.value || ""
};
q.wa = function(a) {
    this.u = a;
    this.R = this.V = !1;
    kj(this)
};

function lj(a) {
    var b = {};
    U(a.w, 11, b);
    !b.cancel && a.u.ff && mj(a.w, function() {
        var b = a.i,
            d = b.ha;
        d.u = d.s;
        nj(b)
    })
}

function oj(a) {
    if (0 == a.u.Dd || 2 == a.u.Dd) return !1;
    var b;
    a: {
        if (pj(a.i) && (null != a.i.i ? b = qj(a.i) : (b = a.i, b = pj(b) ? b.o[0] : null), b.g)) break a;b = null
    }
    var c;
    if (c = b) b = b.b, ((c = a.s) || b ? c && b && c.toLowerCase() == b.toLowerCase() : 1) ? c = !1 : (a.s = a.b, wi(b, a.b, !0) && (b = a.b + b.substr(a.b.length)), rj(a, b, ri(b.length), "", !0), sj(a, b, !0), c = !0);
    return c ? a.T.b[8] = !0 : !1
}

function rj(a, b, c, d, e) {
    a.u.$d && !a.i.La() && "mousedown" == d && tj(a.i, c);
    var f = !1,
        g = !1;
    if (b != a.b || "onremovechip" == d) wi(d, "key") ? a.T.b[1] = !0 : "paste" == d && (a.T.b[2] = !0), f = !0, uj(a, b), U(a.w, 1, {
        yb: d,
        Va: a.H
    }), g = y(), a.U || (a.U = g), a.W = g, si(b) && (e = !0), g = !0;
    b = vj(a.Ca, b, c);
    switch (b.w) {
        case 2:
            e = !0;
            break;
        case 3:
            e = !1
    }
    e ? (f && (f = a.i, f.u && !f.S && (f.S = window.setTimeout(x(f.clear, f), f.T.hf))), a.V && Oi(b, "gs_is", 1), wj(a.qa, b)) : g && (a.i.clear(), f = a.qa, f.u = f.s);
    U(a.w, 2, {
        yb: d
    })
}

function xj(a) {
    a = a.o;
    a.H && (a.b.blur(), a.H = !1)
}

function yj(a) {
    a.b != a.s && uj(a, a.s);
    U(a.w, 5, {
        input: a.s,
        mg: a.i.o,
        Va: a.H
    });
    a.o.refresh()
}

function zj(a) {
    if (a.Ha) {
        if (a.u.We) return !0;
        for (var b = 0, c; c = a.Ia[b++];)
            if (c.isEnabled()) return !0
    }
    return !1
}
q.search = function(a) {
    this.ha.search(this.b, a)
};
q.clear = function() {
    this.b && (uj(this, ""), this.o.clear(), U(this.w, 1), U(this.w, 16), this.i.clear())
};
q.ub = function() {
    this.Aa = this.W = this.U = 0
};

function Aj(a, b) {
    var c = a.o.u.Hb();
    a.H == b ? pj(a.i) && c == a.b.length && (null != a.i.i ? a.u.Ub && a.ha.search(qj(a.i).b, 6) : a.u.Af && oj(a)) : a.S && 0 == c && a.S.b()
}

function sj(a, b, c) {
    a.b = b || "";
    kj(a);
    a.o.refresh();
    c || U(a.w, 4, {
        Va: a.H,
        input: a.b
    })
}

function kj(a) {
    var b = Bj(a.Ba, a.b);
    b != a.H && (Cj(a.o, b), a.H = b)
}

function uj(a, b) {
    a.b = a.s = b || "";
    kj(a)
};

function Dj() {
    this.g = 128
}
A(Dj, T);
q = Dj.prototype;
q.ya = function(a) {
    this.s = a.get(129);
    this.Aa = a.get(145);
    this.W = a.get(115);
    this.ha = a.get(123);
    this.w = a.get(118);
    this.Ca = a.get(147);
    this.ra = a.b[153] || [];
    this.Ha = a.get(553);
    this.U = a.get(184);
    this.Ia = a.get(157);
    this.V = a.s
};
q.setup = function() {
    this.ra.sort(Ai)
};
q.wa = function(a) {
    this.T = a;
    this.i = this.b = null;
    this.u = this.R = !1;
    this.Ba = !0;
    this.H = "";
    this.qa = 0
};

function Ej(a, b) {
    if (a.b != b) {
        var c = a.b;
        a.b = b;
        Fj(a, c)
    }
}
q.td = function() {
    if (pj(this))
        if (this.u) {
            var a = this.b;
            this.b == this.o.length - 1 ? this.i = this.b = null : null == this.b ? this.b = 0 : ++this.b;
            this.i = this.b;
            Gj(this, a, x(this.td, this))
        } else Hj(this)
};
q.ud = function() {
    if (pj(this))
        if (this.u) {
            var a = this.b;
            this.o && 0 != this.b ? null == this.b ? this.b = this.o.length - 1 : --this.b : this.i = this.b = null;
            this.i = this.b;
            Gj(this, a, x(this.ud, this))
        } else Hj(this)
};
q.La = m("u");
q.isEnabled = m("Ba");

function qj(a) {
    return null != a.i ? a.o[a.i] : null
}

function pj(a) {
    return !(!a.o || !a.o.length)
}

function Hj(a) {
    if (!a.u) {
        a: {
            var b = a.W,
                c = ej;
            if (c in b.o) {
                if (b.b) {
                    if (c == ej) break a;
                    fj(b);
                    b.b.i.u = !1
                }
                b.b = b.o[c];
                c = b.s;
                b = b.b;
                b != c.u && (c.u = b, b = b.Da(), c.R ? b != c.R && c.s.replaceChild(b, c.R) : c.s.appendChild(b), c.R = b)
            }
        }
        c = a.W;
        if (!c.i) {
            var b = c.s,
                d = Bi(dj);
            if (c.b) {
                var e = c.b.i;
                d.Va = e.H;
                d.marginWidth = e.qa;
                var f = e.T.ng;
                f || (f = "rtl" == e.H ? "right" : "left");
                d.Uc = f
            }
            ij(b, d.Va || b.xd);
            e = d.marginWidth;
            b.yd != e && (f = b.$b.style, e ? (f.width = e + "px", f.height = "1px") : f.height = "", b.yd = e);
            b.Yc = d.tf;
            b.Vc = d.Uc;
            gj(b.Za.o, !0);
            hj(b.Fc, !0);
            hj(b.Ma, !0);
            U(b.sc, 14);
            b.vd();
            c.i = !0
        }
        a.u = !0;a.V.Gc()
    }
}

function nj(a) {
    a.u && (a.S && (window.clearTimeout(a.S), a.S = null), fj(a.W), a.u = !1, a.V.Hc())
}
q.clear = function() {
    nj(this);
    this.o = null;
    this.R = !1;
    null != this.b && Ij(this.s, this.b);
    this.i = this.b = null;
    this.s.clear()
};

function Jj(a) {
    null != a.b && Ij(a.s, a.b);
    a.i = a.b = null
}

function tj(a, b) {
    if (pj(a)) Hj(a);
    else {
        var c = a.w.s;
        c && (c = vj(a.Ha, c, b || a.w.o.u), wj(a.ha, c))
    }
}

function Kj(a) {
    if (pj(a) && !a.R) {
        for (var b = [], c = [], d = 0, e;
            (e = a.ra[d++]) && !e.g(a.w.s, a.o, c););
        (d = c ? c.length : 0) && (d -= Lj(c, b, 0));
        for (e = 0; e < a.o.length; ++e) b.push(a.o[e]);
        d && (d -= Lj(c, b, 1));
        a.T.Ze && b.push(1);
        d && Lj(c, b, 2);
        a.T.Sc && b.push(2);
        if (a.Ia)
            for (a = -1, c = 0; c < b.length; c++) d = b[c], d = (d = d.ta && d.ta()) && d.Ea && d.Ea("t"), "HELP_ACTION" != d && "HELP_ACTION" == a && (b.splice(c, 0, 3), c++), a = d;
        return b
    }
    return null
}

function Lj(a, b, c) {
    for (var d = 0, e = 0, f; e < a.length; ++e)(f = a[e]) && f.position == c && (b.push(f), ++d);
    return d
}

function Gj(a, b, c) {
    var d;
    (d = null == a.b) || (d = (d = a.s.R[a.b]) ? d.o() : !1);
    d ? (Fj(a, b), null == a.b ? yj(a.w) : (b = a.s, c = a.o[a.b], b = b.Aa[c.ma()].o(c, b.o.s), sj(a.w, b), a.V.Ic(b))) : (Ij(a.s, b), c())
}

function Fj(a, b) {
    null != b && Ij(a.s, b);
    if (null != a.b) {
        var c = a.s,
            d = c.R[a.b];
        if (d) {
            if (d.o()) {
                var e = d.Da().parentNode,
                    f = c.qa;
                e.classList ? e.classList.add(f) : ci(e, f) || (e.className += 0 < e.className.length ? " " + f : f)
            }
            d = d.Da().id;
            c.o.o.b.setAttribute("aria-activedescendant", d)
        }
    }
}
var ej = pi++;

function Mj() {
    this.g = 154
}
A(Mj, T);
Mj.prototype.ya = function(a) {
    this.i = a.get(128);
    this.b = a.get(129)
};
Mj.prototype.Da = function() {
    return this.b.Da()
};

function Nj() {
    this.g = 145;
    this.b = Oj.test("x")
}
A(Nj, T);
var Pj = RegExp("^[\x00- !-@[-`{-\u00bf\u00d7\u00f7\u02b9-\u02ff\u2000-\u2bff]*$"),
    Oj = RegExp("^[\x00- !-@[-`{-\u00bf\u00d7\u00f7\u02b9-\u02ff\u2000-\u2bff]*(?:\\d[\x00- !-@[-`{-\u00bf\u00d7\u00f7\u02b9-\u02ff\u2000-\u2bff]*$|[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0800-\u1fff\u2c00-\ufb1c\ufdfe-\ufe6f\ufefd-\uffff])");
Nj.prototype.Sa = function(a) {
    this.i = a.Xb()
};

function Bj(a, b) {
    var c = a.i;
    a.b && (Oj.test(b) ? c = "ltr" : Pj.test(b) || (c = "rtl"));
    return c
};

function Qj() {
    this.g = 494;
    this.b = {};
    this.i = this.s = 0;
    this.o = -1
}
A(Qj, T);
Qj.prototype.wa = function() {
    this.reset()
};
Qj.prototype.reset = function() {
    this.b = {};
    this.i = this.s = 0;
    this.o = -1
};

function Rj() {
    this.g = 374
}
A(Rj, T);
Rj.prototype.wa = function() {
    this.reset()
};
Rj.prototype.reset = function() {
    this.b = {}
};

function Sj() {
    this.g = 553
}
A(Sj, T);
Sj.prototype.ya = function(a) {
    this.b = a.b[156] || [];
    a.get(126)
};
Sj.prototype.setup = function() {
    this.b.sort(Tj)
};
Sj.prototype.wa = function(a) {
    this.o = a;
    this.i = a.Sf
};

function vj(a, b, c) {
    b = new Mi(b, c || ri(b.length));
    c = 1;
    if (a.b)
        for (var d = 0, e; e = a.b[d++];) e = Yi(e, b), e > c && (c = e);
    b.w = c;
    Oi(b, "ds", a.o.Dc, !0);
    Oi(b, "pq", a.i, !0);
    if (!b.o) {
        b.u = y();
        "cp" in b.i || (a = b.T.Hb(), Oi(b, "cp", a, !0));
        Oi(b, "gs_id", b.g);
        a = b.i;
        c = [];
        for (var f in a) S(f, a[f], c, void 0);
        b.o = !0
    }
    return b
}

function Tj(a, b) {
    return a.b() - b.b()
};

function Uj() {
    this.g = 123;
    this.V = !1;
    this.s = -1
}
A(Uj, T);
var Vj = [0, 1, 2, 3, 4, 5, 5, 6, 6, 6, 7, 7, 7, 7, 7, 8, 8, 8, 8, 8],
    Wj = Vj[Vj.length - 1] + 1,
    Xj = 100 * Vj.length - 1;
q = Uj.prototype;
q.ya = function(a) {
    this.i = a.get(133);
    this.Ha = a.get(130);
    this.zc = a.get(118);
    this.Ac = a.get(120);
    this.yc = a.get(494);
    this.Ab = a.get(124);
    this.Ba = a.get(125);
    this.Ca = a.get(230);
    this.Bc = a.get(127)
};
q.wa = function(a) {
    this.Oa = this.Bc.i;
    this.Ia = a;
    this.V = !0;
    this.H = {};
    this.S = 0;
    this.hb = a.ve;
    this.kb = a.lf;
    this.u = -1;
    this.o = this.Ia.ee && !!this.i
};

function wj(a, b) {
    if (!(!a.V || a.kb || a.Ha && a.Ha.g())) {
        var c = !0,
            d = Ni(b);
        d > a.s && (a.s = d);
        ++a.Pa;
        d = a.yc;
        d.b[b.getId()] = !0;
        si(b.b) || (d.o = 0);
        var d = y(),
            e;
        for (e in a.H) 2500 < d - a.H[e].u && Yj(a, e);
        a.o && (e = a.i.get(b)) && ((c = a.hb || !1) && a.Ia.mf && (b.s = !0), a.Ba.Xa(e), e.s && ++a.ra, a.b = null);
        c && (a.b = b, a.R || a.ld())
    }
}

function Zj(a) {
    return a.o ? Zj(a.i) : 0
}
q.ub = function() {
    this.o && this.i.ub();
    this.W = this.T = this.Aa = this.qa = this.Ta = this.ha = this.ra = this.w = this.Pa = 0;
    this.U = [];
    for (var a = 0; a <= Wj; ++a) this.U[a] = 0
};

function ak(a, b) {
    return x(function(a) {
        this.wd(a, b)
    }, a)
}
q.ld = function() {
    null != this.R && (window.clearTimeout(this.R), this.R = null);
    if (this.b) {
        var a = [],
            b = this.b.ta();
        if (b)
            for (var c in b) S(c, b[c], a);
        var d = this.b,
            e = a.join("&"),
            a = ak(this, this.b),
            b = x(this.wd, this);
        c = this.Oa;
        var f = d.getId(),
            g = d.b;
        if (!c.i.Jc) {
            for (var h in c.b) c.o.removeChild(c.b[h]);
            c.b = {};
            c.s = null
        }
        h = c.w + c.u + c.T + "?" + (c.R ? c.R + "&" : "") + (e ? e + "&" : "");
        d = [];
        S("q", g, d, !0);
        c.i.Jd || S("callback", "google.sbox.p" + c.H, d);
        if (c.S) {
            for (var g = "", e = 4 + Math.floor(32 * Math.random()), l = 0, n; l < e; ++l) n = .3 > Math.random() ? 48 +
                Math.floor(10 * Math.random()) : (.5 < Math.random() ? 65 : 97) + Math.floor(26 * Math.random()), g += String.fromCharCode(n);
            S("gs_gbg", g, d)
        }
        g = W("script");
        g.src = h + d.join("&");
        g.charset = "utf-8";
        c.b[f] = g;
        c.s = c.i.Jc ? b : a;
        c.o.appendChild(g);
        this.b.s || (++this.ha, a = this.b, this.H[a.getId()] = a, ++this.w);
        this.b = null;
        a = 100;
        b = (this.w - 2) / 2;
        for (c = 1; c++ <= b;) a *= 2;
        a < this.S && (a = this.S);
        this.R = window.setTimeout(x(this.ld, this), a)
    }
};

function Yj(a, b) {
    var c = a.Oa,
        d = c.b[b];
    d && (c.o.removeChild(d), delete c.b[b]);
    delete a.H[b];
    a.w && --a.w
}
q.wd = function(a, b) {
    if (this.V) {
        if (!b && (b = this.H[(a[2] || {}).j], !b)) return;
        if (!b.s) {
            var c;
            c = this.Ab;
            var d = b,
                e = a[0],
                f = a[1],
                g = {},
                h = a[2];
            if (h)
                for (var l in h) {
                    var n = h[l];
                    l in c.b && (n = c.b[l].parse(n));
                    g[l] = n
                }
            var p = n = !1,
                h = !1;
            l = 0;
            for (var r; r = f[l++];)
                if (33 == (r[1] || 0) ? p = !0 : n = !0, p && n) {
                    h = !0;
                    break
                }
            n = 0;
            p = [];
            for (l = 0; r = f[l++];) {
                var E = r[1] || 0;
                if (!h || 33 != E) {
                    var ga;
                    ga = r[0];
                    c.i && (ga = bk(e.toLowerCase(), ui(ga).replace(ji, "")));
                    p.push(new $h(ga, ui(ga).replace(ji, ""), n++, E, r[2] || [], ck(r)))
                }
            }
            c = new Ri(d, p, new Wh(g), !1, !0);
            this.Ca &&
                (c = this.Ca.b(c, this.zc.b));
            this.o && this.i.put(c);
            Ni(b) <= this.u || (++this.qa, this.Ba.Xa(c) || ++this.Aa, d = b, this.S = c.ta().b.d || 0, d && (Yj(this, d.getId()), d = d.u, d = y() - d, this.W += d, this.T = Math.max(d, this.T), ++this.U[d > Xj ? Wj : Vj[Math.floor(d / 100)]]));
            c && (c = c.ta().Ea("q")) && this.Ac.setToken(c)
        }
    }
};

function dk() {
    this.g = 124;
    this.b = {}
}
A(dk, T);
dk.prototype.ya = function(a) {
    a.get(150);
    a = a.b[158] || [];
    for (var b = 0, c; c = a[b++];) this.b[c.jh()] = c
};
dk.prototype.wa = function(a) {
    this.i = a.Te
};

function ck(a) {
    return (a = a[3]) ? new Wh(a) : Xh
};

function ek() {
    this.g = 125
}
A(ek, T);
ek.prototype.ya = function(a) {
    this.s = a.get(117);
    this.w = a.get(118);
    this.u = a.get(494);
    this.b = a.b[122] || [];
    this.o = a.get(126);
    this.i = a.get(128);
    this.b.sort(fk)
};
ek.prototype.Xa = function(a) {
    var b;
    b = this.w.b.toLowerCase();
    if (b == a.b.b.toLowerCase()) b = !0;
    else {
        var c = a,
            d = this.o.b;
        b = vi(b);
        var e = c.b,
            c = e ? e.H : vi(c.b.b.toLowerCase()),
            d = d ? d.b.H : "";
        b = 0 == b.indexOf(c) ? 0 == b.indexOf(d) ? c.length >= d.length : !0 : !1
    }
    if (b) {
        if (this.b)
            for (d = 0; c = this.b[d++];) a = aj(c, a);
        c = this.o.b = a;
        a = c.b.b;
        d = c.g;
        if (this.i.isEnabled())
            if (d.length) {
                var f = 0 == c.ma(),
                    e = this.i,
                    g = !1,
                    h = e.U && e.U.i(d);
                e.clear();
                if ((e.o = d) && d.length) {
                    var g = d[0].b,
                        l;
                    a: if (l = g, e.Aa.b) {
                        for (var n = !1, p = !1, r = 0, E; r < l.length; ++r)
                            if (E =
                                l.charAt(r), !Pj.test(E) && (Oj.test(E) ? p = !0 : n = !0, p && n)) {
                                l = !0;
                                break a
                            }
                        l = !1
                    } else l = !0;
                    l && (g = e.w.s);
                    e.H = Bj(e.Aa, g);
                    if (f) {
                        e.R = !0;
                        g = e.s;
                        if (g.s) {
                            g.T = e.H;
                            gk(g);
                            f = !1;
                            for (l = 0; n = d[l++];) hk(g, n) && (f = !0);
                            g = f
                        } else g = !1;
                        l = d[0].ta().Ea("a");
                        l = ui(l);
                        f = e.Ca;
                        n = 0;
                        if (l) {
                            f.b || (n = X(f.w.Xc), p = n.style, p.background = "transparent", p.color = "#000", p.padding = 0, p.position = "absolute", p.whiteSpace = "pre", f.b = n, f.b.style.visibility = "hidden", f.u.appendChild(f.b));
                            n = y();
                            if (!f.o || f.o + 3E3 < n) f.o = n, n = f.b, p = ik(n), n = (n = p.getComputedStyle ? p.getComputedStyle(n, "") : n.currentStyle) ? n.fontSize : null, f.s && n == f.s || (f.i = {}, f.s = n);
                            l in f.i ? n = f.i[l] : (n = f.b, p = ti(l), n.innerHTML != p && (n.innerHTML = p), f.i[l] = n = f.b.offsetWidth, f = f.b, "" != f.innerHTML && (f.innerHTML = ""))
                        }
                        e.qa = n
                    } else e.R = !1, g = e.s.render(Kj(e), e.H), e.qa = 0;
                    h && (e.i = e.U.g(), Ej(e, e.U.b()));
                    g ? Hj(e) : e.clear()
                }
                g && (e = this.u, g = c.b, h = g.getId(), h in e.b && (si(g.b) || (e.o = c.g.length), c = g.u, c = y() - c, e.i += c, ++e.s, delete e.b[h]))
            } else this.i.clear();
        U(this.s, 3, {
            input: a,
            mg: d
        })
    }
    return b
};

function fk(a, b) {
    return a.b() - b.b()
};

function jk() {
    this.g = 126
}
A(jk, T);
jk.prototype.ya = function(a) {
    this.i = a.get(123)
};
jk.prototype.wa = function() {
    this.b = null
};

function kk() {
    this.g = 127;
    this.b = {}
}
A(kk, T);
kk.prototype.ya = function(a) {
    a = a.b[149] || [];
    for (var b = 0, c; c = a[b++];) this.b[0] = c
};
kk.prototype.wa = function(a) {
    var b = "https:" == document.location.protocol,
        c = [];
    S("client", a.Rb, c);
    S("hl", a.Zb, c);
    S("gl", a.Ad, c);
    S("sugexp", a.Cd, c);
    S("gs_rn", 55, c);
    S("gs_ri", a.qc, c);
    a.Cc && S("authuser", a.Cc, c);
    this.o = {
        protocol: "http" + (b ? "s" : "") + "://",
        host: a.od || "clients1." + a.Zd,
        nc: a.nc || "/complete/search",
        kg: c.length ? c.join("&") : ""
    };
    this.i && 0 == a.Tb || (this.i = this.b[a.Tb])
};

function lk() {
    this.g = 191
}
A(lk, T);
var mk = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 63, 0, 0, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 0, 0, 0, 0, 0, 0, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 0, 0, 0, 0, 64, 0, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 0, 0, 0, 0, 0],
    nk = [7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 7, 12, 17, 22, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 5, 9, 14, 20, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 4, 11, 16, 23, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21, 6, 10, 15, 21],
    ok = [3614090360, 3905402710, 606105819, 3250441966, 4118548399, 1200080426, 2821735955, 4249261313, 1770035416, 2336552879, 4294925233, 2304563134, 1804603682, 4254626195, 2792965006, 1236535329, 4129170786, 3225465664, 643717713, 3921069994, 3593408605, 38016083, 3634488961, 3889429448, 568446438, 3275163606, 4107603335, 1163531501, 2850285829, 4243563512, 1735328473, 2368359562, 4294588738, 2272392833, 1839030562, 4259657740, 2763975236, 1272893353, 4139469664, 3200236656, 681279174, 3936430074, 3572445317, 76029189, 3654602809, 3873151461, 530742520, 3299628645, 4096336452, 1126891415, 2878612391, 4237533241, 1700485571, 2399980690, 4293915773, 2240044497, 1873313359, 4264355552, 2734768916, 1309151649, 4149444226, 3174756917, 718787259, 3951481745];

function pk(a) {
    for (var b = [], c = 0, d = 0; d < a.length; ++d) {
        var e = a.charCodeAt(d);
        128 > e ? b[c++] = e : (2048 > e ? b[c++] = e >> 6 | 192 : (b[c++] = e >> 12 | 224, b[c++] = e >> 6 & 63 | 128), b[c++] = e & 63 | 128)
    }
    return b
}

function qk(a) {
    a.va[0] = 1732584193;
    a.va[1] = 4023233417;
    a.va[2] = 2562383102;
    a.va[3] = 271733878;
    a.Bb = a.total = 0
}

function rk(a, b) {
    for (var c = a.wg, d = 0; 64 > d; d += 4) c[d / 4] = b[d] | b[d + 1] << 8 | b[d + 2] << 16 | b[d + 3] << 24;
    for (var e = a.va[0], d = a.va[1], f = a.va[2], g = a.va[3], h, l, n, p = 0; 64 > p; ++p) 16 > p ? (h = g ^ d & (f ^ g), l = p) : 32 > p ? (h = f ^ g & (d ^ f), l = 5 * p + 1 & 15) : 48 > p ? (h = d ^ f ^ g, l = 3 * p + 5 & 15) : (h = f ^ (d | ~g), l = 7 * p & 15), n = g, g = f, f = d, e = e + h + ok[p] + c[l] & 4294967295, h = nk[p], d = d + ((e << h | e >>> 32 - h) & 4294967295) & 4294967295, e = n;
    a.va[0] = a.va[0] + e & 4294967295;
    a.va[1] = a.va[1] + d & 4294967295;
    a.va[2] = a.va[2] + f & 4294967295;
    a.va[3] = a.va[3] + g & 4294967295
}

function sk(a, b, c) {
    c || (c = b.length);
    a.total += c;
    for (var d = 0; d < c; ++d) a.buffer[a.Bb++] = b[d], 64 == a.Bb && (rk(a, a.buffer), a.Bb = 0)
}

function tk(a) {
    var b = Array(16),
        c = 8 * a.total,
        d = a.Bb;
    sk(a, a.padding, 56 > d ? 56 - d : 64 - (d - 56));
    for (var e = 56; 64 > e; ++e) a.buffer[e] = c & 255, c >>>= 8;
    rk(a, a.buffer);
    for (e = d = 0; 4 > e; ++e)
        for (c = 0; 32 > c; c += 8) b[d++] = a.va[e] >> c & 255;
    return b
};

function uk() {
    this.g = 150
}
A(uk, T);

function bk(a, b) {
    b = ti(b.replace(Zh, ""));
    a = ti(vi(a, !0));
    if (wi(b, a)) return a + "<b>" + b.substr(a.length) + "</b>";
    for (var c = "", d = [], e = b.length - 1, f = 0, g = -1, h; h = b.charAt(f); ++f) " " == h || "\t" == h ? c.length && (d.push({
        t: c,
        vb: g,
        e: f + 1
    }), c = "", g = -1) : (c += h, -1 == g ? g = f : f == e && d.push({
        t: c,
        vb: g,
        e: f + 1
    }));
    c = a.split(/\s+/);
    f = {};
    for (e = 0; g = c[e++];) f[g] = 1;
    h = -1;
    for (var c = [], l = d.length - 1, e = 0; g = d[e]; ++e) f[g.t] ? (g = -1 == h, e == l ? c.push({
        vb: g ? e : h,
        e: e
    }) : g && (h = e)) : -1 < h && (c.push({
        vb: h,
        e: e - 1
    }), h = -1);
    if (!c.length) return "<b>" + b + "</b>";
    e = "";
    for (f =
        g = 0; h = c[f]; ++f)(l = d[h.vb].vb) && (e += "<b>" + b.substring(g, l - 1) + "</b> "), g = d[h.e].e, e += b.substring(l, g);
    g < b.length && (e += "<b>" + b.substring(g) + "</b> ");
    return e
};

function vk() {
    this.g = 146
}
A(vk, T);

function wk(a) {
    Sb('"\\u30' + a.split(",").join("\\u30") + '"')
}
wk("02,0C,0D,01,FB,F2,A1,A3,A5,A7,A9,E3,E5,E7,C3,FC,A2,A4,A6,A8,AA,AB,AD,AF,B1,B3,B5,B7,B9,BB,BD,BF,C1,C4,C6,C8,CA,CB,CC,CD,CE,CF,D2,D5,D8,DB,DE,DF,E0,E1,E2,E4,E6,E8,E9,EA,EB,EC,ED,EF,F3,9B,9C");
wk("F4__,AC,AE,B0,B2,B4,B6,B8,BA,BC,BE,C0,C2,C5,C7,C9_____,D0,D3,D6,D9,DC");
wk("D1,D4,D7,DA,DD");
wk("F4____,AC_,AE_,B0_,B2_,B4_,B6_,B8_,BA_,BC_,BE_,C0_,C2__,C5_,C7_,C9______,D0__,D3__,D6__,D9__,DC");
wk("D1__,D4__,D7__,DA__,DD");
wk("A6,AB,AD,AF,B1,B3,B5,B7,B9,BB,BD,BF,C1,C4,C6,C8,CF,D2,D5,D8,DB");
wk("CF,D2,D5,D8,DB");

function xk(a) {
    this.g = 152;
    this.s = a
}
A(xk, T);
xk.prototype.b = fa;
xk.prototype.render = fa;
xk.prototype.i = xi;
xk.prototype.o = function(a) {
    return a.b
};
var yk = {
    rtl: "right",
    ltr: "left"
};

function zk(a, b) {
    try {
        if (a.setSelectionRange) a.setSelectionRange(b, b);
        else if (a.createTextRange) {
            var c = a.createTextRange();
            c.collapse(!0);
            c.moveStart("character", b);
            c.select()
        }
    } catch (d) {}
}

function Ak(a) {
    for (var b = 0, c = 0; a;) {
        b += a.offsetTop;
        c += a.offsetLeft;
        try {
            a = a.offsetParent
        } catch (d) {
            a = null
        }
    }
    return {
        Nb: b,
        Na: c
    }
}

function Bk(a) {
    try {
        return Ck(a).activeElement == a
    } catch (b) {}
    return !1
}

function W(a, b) {
    var c = document.createElement(a);
    b && (c.className = b);
    return c
}

function X(a) {
    return W("div", a)
}

function Dk(a, b) {
    a.dir != b && (a.dir = b, a.style.textAlign = yk[b])
}

function Ek(a) {
    var b = a || window;
    a = b.document;
    var c = b.innerWidth,
        b = b.innerHeight;
    if (!c) {
        var d = a.documentElement;
        d && (c = d.clientWidth, b = d.clientHeight);
        c || (c = a.body.clientWidth, b = a.body.clientHeight)
    }
    return {
        ab: c,
        Tc: b
    }
}

function Ck(a) {
    return a ? a.ownerDocument || a.document : window.document
}

function ik(a) {
    return a ? (a = Ck(a), a.defaultView || a.parentWindow) : window
};

function Fk() {
    this.s = 79;
    this.b = this.g = this.i = null;
    this.i = X();
    var a = X("ghp-autocomplete-icon");
    this.g = X();
    a.appendChild(this.g);
    this.i.appendChild(a);
    this.b = X();
    this.i.appendChild(this.b)
}
A(Fk, ai);
Fk.prototype.Da = m("i");
Fk.prototype.o = ba(!0);
Fk.prototype.render = function(a, b, c) {
    if (c) {
        var d = c.Ea("t") || "";
        b = c.b.p || null;
        a = c.Ea("l") || a;
        if ("ADWORDS_NAVI" == d) this.g.className = "action-adwords-navi-icon", this.b.innerHTML = a, this.b.className = "ghp-autocomplete-label";
        else if ("GUIDED_HELP" == d) this.g.className = "action-guided-help-icon", this.b.innerHTML = a, this.b.className = "ghp-autocomplete-label";
        else if ("HELP_ARTICLE" == d) this.g.className = "help-article-icon", this.b.innerHTML = a, this.b.className = "ghp-autocomplete-label";
        else if ("HELP_ACTION" == d && (this.g.className =
                "action-command-icon", this.b.innerHTML = a, this.b.className = "ghp-autocomplete-label action-command-title", b)) {
            a = {};
            b.result && (a = Sb(b.result));
            if ("JS_CALLBACK" === a.type) b = {
                type: a.type,
                jsCallback: {
                    closePanel: "true" === (a.jsCallback || {}).closePanel
                }
            };
            else if ("URL_NAVIGATION_ACTION" === a.type) b = a.urlNavigationDefinition, b = {
                type: a.type,
                urlNavigationDefinition: {
                    createNewTab: "true" === b.createNewTab,
                    url: b.url
                }
            };
            else throw Error("Invalid help action result type: " + a.type);
            b = b || {};
            "URL_NAVIGATION_ACTION" == b.type &&
                da("urlNavigationDefinition.createNewTab", b) && (this.b.className += " ghp-autocomplete-externalLink")
        }
    } else this.g.className = "search-query-icon", this.b.innerHTML = a, this.b.className = "ghp-autocomplete-label"
};

function Gk() {
    this.g = 149;
    this.o = ni;
    this.b = {}
}
A(Gk, T);
Gk.prototype.ya = function(a) {
    this.U = a.get(127);
    this.H = a.o.getId()
};
Gk.prototype.setup = function() {
    "google" in window || (window.google = {});
    "sbox" in window.google || (window.google.sbox = {})
};
Gk.prototype.wa = function(a) {
    this.i = a;
    if (0 == a.Tb) {
        a = this.U.o;
        this.w = a.protocol;
        this.u = a.host;
        this.T = a.nc;
        this.R = a.kg;
        this.S = "https:" == document.location.protocol;
        (a = x(this.V, this)) || (a = xi);
        var b = window.google;
        this.i.Jd ? b.ac.h = a : b.sbox["p" + this.H] = a;
        (new Image).src = this.w + this.u + "/generate_204"
    }
};
Gk.prototype.V = function(a) {
    this.s && this.s(a)
};

function Hk() {
    this.g = 117;
    this.o = [];
    this.i = {
        Rd: 1
    }
}
A(Hk, T);
var Ik = window.postMessage && !(Ci || Hi || Fi);

function Y(a, b, c, d, e, f) {
    var g = Jk(a, b);
    g || (g = {}, a.o.push({
        element: b,
        Re: g
    }));
    var h = g[c];
    h || (h = g[c] = [], a = Kk(a, c, b.Rd ? window : ik(b), h), w(c) ? b.addEventListener ? b.addEventListener(c, a, !1) : b["on" + c] = a : b[c] = a);
    h.push({
        sf: !!f,
        bc: !1,
        kd: e || 0,
        Xa: d
    });
    h.sort(Lk);
    d.ke = c
}

function Mk(a, b, c) {
    if (a = Jk(a, b))
        if (a = a[c.ke]) {
            b = 0;
            for (var d; d = a[b++];)
                if (d.Xa == c) {
                    d.bc = !0;
                    break
                }
        }
}

function U(a, b, c) {
    c = c || {};
    (a = a.i[b]) && a(c, c.yb)
}

function Nk(a, b, c) {
    a.addEventListener ? a.addEventListener(b, c, !1) : a.attachEvent("on" + b, c)
}

function mj(a, b) {
    if (Ik) {
        if (!a.b) {
            a.b = [];
            var c = x(a.s, a);
            Nk(window, "message", c)
        }
        a.b.push(b);
        c = window.location.href;
        window.postMessage("sbox.df", /HTTPS?:\/\//i.test(c) ? c : "*")
    } else window.setTimeout(b, 0)
}
Hk.prototype.s = function(a) {
    this.b && a && a.source == window && "sbox.df" == a.data && this.b.length && (this.b.shift()(), this.b && this.b.length && window.postMessage("sbox.df", window.location.href))
};

function Kk(a, b, c, d) {
    return x(function(a, f) {
        if (d.length) {
            var e;
            if (!(e = a)) {
                e = {};
                var h = c.event;
                h && (h.keyCode && (e.keyCode = h.keyCode), e.rf = !0)
            }
            e.yb = f || b;
            for (var h = e, l, n, p = 0, r; r = d[p++];) r.bc ? n = !0 : l || (r.sf ? Ok(this, r, h) : l = r.Xa(h));
            if (n)
                for (p = 0; r = d[p];) r.bc ? d.splice(p, 1) : ++p;
            if (e.Lb) {
                delete e.Lb;
                e.rf && (e = c.event || e);
                if (l = e || window.event) l.stopPropagation && l.stopPropagation(), l.cancelBubble = l.cancel = !0;
                l && (l.preventDefault && l.preventDefault(), l.returnValue = !1);
                return e.returnValue = !1
            }
        }
    }, a)
}

function Jk(a, b) {
    for (var c = 0, d; c < a.o.length; ++c)
        if (d = a.o[c], d.element == b) return d.Re;
    return null
}

function Ok(a, b, c) {
    mj(a, function() {
        b.Xa(c)
    })
}

function Lk(a, b) {
    return b.kd - a.kd
};

function Pk() {
    this.g = 120;
    this.T = -1
}
A(Pk, T);
var Qk = /\.+$/,
    Rk = /\./g,
    Sk = /./g,
    Tk = qi([23]);
q = Pk.prototype;
q.ya = function(a) {
    this.V = a.get(191);
    this.b = a.get(123);
    this.o = a.get(118);
    this.R = a.get(374);
    this.s = a.get(494);
    this.S = a.get(126);
    this.w = a.get(128);
    this.U = a.b[311] || []
};
q.setup = function(a) {
    this.H = a.yf
};
q.wa = function(a) {
    this.i = a;
    this.reset()
};
q.ta = function(a, b) {
    var c, d, e, f = this.o.s;
    b && (f = f.replace(Sk, "#"));
    var g;
    g = [];
    g[27] = 55;
    g[0] = Uk(this.i.Rb);
    g[28] = Uk(this.i.qc);
    g[1] = void 0 == a ? "" : a + "";
    d = this.R;
    e = [];
    for (var h in d.b) e.push(parseInt(h, 10));
    g[26] = e.join("j");
    d = "";
    10 <= this.S.i.w ? d = "o" : null != this.w.i && (d = this.w.i + "");
    g[2] = d;
    d = "";
    if (e = this.w.o) {
        for (var l = h = 0, n; n = e[l++];) {
            var p = n;
            n = p.ma() + "";
            p = p.u || [];
            p.length && (n += "i" + p.join("i"));
            n != c && (1 < h && (d += "l" + h), d += (c ? "j" : "") + n, h = 0, c = n);
            ++h
        }
        1 < h && (d += "l" + h)
    }
    g[3] = d;
    c = this.s.o;
    g[33] = -1 < c ? String(c) : "";
    g[4] = Math.max(this.o.U - this.u, 0);
    g[5] = Math.max(this.o.W - this.u, 0);
    g[6] = this.T;
    g[7] = y() - this.u;
    g[18] = Math.max(this.o.Aa - this.u, 0);
    g[8] = this.b.Pa;
    d = this.b;
    d = (c = d.o) ? d.i.b() : 0;
    g[25] = c ? "1" + (this.i.de ? "a" : "") + (this.i.fe ? "c" : "") : "";
    g[10] = d;
    g[11] = Zj(this.b);
    g[12] = this.b.ra;
    e = this.b;
    c = e.ha;
    d = e.Ta;
    e = e.qa;
    g[9] = c;
    g[22] = d;
    g[17] = e;
    g[13] = this.b.Aa;
    g[14] = this.b.T;
    g[15] = this.b.W;
    c = this.b;
    d = [];
    for (h = l = 0; h <= Wj; ++h) e = c.U[h], 0 == e ? l++ : (l = 1 == l ? "0j" : 1 < l ? h + "-" : "", d.push(l + e), l = 0);
    g[16] = d.join("j");
    c = 0;
    for (var r in this.s.b) c++;
    g[30] = c;
    g[31] = this.s.s;
    g[32] = this.s.i;
    g[19] = Uk(this.i.Cd);
    r = (r = this.S.b) ? r.ta().Ea("e") || "" : "";
    g[20] = r;
    for (r = 0; c = this.U[r++];) d = c.o, Tk[d] && (g[d] = void 0 == g[d] ? Uk(c.b()) : "");
    g = g.join(".").replace(Qk, "");
    if (this.V && this.H) {
        r = f + g;
        b: {
            c = this.H;d = [];
            if (c)
                for (l = h = e = 0; l < c.length; ++l) {
                    n = c.charCodeAt(l);
                    if (32 > n || 127 < n || !mk[n - 32]) {
                        c = [];
                        break b
                    }
                    e <<= 6;
                    e |= mk[n - 32] - 1;
                    h += 6;
                    8 <= h && (d.push(e >> h - 8 & 255), h -= 8)
                }
            c = d
        }
        e = c;
        c = {};
        c.va = Array(4);
        c.buffer = Array(4);
        c.wg = Array(4);
        c.padding = Array(64);
        c.padding[0] = 128;
        for (d = 1; 64 > d; ++d) c.padding[d] =
            0;
        qk(c);
        d = Array(64);
        64 < e.length && (qk(c), sk(c, e), e = tk(c));
        for (h = 0; h < e.length; ++h) d[h] = e[h] ^ 92;
        for (h = e.length; 64 > h; ++h) d[h] = 92;
        qk(c);
        for (h = 0; 64 > h; ++h) c.buffer[h] = d[h] ^ 106;
        rk(c, c.buffer);
        c.total = 64;
        sk(c, pk(r));
        r = tk(c);
        qk(c);
        rk(c, d);
        c.total = 64;
        sk(c, r);
        r = tk(c);
        r = r.slice(0, 8);
        w(r) && (r = pk(r));
        c = "";
        if (r) {
            d = r.length;
            for (l = h = e = 0; d--;)
                for (h <<= 8, h |= r[l++], e += 8; 6 <= e;) c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(h >> e - 6 & 63), e -= 6;
            e && (c += "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_".charAt(h <<
                8 >> e + 8 - 6 & 63))
        }
        r = c
    } else r = "";
    f = {
        oq: f,
        gs_l: g + "." + r
    };
    this.i.uf && (f.q = this.o.b);
    return f
};
q.reset = function() {
    this.u = y();
    ++this.T;
    this.o.ub();
    this.R.reset();
    this.b.ub();
    for (var a = 0, b; b = this.U[a++];) b.reset()
};
q.setToken = aa("H");

function Uk(a) {
    return a ? a.replace(Rk, "-") : ""
};

function Vk() {
    this.g = 121
}
A(Vk, T);
q = Vk.prototype;
q.Sa = function(a) {
    this.i = a.nb()
};
q.ya = function(a) {
    a.get(347);
    this.u = a.get(130);
    this.T = a.get(117);
    this.H = a.get(123);
    this.o = a.get(118);
    this.U = a.get(120);
    this.V = a.get(128);
    this.R = a.get(139);
    this.w = a.s;
    this.s = a.b[294] || []
};
q.wa = aa("S");
q.search = function(a, b) {
    if (this.s) {
        for (var c = !1, d = 0, e; e = this.s[d++];) 2 == Yi(e, a) && (c = !0);
        if (c) return
    }
    if (si(a) || this.S.lb || this.u && this.u.lb()) {
        if (Yh.test(b)) {
            if (this.i && !this.b) {
                c = this.i;
                b: {
                    if (d = c.getElementsByTagName("input")) {
                        e = 0;
                        for (var f; f = d[e++];)
                            if ("btnI" == f.name && "submit" != f.type.toLowerCase()) {
                                d = f;
                                break b
                            }
                    }
                    d = null
                }
                d ? c = null : (d = W("input"), d.type = "hidden", d.name = "btnI", d.value = "1", c.appendChild(d), c = d);
                this.b = c
            }
        } else this.b && (this.i.removeChild(this.b), this.b = null);
        this.w.search(a, b);
        Wk(this);
        U(this.T, 12, {
            query: a
        })
    }
};
q.redirect = function(a) {
    this.w.redirect(a);
    Wk(this)
};

function Wk(a) {
    var b = a.H;
    b.u = b.s;
    a.H.b = null;
    a.U.reset();
    a.V.clear();
    a.o.s != a.o.b && (b = a.o, b.s = b.b);
    a.R && a.R.clear()
};

function Xk() {
    this.g = 116;
    this.Yc = !0
}
A(Xk, T);
q = Xk.prototype;
q.Sa = function(a, b) {
    this.xd = a.Xb();
    b.addRule(".sbdd_a", (Li ? "margin-top:-1px;" : "") + "z-index:989");
    b.addRule(".sbdd_a[dir=ltr] .fl, .sbdd_a[dir=rtl] .fr", "float:left");
    b.addRule(".sbdd_a[dir=ltr] .fr, .sbdd_a[dir=rtl] .fl", "float:right");
    Li ? b.addRule(".sbdd_b", "background:#fff;border:1px solid #ccc;border-top-color:#d9d9d9;" + b.prefix("border-radius:0 0 3px 3px;") + b.prefix("box-shadow:0 2px 1px rgba(0,0,0,.1), 0 0 1px rgba(0,0,0,.1);") + "cursor:default") : b.addRule(".sbdd_b", "border:1px solid #ccc;border-top-color:#d9d9d9;" + b.prefix("box-shadow:0 2px 4px rgba(0,0,0,0.2);") +
        "cursor:default");
    b.addRule(".sbdd_c", "border:0;display:block;position:absolute;top:0;z-index:988")
};
q.ya = function(a) {
    this.T = a.get(130);
    a.get(115);
    this.Za = a.get(118);
    this.sc = a.get(117);
    this.U = a.o.getId()
};
q.setup = aa("b");
q.Eb = function(a) {
    this.i = X();
    this.i.className = "gstl_" + this.U + " sbdd_a";
    hj(this.i, !1);
    this.Fc = this.i;
    this.$b = X("fl");
    this.i.appendChild(this.$b);
    this.w = X();
    this.i.appendChild(this.w);
    this.s = X("sbdd_b");
    this.w.appendChild(this.s);
    this.V = X();
    this.w.appendChild(this.V);
    this.b.Se && (this.Ma = W("iframe", "gstl_" + this.U + " sbdd_c"), hj(this.Ma, !1), (this.b.Ja || document.body).appendChild(this.Ma));
    if (this.o = this.b.ae) ia(this.o) && (this.o += this.b.Fb[2], this.o -= Yk(this)), Zk(this, this.i, this.o);
    $k(this);
    (a.Ja || document.body).appendChild(this.i);
    a = this.sc;
    var b = x(this.vd, this);
    Y(a, a.i, 8, b, void 0, void 0)
};
q.wa = function(a) {
    this.b = a;
    this.i.style.position = a.Gb
};
q.vd = function() {
    this.H = 0;
    $k(this);
    if (this.Ma) {
        var a = this.b.Wd[0],
            b = this.Ma.style;
        "relative" != this.b.Gb && (b.top = this.i.style.top, b.left = this.i.offsetLeft + this.$b.offsetWidth + "px");
        b = this.Ma;
        this.H || (this.H = this.s ? Math.max(this.s.offsetHeight, 0) : 0);
        b.style.height = Math.max(this.H + a, 0) + "px";
        Zk(this, this.Ma, this.s.offsetWidth)
    }
    this.u && gk(this.u.b)
};

function $k(a) {
    var b, c, d, e;
    if (e = a.u) e = a.u.b, e = e.b.Ve || e.U == e.T ? e.Ha : null;
    b = (d = e) ? d.offsetWidth : al(a.Za.o);
    var f = a.o;
    e = Yk(a);
    f ? w(f) && (f = null) : a.yd || !a.Yc ? a.w.style.display = "inline-block" : (a.w.style.display = "", f = b + a.b.Fb[2] - e, Zk(a, a.i, f));
    if ("relative" != a.b.Gb) {
        var g = "rtl" == Si() != ("rtl" == a.S),
            h = a.b.Ja;
        c = {
            Na: 0,
            Nb: 0
        };
        if (g || !h || h == document.body || a.b.Kc) c = Ak(a.Za.o.S), d && (c.Na = Ak(d).Na);
        d = c;
        c = f;
        var f = a.b.Fb,
            h = f[1],
            l = a.Za.o,
            n = l.S ? l.S.offsetHeight : 0;
        l.W > n && (n = l.W);
        f = d.Nb + n + f[0];
        if ("right" == a.Vc) {
            c = "rtl" ==
                Si() != ("rtl" == a.S);
            l = a.b.Ja;
            h = -h;
            if (c || !l || l == document.body) h += (ik(a.i) || window).document.documentElement.clientWidth - b - d.Na;
            b = h;
            c = f;
            d = void 0
        } else d = d.Na + h, "center" == a.Vc && c && (d += (b - c) / 2), c = f, b = void 0;
        f = {
            Na: 0,
            Nb: 0
        };
        "absolute" == a.b.Gb && a.b.Ja && a.b.Ja != document.body && (g || a.b.Kc) && (f = Ak(a.b.Ja));
        h = a.i.style;
        h.top = c - f.Nb + "px";
        h.left = h.right = "";
        void 0 != d ? h.left = d + e - f.Na + "px" : (d = 0, a.b.Ja && g && (d = document.body.clientWidth - (f.Na + a.b.Ja.offsetWidth)), h.right = b + e - d + "px")
    }
}

function Zk(a, b, c) {
    ia(c) ? 0 < c && (a.b.Ld ? b.style.width = c + "px" : b.style.minWidth = c + "px") : b.style.width = c
}

function hj(a, b) {
    a && (a.style.display = b ? "" : "none")
}

function ij(a, b) {
    if (a.S != b) {
        a.S = b;
        var c = a.b.Ja;
        c && c != document.body && (c.style.textAlign = "rtl" == b ? "right" : "left");
        Dk(a.i, b)
    }
}

function Yk(a) {
    return a.T && a.T.i() && (a = a.Za.o.w.offsetWidth, ia(a)) ? a : 0
};

function bl() {
    this.g = 119;
    this.qa = !1;
    this.u = ri(0);
    this.Ba = -1;
    this.Ca = !1
}
A(bl, T);
q = bl.prototype;
q.Sa = function(a, b) {
    this.U = a;
    this.b = a.Be();
    this.b.setAttribute("aria-haspopup", !1);
    this.b.setAttribute("role", "combobox");
    this.b.setAttribute("aria-autocomplete", "both");
    a.Vd() || (b.addRule(".sbib_a", "background:#fff;" + b.prefix("box-sizing:border-box;")), b.addRule(".sbib_b", b.prefix("box-sizing:border-box;") + "height:100%;overflow:hidden;padding:4px 6px 0"), b.addRule(".sbib_c[dir=ltr]", "float:right"), b.addRule(".sbib_c[dir=rtl]", "float:left"), b.addRule(".sbib_d", b.prefix("box-sizing:border-box;") + "height:100%;unicode-bidi:embed;white-space:nowrap"), b.addRule(".sbib_d[dir=ltr]", "float:left"), b.addRule(".sbib_d[dir=rtl]", "float:right"), Di && b.addRule(".sbib_a input::-ms-clear", "display: none"), b.addRule(".sbib_a,.sbib_c", "vertical-align:top"))
};
q.ya = function(a) {
    this.i = a.get(118);
    this.o = a.get(117);
    this.Ha = a.get(128);
    this.V = a.get(173);
    this.Pa = !!a.get(136);
    this.Ab = a.o.getId()
};
q.setup = function(a) {
    this.T = a;
    this.W = a.nf;
    this.ha = a.qf;
    this.hb = a.ie;
    this.H = Bk(this.b);
    this.Ob();
    var b = this;
    Ci && Y(this.o, this.b, "beforedeactivate", function(a) {
        b.Ca && (b.Ca = !1, a.Lb = !0)
    }, 10);
    Ei && cl(this);
    this.S = this.b
};
q.Eb = function(a) {
    var b = !!a.je[130];
    if (this.Pa || zj(this.i) || b || a.we)(this.s = this.U.get("gs_id")) ? (b && (this.w = this.U.get("sb_chc")), this.R = this.U.get("sb_ifc")) : (this.s = X("gstl_" + this.Ab + " sbib_a"), a = this.s.style, this.ha && (a.width = this.ha + "px"), this.W && (a.height = this.W + "px"), a = this.b.style, a.border = "none", a.padding = Fi || Ci ? "0 1px" : "0", a.margin = "0", a.height = "auto", a.width = "100%", this.b.className = this.T.Xc, b && (this.w = X("sbib_d"), this.w.id = this.U.getId("sb_chc"), this.s.appendChild(this.w)), zj(this.i) &&
        this.V && (this.V.Da().className += " sbib_c", this.s.appendChild(this.V.Da())), this.R = X("sbib_b"), this.R.id = this.U.getId("sb_ifc"), this.s.appendChild(this.R), dl(this, this.s, this.R)), Ki && Gi && (this.b.style.height = "1.25em", this.b.style.marginTop = "-0.0625em"), el(this, this.s), this.S = this.s;
    this.hb && (b = x(this.Of, this), Y(this.o, this.b, "blur", b, 10), b = x(this.qd, this), Y(this.o, this.b, "focus", b, 10), this.kb = !0);
    b = this.o;
    a = x(this.Qe, this);
    Y(b, b.i, 8, a, void 0, void 0);
    fl(this)
};
q.wa = function(a) {
    this.T = a;
    this.b.setAttribute("autocomplete", "off");
    this.b.setAttribute("spellcheck", !1);
    this.b.style.outline = a.Mf ? "" : "none";
    this.kb && this.qd();
    gl(this)
};

function dl(a, b, c) {
    hl(a);
    c || (c = b);
    a.b.parentNode.replaceChild(b, a.b);
    c.appendChild(a.b);
    a.H && a.T.Tf && (Ci || Ei ? mj(a.o, function() {
        a.b.focus();
        zk(a.b, a.u.Hb())
    }) : a.b.focus());
    gl(a)
}

function Cj(a, b) {
    a.R && (a.R.dir = b);
    a.b.dir = b;
    a.w && (a.w.dir = b);
    a.V && Cj(a.V, b);
    if (a.Pa) {
        var c = a.b,
            d = 0,
            e = c.style;
        "INPUT" != c.nodeName && (d += 1);
        e.left = e.right = "";
        e["rtl" == b ? "right" : "left"] = d + "px"
    }
}

function al(a) {
    return a.ha ? a.ha : a.S ? a.S.offsetWidth : 0
}
q.select = function() {
    this.b.select();
    this.Ob()
};
q.refresh = function() {
    Ji && (this.b.value = "");
    this.b.value = this.i.b;
    Ji && (this.b.value = this.b.value);
    if (this.H) {
        var a = this.b.value.length;
        this.u = ri(a);
        zk(this.b, a)
    }
};
q.clear = function() {
    this.b.value = ""
};

function el(a, b) {
    Y(a.o, b, "mouseup", function() {
        a.b.focus()
    })
}

function fl(a) {
    function b(b) {
        Y(a.o, a.b, b, x(a.nd, a), 10, c)
    }
    Y(a.o, a.b, "keydown", x(a.Oe, a));
    (Fi || a.T.Xd) && Y(a.o, a.b, "keypress", x(a.Pe, a));
    Y(a.o, a.b, "select", x(a.Ob, a), 10);
    var c = !1;
    b("mousedown");
    b("keyup");
    b("keypress");
    c = !0;
    b("mouseup");
    b("keydown");
    b("focus");
    b("blur");
    b("cut");
    b("paste");
    b("input");
    var d = x(a.Je, a);
    Y(a.o, a.b, "compositionstart", d);
    Y(a.o, a.b, "compositionend", d)
}
q.Je = function(a) {
    a = a.type;
    "compositionstart" == a ? (a = this.i, 1 != a.R && (a.R = !0)) : "compositionend" == a && (a = this.i, 0 != a.R && (a.R = !1))
};
q.Oe = function(a) {
    var b = a.keyCode;
    this.Ba = b;
    var c = (Gi || Ei) && (38 == b || 40 == b) && pj(this.Ha),
        d = 13 == b,
        e = 27 == b;
    this.Aa = !1;
    9 == b && (this.Aa = oj(this.i));
    if (d) {
        (b = qj(this.Ha)) && b.ma();
        var f = this;
        mj(this.o, function() {
            var b = f.Ha,
                c = a.shiftKey ? 4 : 3;
            null != b.i && qj(b).ma();
            b.w.search(c)
        })
    }
    if (c || d || e || this.Aa) a.Lb = !0
};
q.Pe = function(a) {
    var b = a.keyCode,
        c = 9 == b && this.Aa;
    if (13 == b || 27 == b || c) a.Lb = !0
};
q.nd = function(a) {
    if (!this.Ta) {
        var b = a.yb;
        if (!(b.indexOf("key") || a.ctrlKey || a.altKey || a.shiftKey || a.metaKey)) a: if (a = a.keyCode, "keypress" != b) {
            var c = 38 == a || 40 == a,
                d;
            if ("keydown" == b) {
                d = this.i;
                var e = 229 == a;
                (d.V = e) && (d.T.b[4] = !0);
                if (c) break a
            } else if (d = a != this.Ba, this.Ba = -1, !c || d) break a;
            switch (a) {
                case 27:
                    a = this.i;
                    a.u.Zf ? a.search(5) : (a.i.La() ? (c = a.i, d = c.ha, d.u = d.s, nj(c)) : xj(a), yj(a));
                    break;
                case 37:
                    Aj(this.i, "rtl");
                    break;
                case 39:
                    Aj(this.i, "ltr");
                    break;
                case 38:
                    this.i.i.ud();
                    break;
                case 40:
                    a = this.i;
                    c = this.u;
                    pj(a.i) ? a.i.td() : tj(a.i, c);
                    break;
                case 46:
                    a = this.i;
                    a.b && this.u.Mc() == a.b.length && (a.ra && a.ra.clear(), a.u.Yf && a.search(2));
                    break;
                case 8:
                    a = this.i, a.S && 0 == this.u.Hb() && a.S.b()
            }
        }
        this.Ob();
        rj(this.i, this.b.value, this.u, b)
    }
};
q.Ie = function() {
    this.H = !0;
    U(this.i.w, 10)
};
q.Fe = function() {
    this.H = !1;
    lj(this.i)
};

function gl(a) {
    a.qa || (a.qa = !0, a.Oa = x(a.Ie, a), Y(a.o, a.b, "focus", a.Oa, 99), a.Ia = x(a.Fe, a), Y(a.o, a.b, "blur", a.Ia, 99))
}

function hl(a) {
    a.qa && (a.qa = !1, Mk(a.o, a.b, a.Oa), Mk(a.o, a.b, a.Ia))
}
q.qd = function() {
    if (!this.ra) {
        var a = this.T.Rf || 50;
        this.ra = window.setInterval(x(this.Qf, this), a)
    }
};
q.Of = function() {
    this.ra && (window.clearTimeout(this.ra), this.ra = null)
};
q.Qf = function() {
    this.nd({
        yb: "polling"
    })
};
q.Qe = function() {
    if (Ei) {
        var a = this.b,
            b = document.createEvent("KeyboardEvent");
        b.initKeyEvent && (b.initKeyEvent("keypress", !0, !0, null, !1, !1, !0, !1, 27, 0), a.dispatchEvent(b))
    }
};
q.Ob = function() {
    if (this.H) {
        var a;
        a: {
            var b = this.b;
            try {
                var c, d;
                if ("selectionStart" in b) c = b.selectionStart, d = b.selectionEnd;
                else {
                    var e = b.createTextRange(),
                        f = Ck(b).selection.createRange();
                    e.inRange(f) && (e.setEndPoint("EndToStart", f), c = e.text.length, e.setEndPoint("EndToEnd", f), d = e.text.length)
                }
                if (void 0 !== c) {
                    a = ri(c, d);
                    break a
                }
            } catch (g) {}
            a = null
        }
        a && (this.u = a)
    }
};

function cl(a) {
    var b;
    Nk(window, "pagehide", function() {
        a.Ta = !0;
        b = a.b.value
    });
    Nk(window, "pageshow", function(c) {
        a.Ta = !1;
        if (c.persisted || void 0 !== b) {
            c = a.i;
            var d = b;
            uj(c, d);
            c.o.refresh();
            U(c.w, 4, {
                Va: c.H,
                input: d
            })
        }
    })
}

function gj(a, b) {
    a.b.setAttribute("aria-haspopup", b);
    b || a.b.removeAttribute("aria-activedescendant")
};

function il() {
    this.g = 129;
    this.W = {};
    this.ha = [];
    this.ra = [];
    this.Ba = [];
    this.R = [];
    this.Ca = 0
}
A(il, T);
q = il.prototype;
q.Sa = function(a, b) {
    this.Ia = a;
    this.U = a.Xb();
    Li || b.addRule(".sbsb_a", "background:#fff");
    b.addRule(".sbsb_b", "list-style-type:none;margin:0;padding:0");
    Li || b.addRule(".sbsb_c", "line-height:22px;overflow:hidden;padding:0 7px");
    b.addRule(".sbsb_d", "background:#eee");
    b.addRule(".sbsb_e", "height:1px;background-color:#e5e5e5");
    b.addRule("#sbsb_f", "font-size:11px;color:#36c;text-decoration:none");
    b.addRule("#sbsb_f:hover", "font-size:11px;color:#36c;text-decoration:underline");
    b.addRule(".sbsb_g", "text-align:center;padding:8px 0 7px;position:relative");
    b.addRule(".sbsb_h", "font-size:15px;height:28px;margin:0.2em" + (Gi ? ";-webkit-appearance:button" : ""));
    b.addRule(".sbsb_i", "font-size:13px;color:#36c;text-decoration:none;line-height:100%");
    b.addRule(".sbsb_i:hover", "text-decoration:underline");
    b.addRule(".sbsb_j", "padding-top:1px 0 2px 0;font-size:11px");
    b.addRule(".sbdd_a[dir=ltr] .sbsb_j", "padding-right:4px;text-align:right");
    b.addRule(".sbdd_a[dir=rtl] .sbsb_j", "padding-left:4px;text-align:left");
    Li && (b.addRule(".sbsb_c[dir=ltr] .sbsb_k", "padding:10px 3px 11px 8px"), b.addRule(".sbsb_c[dir=rtl] .sbsb_k", "padding:10px 8px 11px 3px"))
};
q.ya = function(a) {
    this.S = a.get(128);
    this.o = a.get(118);
    this.V = a.get(121);
    a = a.b[152] || [];
    var b = {};
    if (a)
        for (var c = 0, d; d = a[c++];) b[d.s] = d;
    this.Aa = b
};
q.setup = aa("b");
q.Eb = function() {
    this.s = X();
    this.u = W("ul", "sbsb_b");
    this.u.setAttribute("role", "listbox");
    this.s.appendChild(this.u)
};
q.wa = function(a) {
    this.b = a;
    var b = a.md;
    b && (this.Ha = this.Ia.xe(b));
    this.s.className = a.og || "sbsb_a";
    this.qa = a.lg || "sbsb_d"
};
q.render = function(a, b) {
    if (!this.s) return !1;
    this.T = b;
    gk(this);
    for (var c = !1, d = 0, e; e = a[d++];)
        if (1 == e)
            if (this.H) this.H.style.display = "";
            else {
                e = X();
                var f = e.style;
                f.position = "relative";
                f.textAlign = "center";
                f.whiteSpace = "nowrap";
                e.dir = this.U;
                this.i = X();
                this.i.className = "sbsb_g";
                this.b.Sc && (this.i.style.paddingBottom = "1px");
                jl(this, this.b.$f, this.i, 13);
                this.b.Xe ? jl(this, this.b.te, this.i, 8) : this.b.$e && jl(this, this.b.ag, this.i, 14);
                e.appendChild(this.i);
                e.onmousedown = x(this.lc, this);
                e.className = this.b.uc;
                this.H =
                    e;
                this.s.appendChild(this.H)
            }
    else 2 == e ? this.w ? this.w.style.display = "" : (e = X("sbsb_j " + this.b.uc), f = W("a"), f.id = "sbsb_f", f.href = "http://www.google.com/support/websearch/bin/answer.py?hl=" + this.b.Zb + "&answer=106230", f.innerHTML = this.b.wf, e.appendChild(f), e.onmousedown = x(this.lc, this), this.w = e, this.s.appendChild(this.w)) : 3 == e ? (e = this.Ba.pop(), e || (e = W("li"), e.b = !0, f = W("div", "sbsb_e"), e.appendChild(f)), this.u.appendChild(e)) : hk(this, e) && (c = !0);
    return c
};

function Ij(a, b) {
    var c = a.R[b];
    c && (c = c.Da().parentNode, di(c, a.qa))
}
q.clear = function() {
    for (var a, b, c; c = this.ha.pop();) a = c.ma(), (b = this.W[a]) || (b = this.W[a] = []), b.push(c), a = c.Da(), a.parentNode.removeChild(a);
    for (; a = this.u.firstChild;) a = this.u.removeChild(a), a.b ? this.Ba.push(a) : a != this.H && a != this.w && this.ra.push(a);
    this.H && (this.H.style.display = "none");
    this.w && (this.w.style.display = "none");
    this.R = []
};
q.Da = m("s");

function hk(a, b) {
    var c = b.ma(),
        d = a.Aa[c];
    if (!d) return !1;
    c = (c = a.W[c]) && c.pop();
    if (!c) {
        var c = d.b(a.V),
            e = c.Da();
        e.setAttribute("role", "option");
        e.id = "sbse" + a.Ca;
        a.Ca++
    }
    d.render(b, c);
    a.ha.push(c);
    var e = c.Da(),
        f = kl(a);
    f.appendChild(e);
    var g;
    if (void 0 !== b.w) {
        a.R.push(c);
        g = a.T;
        var h = b.o;
        a.b.jf && (e.onmouseover = function() {
            Ej(a.S, h)
        }, e.onmouseout = function() {
            Jj(a.S)
        });
        var l = c.Da();
        l.onclick = function(c) {
            xj(a.o);
            b.g && sj(a.o, b.b);
            Jj(a.S);
            var e = a.S;
            e.i = e.b = h;
            c = c || ik(l).event;
            d.i(c, b, a.V)
        }
    } else g = a.U;
    Dk(f, g);
    return !0
}

function jl(a, b, c, d) {
    var e = W("input");
    e.type = "button";
    e.value = ui(b);
    e.onclick = function() {
        a.V.search(a.o.b, d)
    };
    var f;
    if (a.b.Ue) {
        b = "lsb";
        f = W("span");
        var g = W("span");
        f.className = "ds";
        g.className = "lsbb";
        f.appendChild(g);
        g.appendChild(e)
    } else b = "sbsb_h", f = e;
    e.className = b;
    c.appendChild(f)
}

function kl(a) {
    var b = a.ra.pop();
    if (b) return a.u.appendChild(b), b;
    b = W("li");
    b.className = "sbsb_c " + a.b.uc;
    b.onmousedown = x(a.lc, a);
    a.u.appendChild(b);
    return b
}
q.lc = function(a) {
    a = a || ik(this.s).event;
    a.stopPropagation ? a.stopPropagation() : !Fi && Ci && (this.o.o.Ca = !0);
    return !1
};

function gk(a) {
    if (a.i) {
        var b = 0,
            c = a.o.o.w;
        c && (b = c.offsetWidth);
        b = al(a.o.o) - b - 3;
        0 < b && (a.i.style.width = b + "px")
    }
};

function ll(a, b, c, d, e) {
    var f = Ei ? "-moz-" : Ci ? "-ms-" : Fi ? "-o-" : Gi ? "-webkit-" : "",
        g = ".gstl_" + d,
        h = new RegExp("(\\.(" + e.join("|") + ")\\b)"),
        l = [];
    return {
        addRule: function(a, d) {
            if (b) {
                if (c) {
                    for (var e = a.split(","), f = [], n = 0, p; p = e[n++];) p = h.test(p) ? p.replace(h, g + "$1") : g + " " + p, f.push(p);
                    a = f.join(",")
                }
                l.push(a, "{", d, "}")
            }
        },
        Td: function() {
            if (b && l.length) {
                b = !1;
                var c = W("style");
                c.setAttribute("type", "text/css");
                (a || ni).appendChild(c);
                var d = l.join("");
                l = null;
                c.styleSheet ? c.styleSheet.cssText = d : c.appendChild(document.createTextNode(d))
            }
        },
        prefix: function(a, b) {
            var c = a + (b || "");
            f && (c += b ? a + f + b : f + a);
            return c
        }
    }
};

function ml() {
    this.g = 147
}
A(ml, T);
ml.prototype.Sa = function(a) {
    this.u = a.nb() || document.body
};
ml.prototype.setup = aa("w");

function nl() {
    xk.call(this, 79)
}
A(nl, xk);
nl.prototype.b = function() {
    return new Fk
};
nl.prototype.render = function(a, b) {
    b.render(a.i, a.b, a.ta())
};
nl.prototype.i = function(a, b, c) {
    c.search(b.b, 1)
};
nl.prototype.o = function(a, b) {
    return "GUIDED_HELP" == a.ta().Ea("t") ? b : a.b
};

function ol() {
    xk.call(this, 0)
}
A(ol, xk);
ol.prototype.b = function() {
    return new Fk
};
ol.prototype.render = function(a, b) {
    b.render(a.i, a.b)
};
ol.prototype.i = function(a, b, c) {
    c.search(b.b, 1)
};

function pl() {
    Pi.call(this);
    this.set(191, new lk);
    this.set(150, new uk);
    this.set(146, new vk);
    this.set(147, new ml);
    Qi(this, 149, new Gk);
    this.set(145, new Nj);
    this.set(117, new Hk);
    this.set(494, new Qj);
    this.set(374, new Rj);
    this.set(120, new Pk);
    this.set(121, new Vk);
    this.set(553, new Sj);
    this.set(124, new dk);
    this.set(125, new ek);
    this.set(123, new Uj);
    this.set(126, new jk);
    this.set(127, new kk);
    this.set(115, new cj);
    this.set(118, new jj);
    this.set(128, new Dj);
    Qi(this, 154, new Mj);
    this.set(116, new Xk);
    this.set(119, new bl);
    this.set(129, new il)
}
A(pl, Pi);

function ql(a, b, c, d, e) {
    this.i = a;
    this.S = b;
    this.w = c;
    this.H = d;
    this.g = void 0 === e ? -1 : e;
    this.o = !1
}
q = ql.prototype;
q.install = function(a) {
    if (!this.o) {
        a = rl(a);
        0 > this.g && (this.g = sl(a));
        var b = Ck(this.i),
            c = tl(this),
            d = !!b.getElementById("gs_id" + this.g),
            e = this,
            f = ["gssb_c", "gssb_k", "sbdd_a", "sbdd_c", "sbib_a"];
        a.Gd && f.push(a.Gd);
        f = ll(a.Bd, a.af, a.he, this.g, f);
        this.u = a.lb;
        this.b = new Ui(this.w, this.H, {
            Vd: function() {
                return d
            },
            get: function(a) {
                return b.getElementById(a + e.g)
            },
            xe: function(a) {
                return b.getElementById(a)
            },
            nb: function() {
                return e.S
            },
            Xb: function() {
                return c
            },
            getId: function(a) {
                return a + e.g
            },
            Be: function() {
                return e.i
            }
        }, f, this, a);
        this.b.get(347);
        this.s = this.b.get(130);
        this.b.get(115);
        this.R = this.b.get(117);
        this.b.get(123);
        this.b.get(118);
        this.b.get(119);
        this.b.get(374);
        this.T = this.b.get(120);
        this.b.get(189);
        this.b.get(553);
        this.b.get(419);
        this.b.get(126);
        this.U = this.b.get(128);
        this.b.get(139);
        this.V = this.b.get(121);
        ul(this);
        this.o = !0
    }
};
q.getId = m("g");
q.ub = function() {
    this.T.reset()
};
q.search = function(a, b) {
    this.V.search(a, b)
};
q.lb = function() {
    return this.u || !!this.s && this.s.lb()
};

function sl(a) {
    a = ik(a.Bd || ni);
    void 0 == a.nextSearchboxId && (a.nextSearchboxId = 50);
    return a.nextSearchboxId++
}

function tl(a) {
    if (a.i)
        for (a = a.i; a = a.parentNode;) {
            var b = a.dir;
            if (b) return b
        }
    return "ltr"
}

function rl(a) {
    a = Bi(a);
    var b = a.hd;
    b ? a.hd = b.toLowerCase() : a.Ye = !1;
    a.Ub && !a.se && (a.Ub = !1);
    Ii || (a.vf = !1);
    return a
}

function ul(a) {
    var b = ik(a.i),
        c = Ek(b);
    Nk(b, "resize", function() {
        var d = Ek(b);
        if (d.ab != c.ab || d.Tc != c.Tc) c = d, U(a.R, 8)
    })
};

function vl() {
    this.g = !1;
    this.i = null;
    this.b = new O
}
A(vl, Ti);
q = vl.prototype;
q.install = function(a, b, c, d, e, f, g, h, l) {
    this.s = d;
    this.o = e;
    d = Wi().Yb();
    "17" != b && "83757" != b && (d.od = h || "www.google.com");
    d.Rb = "help";
    d.Dc = "help";
    d.qc = "help";
    h = (h = c.match(/^\w{2,3}([-_]|$)/)) ? h[0].replace(/[_-]/g, "") : "";
    d.Zb = h;
    h = c.split(/[-_]/g);
    (h = 1 < h.length && h[1].match(/^[a-zA-Z]{4}$/) ? h[1] : "") || (h = (c = c.match(/[-_]([a-zA-Z]{2}|\d{3})([-_]|$)/)) ? c[0].replace(/[_-]/g, "") : "");
    d.Ad = h;
    l ? d.md = l : d.Fb = [8, 0, 0];
    d.Ld = !0;
    l = [0];
    f && l.push(79);
    d.Oh = qi(l);
    l = new pl;
    Qi(l, 156, new Xi(b));
    Qi(l, 152, new nl);
    Qi(l, 152, new ol);
    l.set(157, new bj);
    this.u = new $i(5, f, g);
    Qi(l, 122, this.u);
    this.i = new ql(a, null, this, l);
    this.i.install(d)
};
q.$c = function(a) {
    a.addRule(".sbdd_a", "z-index: 1202")
};
q.search = function(a, b) {
    1 == b && (this.g = !0);
    var c = qj(this.i.U);
    if (c && 79 == c.ma()) {
        var d = c.ta(),
            c = d.Ea("t"),
            d = d.Ea("p");
        this.o && this.o(c, d, a)
    } else this.s && this.s(a)
};
q.Ic = function() {
    this.g = !0;
    this.b.Wa("OSC")
};
q.Gc = function() {
    this.b.Wa("OSS")
};
q.Hc = function() {
    this.b.Wa("OSH")
};

function wl(a, b) {
    this.R = a;
    this.i = b || document;
    this.o = this.g = this.b = null;
    this.w = !1;
    this.s = null;
    xl(this)
}

function xl(a) {
    a.b = a.i.querySelector("#gbqf, .gaiabar form, .non-one-bar form");
    a.g = a.i.querySelector('#gbqfq, .gaiabar form input[name="q"], .non-one-bar input[name="q"]');
    a.b && a.g && (a.b.id = "search-form", a.s = new vl, a.s.install(a.g, a.R.eid, D().lang, a.u.bind(a), a.H.bind(a), ["HELP_ARTICLE"], void 0, void 0, "search-form"), a.o = a.i.querySelector('#gbqfb, .gaiabar form button[role="button"]'), a.o && a.o.addEventListener("click", function(a) {
        a.preventDefault();
        this.u()
    }.bind(a)))
}
wl.prototype.u = function() {
    this.w || (window.sc_trackStatsEvent(Ja, this.s.g ? zb : yb, this.g.value), this.b.submit(), this.w = !0)
};
wl.prototype.H = function(a, b) {
    var c = b.url;
    window.sc_trackStatsEvent(Ja, qb, c, void 0, function() {
        H(c)
    })
};
window.sc_initSearchAutocomplete = function(a) {
    function b() {
        new wl(a, window.sc_scope)
    }
    b();
    window.sc_reinitSearchAutocomplete = b
};


function ym(a) {
    this.b = a || document
}
ym.prototype.init = function() {
    for (var a = this.b.querySelectorAll(".zippy"), b = null, c = 0; c < a.length; c++) {
        var d = c + 1,
            e = a[c],
            f = e.nextElementSibling;
        if (f && ("DIV" === f.nodeName || "P" === f.nodeName)) {
            var g = document.createElement("DIV");
            B(g, "zippy-container", !0);
            e.parentNode.replaceChild(g, e);
            g.appendChild(e);
            var h = document.createElement("DIV");
            h.className = "zippy-overflow";
            f.parentNode.insertBefore(h, f);
            h.appendChild(f);
            B(e, "index" + d, !0);
            B(f, "zippy-content", !0);
            C(e, "zippy-expand") || e.name && zm(D().query + window.location.hash, e.name) ? (B(e, "goog-zippy-expanded", !0), f.removeAttribute("aria-hidden"), e.setAttribute("aria-expanded", !0), f.style.marginTop = 0, !b && e.name && zm(D().query + window.location.hash, e.name) && (b = e)) : (Am(f), f.style.height = f.style.padding = 0, f.setAttribute("aria-hidden", !0), e.setAttribute("aria-expanded", !1), B(f, "zippy-hidden", !0), B(e, "goog-zippy-collapsed", !0));
            window.addEventListener("resize", function(a) {
                C(a, "zippy-hidden") && Bm(a, "", function() {
                    Am(a)
                }.bind(this))
            }.bind(this, f));
            (h = h.nextElementSibling) && C(h, "zippy") || B(g, "zippy-last", !0);
            "A" === e.nodeName ? e.href = "javascript:;" : e.tabIndex = 0;
            e.setAttribute("role", "button");
            e.setAttribute("aria-haspopup", "true");
            e.addEventListener("click", this.g.bind(this, f, e));
            e.addEventListener("keydown", this.o.bind(this, f, e));
            e.setAttribute("data-tracking-impression", "");
            e.setAttribute("st-ve", Ga.id);
            e.setAttribute("st-imp", "");
            e.setAttribute("st-idx", d + "," + a.length);
            e.setAttribute("st-ignore", "");
            Cm(this, e, f)
        }
    }
    b && b.scrollIntoView()
};

function Bm(a, b, c) {
    a.style.transition != b ? (a.style.transition = b, window.setTimeout(c, 0)) : c()
}

function zm(a, b) {
    return (new RegExp("[?#&,]" + oa(b) + "(?:[#&,]|$)")).test(a)
}

function Am(a) {
    a.style.marginTop = -a.offsetHeight + "px"
}
ym.prototype.g = function(a, b) {
    B(a, "zippy-hidden");
    B(b, "goog-zippy-expanded");
    B(b, "goog-zippy-collapsed");
    var c;
    C(b, "goog-zippy-expanded") ? (a.removeAttribute("aria-hidden"), b.setAttribute("aria-expanded", !0), c = I, Dm(a)) : (a.setAttribute("aria-hidden", !0), b.setAttribute("aria-expanded", !1), c = ib, Bm(a, "margin-top .218s ease-out", function() {
        Am(a)
    }.bind(this)));
    window.sc_trackStatsEventByElement(b, Ga, c)
};
ym.prototype.o = function(a, b, c) {
    switch (c.which) {
        case 13:
        case 32:
            c.preventDefault(), this.g(a, b)
    }
};

function Dm(a) {
    Em(a);
    a.style.height = a.style.padding = "";
    Bm(a, "margin-top .218s ease-out", function() {
        a.style.overflow = "auto";
        a.style.marginTop = 0
    });
    G(document, "imgLazyLoad")
}

function Em(a) {
    a = a.getElementsByClassName("goog-zippy-collapsed");
    for (var b = 0; b < a.length; b++) {
        var c = a[b].parentNode.nextElementSibling;
        c && (c = c.firstChild) && Am(c)
    }
}

function Cm(a, b, c) {
    if (b.name)
        for (var d = a.b.getElementsByTagName("a"), e = 0; e < d.length; e++) {
            var f = d[e];
            zm(f.href, b.name) && f.addEventListener("click", a.i.bind(a, b, c))
        }
}
ym.prototype.i = function(a, b) {
    C(a, "goog-zippy-expanded") || (B(b, "zippy-hidden", !1), B(a, "goog-zippy-expanded", !0), B(a, "goog-zippy-collapsed", !1), Dm(b), window.sc_trackStatsEventByElement(a, Ga, I))
};
window.sc_initZippy = function() {
    (new ym(window.sc_scope)).init()
};



var xd = {};

function yd() {
    this.b = "";
    this.g = xd
}
var zd = {
    cellpadding: "cellPadding",
    cellspacing: "cellSpacing",
    colspan: "colSpan",
    frameborder: "frameBorder",
    height: "height",
    maxlength: "maxLength",
    nonce: "nonce",
    role: "role",
    rowspan: "rowSpan",
    type: "type",
    usemap: "useMap",
    valign: "vAlign",
    width: "width"
};

function Ad(a, b) {
    for (var c in a) b.call(void 0, a[c], c, a)
}

function Bd(a, b) {
    Ad(b, function(b, d) {
        "style" == d ? a.style.cssText = b : "class" == d ? a.className = b : "for" == d ? a.htmlFor = b : zd.hasOwnProperty(d) ? a.setAttribute(zd[d], b) : 0 == d.lastIndexOf("aria-", 0) || 0 == d.lastIndexOf("data-", 0) ? a.setAttribute(d, b) : a[d] = b
    })
}

function P(a) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, P);
    else {
        var b = Error().stack;
        b && (this.stack = b)
    }
    a && (this.message = String(a))
}
A(P, Error);
P.prototype.name = "CustomError";

function Cd() {
    this.b = y()
}
new Cd;
Cd.prototype.set = aa("b");
Cd.prototype.reset = function() {
    this.set(y())
};
Cd.prototype.get = m("b");

function Dd() {}
Dd.prototype.b = fa;
var Ed;

function Fd() {}
A(Fd, Dd);
Fd.prototype.b = function() {
    var a;
    a: {
        if (!this.g && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
            for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
                var d = b[c];
                try {
                    new ActiveXObject(d);
                    a = this.g = d;
                    break a
                } catch (e) {}
            }
            throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
        }
        a = this.g
    }
    return a ? new ActiveXObject(a) : new XMLHttpRequest
};
Ed = new Fd;

function Gd(a, b, c) {
    this.o = c;
    this.i = a;
    this.s = b;
    this.g = 0;
    this.b = null
}
Gd.prototype.get = function() {
    var a;
    0 < this.g ? (this.g--, a = this.b, this.b = a.next, a.next = null) : a = this.i();
    return a
};
Gd.prototype.put = function(a) {
    this.s(a);
    this.g < this.o && (this.g++, a.next = this.b, this.b = a)
};

function Hd(a) {
    v.setTimeout(function() {
        throw a;
    }, 0)
}
var Id;

function Jd() {
    var a = v.MessageChannel;
    "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !L("Presto") && (a = function() {
        var a = document.createElement("IFRAME");
        a.style.display = "none";
        a.src = "";
        document.documentElement.appendChild(a);
        var b = a.contentWindow,
            a = b.document;
        a.open();
        a.write("");
        a.close();
        var c = "callImmediate" + Math.random(),
            d = "file:" == b.location.protocol ? "*" : b.location.protocol + "//" + b.location.host,
            a = x(function(a) {
                if (("*" == d || a.origin == d) && a.data ==
                    c) this.port1.onmessage()
            }, this);
        b.addEventListener("message", a, !1);
        this.port1 = {};
        this.port2 = {
            postMessage: function() {
                b.postMessage(c, d)
            }
        }
    });
    if ("undefined" !== typeof a && !mc()) {
        var b = new a,
            c = {},
            d = c;
        b.port1.onmessage = function() {
            if (void 0 !== c.next) {
                c = c.next;
                var a = c.cb;
                c.cb = null;
                a()
            }
        };
        return function(a) {
            d.next = {
                cb: a
            };
            d = d.next;
            b.port2.postMessage(0)
        }
    }
    return "undefined" !== typeof document && "onreadystatechange" in document.createElement("SCRIPT") ? function(a) {
        var b = document.createElement("SCRIPT");
        b.onreadystatechange = function() {
            b.onreadystatechange = null;
            b.parentNode.removeChild(b);
            b = null;
            a();
            a = null
        };
        document.documentElement.appendChild(b)
    } : function(a) {
        v.setTimeout(a, 0)
    }
};
var Ld = new Gd(function() {
    return new Kd
}, function(a) {
    a.reset()
}, 100);

function Md() {
    var a = Nd,
        b = null;
    a.b && (b = a.b, a.b = a.b.next, a.b || (a.g = null), b.next = null);
    return b
}

function Kd() {
    this.next = this.scope = this.b = null
}
Kd.prototype.set = function(a, b) {
    this.b = a;
    this.scope = b;
    this.next = null
};
Kd.prototype.reset = function() {
    this.next = this.scope = this.b = null
};

function Od(a, b) {
    Pd || Qd();
    Rd || (Pd(), Rd = !0);
    var c = Nd,
        d = Ld.get();
    d.set(a, b);
    c.g ? c.g.next = d : c.b = d;
    c.g = d
}
var Pd;

function Qd() {
    var a = v.Promise;
    if (-1 != String(a).indexOf("[native code]")) {
        var b = a.resolve(void 0);
        Pd = function() {
            b.then(Sd)
        }
    } else Pd = function() {
        var a = Sd;
        !ja(v.setImmediate) || v.Window && v.Window.prototype && !L("Edge") && v.Window.prototype.setImmediate == v.setImmediate ? (Id || (Id = Jd()), Id(a)) : v.setImmediate(a)
    }
}
var Rd = !1,
    Nd = new function() {
        this.g = this.b = null
    };

function Sd() {
    for (var a; a = Md();) {
        try {
            a.b.call(a.scope)
        } catch (b) {
            Hd(b)
        }
        Ld.put(a)
    }
    Rd = !1
};

function Td(a) {
    a.prototype.then = a.prototype.then;
    a.prototype.$goog_Thenable = !0
}

function Ud(a) {
    if (!a) return !1;
    try {
        return !!a.$goog_Thenable
    } catch (b) {
        return !1
    }
};

function Q(a, b) {
    this.b = 0;
    this.w = void 0;
    this.o = this.g = this.i = null;
    this.s = this.u = !1;
    if (a != ea) try {
        var c = this;
        a.call(b, function(a) {
            Vd(c, 2, a)
        }, function(a) {
            Vd(c, 3, a)
        })
    } catch (d) {
        Vd(this, 3, d)
    }
}

function Wd() {
    this.next = this.i = this.g = this.o = this.b = null;
    this.s = !1
}
Wd.prototype.reset = function() {
    this.i = this.g = this.o = this.b = null;
    this.s = !1
};
var Xd = new Gd(function() {
    return new Wd
}, function(a) {
    a.reset()
}, 100);

function Yd(a, b, c) {
    var d = Xd.get();
    d.o = a;
    d.g = b;
    d.i = c;
    return d
}

function Zd(a) {
    if (a instanceof Q) return a;
    var b = new Q(ea);
    Vd(b, 2, a);
    return b
}
Q.prototype.then = function(a, b, c) {
    return $d(this, ja(a) ? a : null, ja(b) ? b : null, c)
};
Td(Q);
Q.prototype.cancel = function(a) {
    0 == this.b && Od(function() {
        var b = new ae(a);
        be(this, b)
    }, this)
};

function be(a, b) {
    if (0 == a.b)
        if (a.i) {
            var c = a.i;
            if (c.g) {
                for (var d = 0, e = null, f = null, g = c.g; g && (g.s || (d++, g.b == a && (e = g), !(e && 1 < d))); g = g.next) e || (f = g);
                e && (0 == c.b && 1 == d ? be(c, b) : (f ? (d = f, d.next == c.o && (c.o = d), d.next = d.next.next) : ce(c), de(c, e, 3, b)))
            }
            a.i = null
        } else Vd(a, 3, b)
}

function ee(a, b) {
    a.g || 2 != a.b && 3 != a.b || fe(a);
    a.o ? a.o.next = b : a.g = b;
    a.o = b
}

function $d(a, b, c, d) {
    var e = Yd(null, null, null);
    e.b = new Q(function(a, g) {
        e.o = b ? function(c) {
            try {
                var e = b.call(d, c);
                a(e)
            } catch (n) {
                g(n)
            }
        } : a;
        e.g = c ? function(b) {
            try {
                var e = c.call(d, b);
                void 0 === e && b instanceof ae ? g(b) : a(e)
            } catch (n) {
                g(n)
            }
        } : g
    });
    e.b.i = a;
    ee(a, e);
    return e.b
}
Q.prototype.R = function(a) {
    this.b = 0;
    Vd(this, 2, a)
};
Q.prototype.S = function(a) {
    this.b = 0;
    Vd(this, 3, a)
};

function Vd(a, b, c) {
    if (0 == a.b) {
        a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself"));
        a.b = 1;
        var d;
        a: {
            var e = c,
                f = a.R,
                g = a.S;
            if (e instanceof Q) ee(e, Yd(f || ea, g || null, a)),
            d = !0;
            else if (Ud(e)) e.then(f, g, a),
            d = !0;
            else {
                var h = typeof e;
                if ("object" == h && null != e || "function" == h) try {
                    var l = e.then;
                    if (ja(l)) {
                        ge(e, l, f, g, a);
                        d = !0;
                        break a
                    }
                } catch (n) {
                    g.call(a, n);
                    d = !0;
                    break a
                }
                d = !1
            }
        }
        d || (a.w = c, a.b = b, a.i = null, fe(a), 3 != b || c instanceof ae || he(a, c))
    }
}

function ge(a, b, c, d, e) {
    function f(a) {
        h || (h = !0, d.call(e, a))
    }

    function g(a) {
        h || (h = !0, c.call(e, a))
    }
    var h = !1;
    try {
        b.call(a, g, f)
    } catch (l) {
        f(l)
    }
}

function fe(a) {
    a.u || (a.u = !0, Od(a.H, a))
}

function ce(a) {
    var b = null;
    a.g && (b = a.g, a.g = b.next, b.next = null);
    a.g || (a.o = null);
    return b
}
Q.prototype.H = function() {
    for (var a; a = ce(this);) de(this, a, this.b, this.w);
    this.u = !1
};

function de(a, b, c, d) {
    if (3 == c && b.g && !b.s)
        for (; a && a.s; a = a.i) a.s = !1;
    if (b.b) b.b.i = null, ie(b, c, d);
    else try {
        b.s ? b.o.call(b.i) : ie(b, c, d)
    } catch (e) {
        je.call(null, e)
    }
    Xd.put(b)
}

function ie(a, b, c) {
    2 == b ? a.o.call(a.i, c) : a.g && a.g.call(a.i, c)
}

function he(a, b) {
    a.s = !0;
    Od(function() {
        a.s && je.call(null, b)
    })
}
var je = Hd;

function ae(a) {
    P.call(this, a)
}
A(ae, P);
ae.prototype.name = "cancel";
var le = /^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/;

function me(a) {
    var b = {
        Ed: 7E3,
        Md: new ne
    };
    return oe(a, b).then(function(a) {
        var c = a.responseText;
        b && b.xg && (a = b.xg, 0 == c.lastIndexOf(a, 0) && (c = c.substring(a.length)));
        return Sb(c)
    })
}

function oe(a, b) {
    return new Q(function(c, d) {
        var e = b || {},
            f, g = e.Md ? e.Md.b() : Ed.b();
        try {
            g.open("GET", a, !0)
        } catch (n) {
            d(new pe("Error opening XHR: " + n.message, a))
        }
        g.onreadystatechange = function() {
            if (4 == g.readyState) {
                v.clearTimeout(f);
                var b;
                a: switch (g.status) {
                    case 200:
                    case 201:
                    case 202:
                    case 204:
                    case 206:
                    case 304:
                    case 1223:
                        b = !0;
                        break a;
                    default:
                        b = !1
                }!b && (b = 0 === g.status) && (b = a.match(le)[1] || null, !b && v.self && v.self.location && (b = v.self.location.protocol, b = b.substr(0, b.length - 1)), b = b ? b.toLowerCase() : "", b = !("http" ==
                    b || "https" == b || "" == b));
                b ? c(g) : d(new qe(g.status, a))
            }
        };
        g.onerror = function() {
            d(new pe("Network error", a))
        };
        if (e.headers)
            for (var h in e.headers) {
                var l = e.headers[h];
                null != l && g.setRequestHeader(h, l)
            }
        e.withCredentials && (g.withCredentials = e.withCredentials);
        e.responseType && (g.responseType = e.responseType);
        e.zf && g.overrideMimeType(e.zf);
        0 < e.Ed && (f = v.setTimeout(function() {
            g.onreadystatechange = ea;
            g.abort();
            d(new re(a))
        }, e.Ed));
        try {
            g.send(null)
        } catch (n) {
            g.onreadystatechange = ea, v.clearTimeout(f), d(new pe("Error sending XHR: " + n.message, a))
        }
    })
}

function pe(a, b) {
    P.call(this, a + ", url=" + b)
}
A(pe, P);
pe.prototype.name = "XhrError";

function qe(a, b) {
    pe.call(this, "Request Failed, status=" + a, b);
    this.status = a
}
A(qe, pe);
qe.prototype.name = "XhrHttpError";

function re(a) {
    pe.call(this, "Request timed out", a)
}
A(re, pe);
re.prototype.name = "XhrTimeoutError";

function ne() {}
A(ne, Dd);
ne.prototype.b = function() {
    var a = new XMLHttpRequest;
    if ("withCredentials" in a) return a;
    if ("undefined" != typeof XDomainRequest) return new se;
    throw Error("Unsupported browser");
};

function se() {
    this.b = new XDomainRequest;
    this.readyState = 0;
    this.onreadystatechange = null;
    this.responseText = "";
    this.status = -1;
    this.statusText = null;
    this.b.onload = x(this.Ke, this);
    this.b.onerror = x(this.Qc, this);
    this.b.onprogress = x(this.Me, this);
    this.b.ontimeout = x(this.Ne, this)
}
q = se.prototype;
q.open = function(a, b, c) {
    if (null != c && !c) throw Error("Only async requests are supported.");
    this.b.open(a, b)
};
q.send = function(a) {
    if (a)
        if ("string" == typeof a) this.b.send(a);
        else throw Error("Only string data is supported");
    else this.b.send()
};
q.abort = function() {
    this.b.abort()
};
q.setRequestHeader = k();
q.Ke = function() {
    this.status = 200;
    this.responseText = this.b.responseText;
    te(this, 4)
};
q.Qc = function() {
    this.status = 500;
    this.responseText = "";
    te(this, 4)
};
q.Ne = function() {
    this.Qc()
};
q.Me = function() {
    this.status = 200;
    te(this, 1)
};

function te(a, b) {
    a.readyState = b;
    if (a.onreadystatechange) a.onreadystatechange()
};

function ue(a, b) {
    this.s = [];
    this.U = a;
    this.T = b || null;
    this.o = this.b = !1;
    this.i = void 0;
    this.R = this.V = this.w = !1;
    this.u = 0;
    this.g = null;
    this.H = 0
}
ue.prototype.cancel = function(a) {
    if (this.b) this.i instanceof ue && this.i.cancel();
    else {
        if (this.g) {
            var b = this.g;
            delete this.g;
            a ? b.cancel(a) : (b.H--, 0 >= b.H && b.cancel())
        }
        this.U ? this.U.call(this.T, this) : this.R = !0;
        this.b || (a = new ve, we(this), xe(this, !1, a))
    }
};
ue.prototype.S = function(a, b) {
    this.w = !1;
    xe(this, a, b)
};

function xe(a, b, c) {
    a.b = !0;
    a.i = c;
    a.o = !b;
    ye(a)
}

function we(a) {
    if (a.b) {
        if (!a.R) throw new ze;
        a.R = !1
    }
}
ue.prototype.callback = function(a) {
    we(this);
    xe(this, !0, a)
};

function Ae(a, b, c) {
    a.s.push([b, c, void 0]);
    a.b && ye(a)
}
ue.prototype.then = function(a, b, c) {
    var d, e, f = new Q(function(a, b) {
        d = a;
        e = b
    });
    Ae(this, d, function(a) {
        a instanceof ve ? f.cancel() : e(a)
    });
    return f.then(a, b, c)
};
Td(ue);

function Be(a) {
    return ec(a.s, function(a) {
        return ja(a[1])
    })
}

function ye(a) {
    if (a.u && a.b && Be(a)) {
        var b = a.u,
            c = Ce[b];
        c && (v.clearTimeout(c.b), delete Ce[b]);
        a.u = 0
    }
    a.g && (a.g.H--, delete a.g);
    for (var b = a.i, d = c = !1; a.s.length && !a.w;) {
        var e = a.s.shift(),
            f = e[0],
            g = e[1],
            e = e[2];
        if (f = a.o ? g : f) try {
            var h = f.call(e || a.T, b);
            void 0 !== h && (a.o = a.o && (h == b || h instanceof Error), a.i = b = h);
            if (Ud(b) || "function" === typeof v.Promise && b instanceof v.Promise) d = !0, a.w = !0
        } catch (l) {
            b = l, a.o = !0, Be(a) || (c = !0)
        }
    }
    a.i = b;
    d && (h = x(a.S, a, !0), d = x(a.S, a, !1), b instanceof ue ? (Ae(b, h, d), b.V = !0) : b.then(h, d));
    c && (b =
        new De(b), Ce[b.b] = b, a.u = b.b)
}

function ze() {
    P.call(this)
}
A(ze, P);
ze.prototype.message = "Deferred has already fired";
ze.prototype.name = "AlreadyCalledError";

function ve() {
    P.call(this)
}
A(ve, P);
ve.prototype.message = "Deferred was canceled";
ve.prototype.name = "CanceledError";

function De(a) {
    this.b = v.setTimeout(x(this.i, this), 0);
    this.g = a
}
De.prototype.i = function() {
    delete Ce[this.b];
    throw this.g;
};
var Ce = {};

function Ee(a, b) {
    var c = new yd;
    c.b = a;
    return Fe(c, b)
}

function Fe(a, b) {
    var c = b || {},
        d = c.document || document,
        e = a instanceof yd && a.constructor === yd && a.g === xd ? a.b : "type_error:TrustedResourceUrl",
        f = document.createElement("SCRIPT"),
        g = {
            sd: f,
            Fd: void 0
        },
        h = new ue(Ge, g),
        l = null,
        n = null != c.timeout ? c.timeout : 5E3;
    0 < n && (l = window.setTimeout(function() {
        He(f, !0);
        var a = new Ie(1, "Timeout reached for loading script " + e);
        we(h);
        xe(h, !1, a)
    }, n), g.Fd = l);
    f.onload = f.onreadystatechange = function() {
        f.readyState && "loaded" != f.readyState && "complete" != f.readyState || (He(f, c.Wg || !1, l), h.callback(null))
    };
    f.onerror = function() {
        He(f, !0, l);
        var a = new Ie(0, "Error while loading script " + e);
        we(h);
        xe(h, !1, a)
    };
    g = c.attributes || {};
    Ub(g, {
        type: "text/javascript",
        charset: "UTF-8",
        src: e
    });
    Bd(f, g);
    Je(d).appendChild(f);
    return h
}

function Je(a) {
    var b;
    return (b = (a || document).getElementsByTagName("HEAD")) && 0 != b.length ? b[0] : a.documentElement
}

function Ge() {
    if (this && this.sd) {
        var a = this.sd;
        a && "SCRIPT" == a.tagName && He(a, !0, this.Fd)
    }
}

function He(a, b, c) {
    null != c && v.clearTimeout(c);
    a.onload = ea;
    a.onerror = ea;
    a.onreadystatechange = ea;
    b && window.setTimeout(function() {
        a && a.parentNode && a.parentNode.removeChild(a)
    }, 0)
}

function Ie(a, b) {
    var c = "Jsloader error (code #" + a + ")";
    b && (c += ": " + b);
    P.call(this, c)
}
A(Ie, P);

function Ke(a) {
    a = a || {};
    this.operatorDeferredUrl = a.operatorDeferredUrl;
    this.alphaTestMode = a.alphaTestMode || !1;
    this.stagingMode = a.stagingMode || !1;
    this.rosterId = a.rosterId || "talk_roster";
    this.feedbackId = a.feedbackId || 74772;
    this.moleVersion = a.moleVersion || void 0;
    this.moleUrl = a.moleUrl || "https://support.google.com/inapp/chat_mole_frame";
    this.gstaticBaseUrl = a.gstaticBaseUrl || void 0;
    this.operatorDeferredBaseUrl = a.operatorDeferredBaseUrl || void 0;
    this.isRtl = a.isRtl || void 0;
    this.forceLeftMoles = a.forceLeftMoles ||
        void 0;
    this.helpCenterName = a.helpCenterName || null;
    this.localeName = a.localeName || null;
    this.document = a.document || document;
    this.source = a.source || void 0;
    this.entityId = a.entityId || void 0;
    this.authUser = a.authUser || void 0;
    this.apiKey = a.apiKey || void 0
};

function Le() {}
var Me, Ne, Oe;
Me = new Le;
Ne = new Le;
Oe = new Le;

function Pe() {
    this.b = Oe;
    this.i = this.window = this.g = void 0
};
var Qe = {
    Nd: "AIzaSyB5V4SIBGmrqREm7kf2fBJgPcBMCdUrLzE",
    Gg: "https://test-realtimesupport-googleapis.sandbox.google.com",
    Ig: "https://staging-realtimesupport-googleapis.sandbox.google.com",
    Hg: "https://realtimesupport.clients6.google.com",
    Od: "d",
    Qd: "s",
    Pd: "p",
    Sd: "true",
    sh: function(a) {
        return null != a && a.toLowerCase() == Qe.Sd.toLowerCase()
    },
    Ug: function(a, b) {
        var c = new Pe;
        c.b = b ? Qe.ze(a) : Qe.Ae(a);
        var d = a.document;
        c.window = d ? d.parentWindow || d.defaultView : window;
        c.g = a.apiKey;
        c.i = a.authUser;
        return c
    },
    Ae: function() {
        return new Le
    },
    ze: function(a) {
        return a.alphaTestMode ? Me : a.stagingMode ? Ne : Oe
    },
    ih: function(a) {
        return a.alphaTestMode ? Qe.Od : a.stagingMode ? Qe.Qd : Qe.Pd
    }
};
z("chatsupport.ConfigUtils", Qe);

function Re(a) {
    this.b = a instanceof Ke ? a : new Ke(a);
    this.b = Se(this.b);
    this.g = Te(this);
    this.b.moleVersion || this.g.then(function(a) {
        this.b.moleVersion = a.cbfVersion
    }, k(), this);
    this.g.then(this.o, k(), this)
}

function Ue() {
    return da("cs.operatorDeferredInstance")
}

function Ve() {
    var a = da("cs.operatorDeferredPromise");
    return a instanceof Q ? a : null != a ? Zd(a) : null
}

function We(a) {
    z("cs.operatorDeferredPromise", a)
}

function Xe() {}

function Se(a) {
    var b = {},
        c;
    for (c in a) b[c] = a[c];
    b.document = b.document || document;
    null != b.localeName && (b.localeName = b.localeName.replace(/_/g, "-"));
    b.localeName = b.localeName && 0 <= ac(Ye, b.localeName) ? b.localeName : "en";
    b.helpCenterName = b.helpCenterName || "chatsupport";
    b.apiKey = b.apiKey || Qe.Nd;
    return b
}

function Te(a) {}

function Ze(a) {
    var b = Ve();
    if (b) return b;
    if (b = Ue()) return a = Zd(b), We(a), a;
    a = $e(a).then(function(a) {
        var b = {
            document: this.b.document
        };
        this.b.operatorDeferredUrl = a;
        return Ee(a, b).then(function() {
            return v.cs.OperatorDeferred.getInstance(this.b)
        }, null, this)
    }, null, a);
    We(a);
    return a
}
Re.prototype.o = function(a) {
    (new RegExp(a.eagerLoadHostnamePattern, a.eagerLoadHostnameFlags)).test(this.b.document.location.hostname) && (a = Ze(this), $d(a, null, ma(Xe, "Error retrieving OperatorDeferred"), void 0))
};

function $e(a) {
    return a.b.operatorDeferredUrl ? Zd(a.b.operatorDeferredUrl) : a.b.operatorDeferredBaseUrl ? (a = a.b.operatorDeferredBaseUrl + "/" + a.b.moleVersion + "/operatordeferred_bin_base__" + a.b.localeName.replace(/-/g, "_").toLowerCase() + ".js", Zd(a)) : a.g.then(x(function(a) {
        return "https://ssl.gstatic.com/support/realtime/operator/" + a.cbfVersion + "/operatordeferred_bin_base__" + this.b.localeName.replace(/-/g, "_").toLowerCase() + ".js"
    }, a), k())
}

function af(a, b) {
    Ze(a).then(ma(function(a, b) {
        b.registerAvailabilityCallbacks(a)
    }, b))
}
Re.prototype.i = function() {
    return Ze(this).then(function(a) {
        a.getAvailabilities()
    })
};

function bf(a, b, c) {
    b = ma(function(a, b, c, g, h) {
        return h.requestSupport(a, b, c, g)
    }, b, c, void 0, !0);
    return (c = Ue()) ? (a = b(c), Zd(a)) : Ze(a).then(b)
}
var Ye = "ar ar-XB bg ca cs da de el en en-AU en-GB en-XA en-XC es es-419 et fa fi fil fr hi hr hu id it iw ja ko lt lv ms nl no pl pt-PT pt-BR ro ru sk sl sr sv th tr uk vi zh-CN zh-TW zh-HK".split(" ");

function cf(a) {
    this.b = new Re({
        helpCenterName: D().hc,
        localeName: a.lang,
        isRtl: D().rtl,
        alphaTestMode: 1 == na("hcfe.page.Page.model.chatAlphaTestMode"),
        stagingMode: 1 == na("hcfe.page.Page.model.chatStagingMode") || "PROD" != a.env,
        rosterId: "chat-support-roster",
        source: 3,
        authUser: D().au || 0
    });
    a = document.createElement("div");
    a.id = "chat-support-roster";
    a.style.display = "none";
    document.body.appendChild(a)
}
cf.prototype.o = function(a) {
    af(this.b, a);
    this.b.i();
    df(this)
};

function df(a) {
    a.g || (a.g = window.setInterval(a.b.i.bind(a.b), 3E4), document.addEventListener("pjaxunload", function() {
        window.clearInterval(this.g)
    }.bind(a)))
}
cf.prototype.i = function(a, b) {
    bf(this.b, a, b).then(function() {
        window.sc_trackStatsEvent(Za, ub)
    })
};
window.sc_initChatSupport = function(a) {
    if (!window.sc_registerChatPools || window.sc_refresh) a = new cf(a), window.sc_registerChatPools = a.o.bind(a), window.sc_requestChatSupport = a.i.bind(a)
};



function rn(a) {
    this.b = a;
    this.i = this.b.getAttribute("data-videoid");
    this.g = C(this.b, "embedded-video") ? "default" : "medium";
    sn(this)
}

function sn() {}

function un(a, b) {
    if (b.items && b.items[0] && b.items[0].snippet) {
        var c = b.items[0].snippet,
            d = function(a) {
                for (var b = c, d = 0; d < arguments.length && b; d++) b = b[arguments[d]];
                return b
            };
        a.s = a.b.textContent || d("localized", "title");
        a.w = d("localized", "description");
        a.o = Number(d("thumbnails", a.g, "width")) / Number(d("thumbnails", a.g, "height")) == tn ? tn : 1.6;
        a.u = d("thumbnails", a.g, "url");
        vn(a)
    }
}

function vn(a) {
    a.u && (a.b.style.backgroundImage = "url(" + a.u.replace(/^https?:/, "") + ")");
    a.b.setAttribute("data-tracking-method", "NOW");
    a.b.setAttribute("st-method", "IMMEDIATE");
    a.b.addEventListener("click", function(a) {
        a.preventDefault();
        wn(this)
    }.bind(a));
    a.b.textContent = "";
    var b = document.createElement("div");
    b.className = "default" == a.g ? "video-description" : "video-custom";
    a.b.parentNode.replaceChild(b, a.b);
    b.appendChild(a.b);
    if ("video-custom" == b.className) {
        var c = b.nextElementSibling;
        c && !C(c, "youtube-text") && B(b, "border-bottom", !0)
    }
    b = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    b.setAttribute("viewBox", "0 0 48 48");
    c = document.createElementNS("http://www.w3.org/2000/svg", "path");
    c.setAttribute("d", "M40 8.8c-1.2-.4-8.6-.8-16-.8s-14.8.4-16 .8c-3.1 1-4 8-4 15.2s.9 14.2 4 15.2c1.2.4 8.6.8 16 .8s14.8-.4 16-.8c3.1-1 4-8 4-15.2s-.9-14.2-4-15.2zM20 33V15l12 9-12 9z");
    b.appendChild(c);
    a.b.appendChild(b);
    b = document.createElement("div");
    b.className = "title";
    b.textContent = a.s;
    a.b.appendChild(b);
    b = document.createElement("div");
    b.className = "description";
    b.textContent = a.w;
    a.b.appendChild(b)
}

function wn(a) {
    var b = "//www.youtube.com/embed/" + a.i + "/?rel=0&cc_load_policy=1&autoplay=1&hl=" + window.sc_pageModel.lang;
    if (770 >= window.innerWidth) H(b);
    else {
        var b = document.createElement("div"),
            c = document.createElement("h2");
        c.textContent = a.s;
        b.appendChild(c);
        c = document.createElement("div");
        c.className = "video-popup";
        b.appendChild(c);
        var d = document.createElement("div");
        d.style.height = 640 / a.o + "px";
        c.appendChild(d);
        window.YT && window.YT.Player ? xn(a, d) : (tm.push(function(a) {
            xn(this, a)
        }.bind(a, d)), vm());
        window.sc_showLightbox(b)
    }
}

function xn(a, b) {
    var c = new window.YT.Player(b, {
        height: String(640 / a.o),
        width: "640",
        videoId: a.i,
        playerVars: {
            autoplay: 1,
            cc_load_policy: 1,
            controls: 2,
            hl: window.sc_pageModel.lang,
            rel: 0
        },
        events: {
            onStateChange: function(a) {
                a = a.data;
                var b = c.getCurrentTime(),
                    d = c.getDuration();
                xm(a, this.i, b, d)
            }.bind(a)
        }
    })
}
window.sc_initPopupVideos = function() {
    for (var a = window.sc_scope || document, b = a.querySelectorAll(".carousel-container .related-item--youtube"), c = 0; c < b.length; c++) {
        var d = b[c],
            e = d.getElementsByClassName("embedded-video")[0];
        e && B(e, "embedded-video", !1);
        e || (e = d.getElementsByClassName("embedded-video-large")[0]) && B(e, "embedded-video-large", !1);
        e && B(e, "embedded-video-custom", !0)
    }
    a = a.querySelectorAll(".embedded-video, .embedded-video-custom");
    for (b = 0; b < a.length; b++) new rn(a[b])
};


var Fl = 1;

function Gl(a) {
    this.i = a;
    this.b = this.H = this.g = null;
    this.o = [];
    this.s = -1;
    this.U = this.Kb.bind(this);
    this.S = this.kc.bind(this);
    this.V = this.R = this.w = 0;
    this.u = !1;
    this.T = 0;
    Hl(this)
}

function Hl(a) {
    a.g = document.createElement("div");
    a.g.className = a.i.className;
    var b = a.i.getAttribute("aria-label");
    b && a.g.setAttribute("aria-label", b);
    B(a.g, "sc-select", !0);
    a.g.setAttribute("tabindex", 0);
    a.g.setAttribute("role", "listbox");
    a.g.addEventListener("mousedown", function(a) {
        C(this.b, "sc-select-show") ? a.target == this.b || this.b.contains(a.target) || this.Kb() : 0 == a.button && Il(this)
    }.bind(a));
    a.g.addEventListener("keydown", a.Hf.bind(a));
    a.H = document.createElement("span");
    a.g.appendChild(a.H);
    b = document.createElementNS("http://www.w3.org/2000/svg", "svg");
    b.setAttribute("viewBox", "0 0 8 12");
    var c = document.createElementNS("http://www.w3.org/2000/svg", "path");
    c.setAttribute("d", "M0 5l4-4 4 4z M0 8l4 4 4-4z");
    b.appendChild(c);
    a.g.appendChild(b);
    a.b = document.createElement("ol");
    a.b.addEventListener("mousemove", function() {
        this.u = !0
    }.bind(a));
    a.b.addEventListener("scroll", function() {
        0 < this.T ? this.T-- : this.kc()
    }.bind(a));
    a.g.appendChild(a.b);
    a.Zc();
    a.i.addEventListener("optionschange", a.Zc.bind(a));
    a.i.addEventListener("change", function() {
        this.H.textContent = this.i.options[this.i.selectedIndex].text;
        this.g.setAttribute("aria-activedescendant", this.o[this.i.selectedIndex].id)
    }.bind(a));
    a.i.style.display = "none";
    a.i.nextElementSibling ? a.i.parentNode.insertBefore(a.g, a.i.nextElementSibling) : a.i.parentNode.appendChild(a.g)
}
q = Gl.prototype;
q.Zc = function() {
    this.b.textContent = "";
    this.b.style.height = "";
    this.R = 0;
    this.o = [];
    for (var a = 0; a < this.i.options.length; a++) {
        var b = document.createElement("li");
        b.setAttribute("role", "option");
        b.id = ":" + Fl++;
        b.textContent = this.i.options[a].text;
        b.addEventListener("mouseup", function(a) {
            this.u && this.tc(a)
        }.bind(this, a));
        b.addEventListener("click", this.tc.bind(this, a));
        b.addEventListener("mouseenter", function(a) {
            this.u && Jl(this, a)
        }.bind(this, a));
        b.addEventListener("mouseleave", function(a) {
            this.u && this.s == a && (this.s = -1, B(this.o[a], "sc-select-highlight", !1))
        }.bind(this, a));
        this.o.push(b);
        this.b.appendChild(b)
    } - 1 != this.i.selectedIndex && (this.H.textContent = this.i.options[this.i.selectedIndex].text, this.g.setAttribute("aria-activedescendant", this.o[this.i.selectedIndex].id))
};

function Il(a) {
    a.u = !1;
    Jl(a, a.i.selectedIndex);
    a.kc();
    document.addEventListener("click", a.U);
    document.addEventListener("scroll", a.S);
    window.addEventListener("resize", a.S);
    Ba(!0)
}
q.Kb = function(a) {
    if (!a || a.target != this.g && !this.g.contains(a.target)) document.removeEventListener("click", this.U), document.removeEventListener("scroll", this.S), window.removeEventListener("resize", this.S), B(this.b, "sc-select-show", !1), Ba(!1)
};
q.kc = function() {
    var a, b, c, d;
    C(this.b, "sc-select-show") ? this.w = this.b.offsetTop - this.b.scrollTop : (B(this.b, "sc-select-show", !0), b = this.o[0] ? this.o[0].offsetHeight : 0, this.w = this.g.offsetHeight / 2 - b / 2 - b * this.i.selectedIndex - (this.o[0] ? this.o[0].offsetTop : 0), this.R || (this.R = this.b.offsetHeight, this.V = this.b.offsetHeight - b * this.o.length));
    b = d = 0;
    a = this.b.offsetParent;
    for (c = !1; a;) d -= a.offsetLeft, b -= a.offsetTop, "fixed" == window.getComputedStyle(a).position && (c = !0), a = a.offsetParent;
    c || (d += window.pageXOffset, b += window.pageYOffset);
    a = d;
    c = document.documentElement.clientWidth;
    d = document.documentElement.clientHeight;
    a = Math.max(Math.min(D().rtl ? this.g.offsetWidth - this.b.offsetWidth : 0, a + c - this.b.offsetWidth), a);
    c = Math.max(this.w, b);
    b = Math.min(this.w + this.R, b + d) - c;
    b <= this.V || (this.b.style.left = a + "px", this.b.style.top = c + "px", this.b.style.height = b + "px", b = c - this.w, this.b.scrollTop != b && (this.T++, this.b.scrollTop = b))
};
q.tc = function(a) {
    var b = this.i.options[a];
    b.selected || (b.selected = !0, this.H.textContent = b.text, this.g.setAttribute("aria-activedescendant", this.o[a].id), G(this.i, "change"));
    this.Kb()
};

function Jl(a, b) {
    -1 != a.s && B(a.o[a.s], "sc-select-highlight", !1);
    a.s = b;
    B(a.o[a.s], "sc-select-highlight", !0)
}
q.Hf = function(a) {
    switch (a.which) {
        case 13:
        case 32:
            C(this.b, "sc-select-show") ? -1 != this.s && this.tc(this.s) : Il(this);
            break;
        case 27:
            this.Kb();
            this.g.setAttribute("aria-activedescendant", this.o[this.i.selectedIndex].id);
            break;
        case 38:
            a.preventDefault();
            C(this.b, "sc-select-show") || Il(this);
            a = -1 == this.s ? 0 : (this.s - 1 + this.o.length) % this.o.length;
            Jl(this, a);
            this.g.setAttribute("aria-activedescendant", this.o[a].id);
            Kl(this);
            break;
        case 40:
            a.preventDefault(), C(this.b, "sc-select-show") || Il(this), a = -1 == this.s ? 0 : (this.s + 1) % this.o.length, Jl(this, a), this.g.setAttribute("aria-activedescendant", this.o[a].id), Kl(this)
    }
};

function Kl(a) {
    if (-1 != a.s) {
        var b = a.o[a.s];
        b.offsetTop < a.b.scrollTop ? (a.u = !1, a.b.scrollTop = b.offsetTop) : b.offsetTop + b.offsetHeight > a.b.scrollTop + a.b.offsetHeight && (a.u = !1, a.b.scrollTop = b.offsetTop + b.offsetHeight - a.b.offsetHeight)
    }
}
window.sc_initSelects = function() {
    for (var a = (window.sc_scope || document).getElementsByTagName("select"), b = 0; b < a.length; b++) new Gl(a[b])
};